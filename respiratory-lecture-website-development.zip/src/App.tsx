import { useEffect, useRef, useState } from "react";
import { StoreProvider, useStore } from "./store";
import { LightboxProvider } from "./components/ui";
import { BlockView, countChecks, countDone } from "./components/Blocks";
import { lec1 } from "./data/lec1";
import { lec2 } from "./data/lec2";
import { lec3 } from "./data/lec3";
import { McqView, FlashView, PastView, ReviewView } from "./views/Practice";
import { DdxView, CasesView, RadLab } from "./views/Clinical";
import { MindView } from "./views/MindView";
import type { Lecture } from "./types";

const LECS: Lecture[] = [lec1, lec2, lec3];
type Route = { v: string; l?: string; s?: string };
const parse = (): Route => { const h = location.hash.replace(/^#\/?/, "").split("/"); return h[0] === "lec" ? { v: "lec", l: h[1], s: h[2] } : { v: h[0] || "home" }; };

function useProgress() {
  const { isDone } = useStore();
  const secDone = (l: Lecture, si: number) => {
    const s = l.sections[si]; const tot = countChecks(s.blocks) + (si === 0 ? l.objectives.length : 0);
    const dn = countDone(s.blocks, `${l.id}/${s.id}`, isDone) + (si === 0 ? l.objectives.filter((_, i) => isDone(`obj/${l.id}/${i}`)).length : 0);
    return { tot, dn, complete: isDone(`section/${l.id}/${s.id}`) || (tot > 0 && dn === tot) };
  };
  const lecPct = (l: Lecture) => Math.round((l.sections.filter((_, i) => secDone(l, i).complete).length / l.sections.length) * 100);
  return { secDone, lecPct };
}

/* ---------------- Timer ---------------- */
function Timer() {
  const { ui } = useStore();
  const [end, setEnd] = useState<number | null>(() => { const v = localStorage.getItem("rx-timer-end"); return v ? +v : null; });
  const [paused, setPaused] = useState<number | null>(() => { const v = localStorage.getItem("rx-timer-paused"); return v ? +v : null; });
  const [total, setTotal] = useState<number>(() => +(localStorage.getItem("rx-timer-total") ?? 0));
  const [now, setNow] = useState(Date.now());
  const [open, setOpen] = useState(false);
  const [custom, setCustom] = useState(25);
  const beeped = useRef(false);
  useEffect(() => { const i = setInterval(() => setNow(Date.now()), 500); return () => clearInterval(i); }, []);
  useEffect(() => {
    end ? localStorage.setItem("rx-timer-end", String(end)) : localStorage.removeItem("rx-timer-end");
    paused !== null ? localStorage.setItem("rx-timer-paused", String(paused)) : localStorage.removeItem("rx-timer-paused");
    localStorage.setItem("rx-timer-total", String(total));
  }, [end, paused, total]);
  const left = paused !== null ? paused : end ? Math.max(0, end - now) : 0;
  const finished = !!end && paused === null && left <= 0;
  useEffect(() => {
    if (finished && !beeped.current) {
      beeped.current = true;
      try { const ac = new AudioContext(); [0, 0.35, 0.7].forEach((t) => { const o = ac.createOscillator(); const g = ac.createGain(); o.frequency.value = 880; o.connect(g); g.connect(ac.destination); g.gain.setValueAtTime(0.2, ac.currentTime + t); g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + t + 0.3); o.start(ac.currentTime + t); o.stop(ac.currentTime + t + 0.3); }); } catch { /* */ }
    }
    if (!finished) beeped.current = false;
  }, [finished]);
  const start = (min: number) => { setTotal(min * 60000); setEnd(Date.now() + min * 60000); setPaused(null); setOpen(false); };
  const fmt = (ms: number) => { const s = Math.ceil(ms / 1000); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60; return (h ? h + ":" : "") + String(m).padStart(2, "0") + ":" + String(ss).padStart(2, "0"); };
  const pct = total ? (1 - left / total) * 100 : 0;
  return (
    <div className="relative">
      {end ? (
        <div className={"timer-pill " + (finished ? "done" : "")}>
          <span className="timer-ring" style={{ background: `conic-gradient(#7fb39b ${pct}%, #e8e1d2 0)` }} />
          <b dir="ltr">{finished ? ui("انتهى الوقت! ⏰", "Time's up! ⏰") : fmt(left)}</b>
          {!finished && <button onClick={() => (paused !== null ? (setEnd(Date.now() + paused), setPaused(null)) : setPaused(left))} title="pause">{paused !== null ? "▶" : "⏸"}</button>}
          <button onClick={() => { setEnd(null); setPaused(null); setTotal(0); }} title="stop">✕</button>
        </div>
      ) : (
        <button className="hdr-btn" onClick={() => setOpen(!open)}>⏱️ <span className="hidden sm:inline">{ui("مؤقت", "Timer")}</span></button>
      )}
      {open && !end && (
        <div className="timer-pop animate-fade">
          <div className="font-bold mb-2">{ui("حدد وقت الدراسة", "Set your study time")}</div>
          <div className="grid grid-cols-3 gap-2">{[15, 30, 45, 60, 90, 120].map((m) => <button key={m} className="pill" onClick={() => start(m)}>{m < 60 ? `${m} ${ui("د", "min")}` : `${m / 60} ${ui("س", "h")}`}</button>)}</div>
          <div className="flex gap-2 mt-2 items-center"><input type="number" min={1} max={600} value={custom} onChange={(e) => setCustom(+e.target.value)} className="num-in" /><span className="text-sm">{ui("دقيقة", "min")}</span><button className="btn-soft !py-1" onClick={() => start(custom)}>{ui("ابدأ", "Start")}</button></div>
        </div>
      )}
    </div>
  );
}

/* ---------------- Home ---------------- */
function Home({ go }: { go: (h: string) => void }) {
  const { tr, ui } = useStore();
  const { lecPct } = useProgress();
  const tools = [
    ["mcq", "✍️", ui("أسئلة MCQ", "MCQ"), ui("70+ سؤال مع أسئلة السنين", "70+ questions incl. past papers"), "#fbe3c4"],
    ["flash", "🃏", ui("بطاقات المراجعة", "Flashcards"), ui("50 بطاقة قلابة", "50 flip cards"), "#d9ecf5"],
    ["mind", "🗺️", ui("الخريطة الذهنية", "Mind map"), ui("كل المحاضرات بفروع", "All lectures as branches"), "#e3efd8"],
    ["ddx", "⚖️", ui("التشخيص التفريقي", "Differential diagnosis"), ui("مقارنات صف بصف", "Row-by-row comparisons"), "#f8d9d2"],
    ["cases", "🩺", ui("حالات سريرية", "Clinical cases"), ui("الحالة تنكشف بالتدريج", "Step-by-step unfolding"), "#d7ecdf"],
    ["rad", "🩻", ui("مختبر الأشعة", "Radiology lab"), ui("تكبير، علامات، اختبار، مقارنة", "Zoom, labels, quiz, compare"), "#dfe6f2"],
    ["past", "📜", ui("أسئلة السنين", "Past papers"), ui("فقط المتعلقة بالمحاضرات", "Only lecture-related"), "#f6e3b4"],
    ["review", "🧠", ui("المراجعة الذكية", "Smart review"), ui("Spaced repetition", "Spaced repetition"), "#efe1f5"],
  ];
  return (
    <div className="space-y-6">
      <div className="hero">
        <div className="hero-stickers"><span className="sticker floaty" style={{ background: "#f6e3b4" }}>🫁</span><span className="sticker floaty d2" style={{ background: "#d9ecf5" }}>🩻</span><span className="sticker floaty d3" style={{ background: "#f8d9d2" }}>🩺</span></div>
        <div className="text-sm font-bold text-[#7fb39b]">University of Baghdad · College of Medicine · 4th grade</div>
        <h1 className="hero-title">{ui("طب الجهاز التنفسي", "Respiratory Medicine")} <span>LEC 1–3</span></h1>
        <p className="hero-sub">{ui("شرح مبسط ومفصل بالعربي لكل معلومة بالمحاضرات، مع صور حقيقية، فيديوهات قصيرة، أنيميشن، نماذج 3D، ألعاب، أسئلة سنين، وحالات سريرية.", "A simple yet detailed explanation of every lecture point, with real images, short videos, animations, 3D models, games, past papers and clinical cases.")}</p>
        <svg viewBox="0 0 300 120" className="hero-svg" aria-hidden><path d="M10 60 L80 60 L95 30 L110 95 L125 45 L140 60 L290 60" fill="none" stroke="#d16a5c" strokeWidth="4" strokeLinecap="round" className="ecg-line" /></svg>
      </div>
      <div className="fill-grid lec-grid">
        {LECS.map((l) => (
          <button key={l.id} className="lec-card" style={{ ["--c" as string]: l.color }} onClick={() => go(`lec/${l.id}/${l.sections[0].id}`)}>
            <div className="flex items-center gap-3"><span className="lec-num">{l.num}</span><span className="text-3xl">{l.emoji}</span></div>
            <div className="text-lg font-extrabold mt-3 leading-snug">{tr(l.title)}</div>
            <div className="text-sm mt-2 text-[#5b5546] leading-relaxed">{tr(l.summary)}</div>
            <div className="text-xs mt-2 text-[#8a857a]">{l.sections.length} {ui("فئات", "sections")} · {l.lecturer}</div>
            <div className="progress-line mt-3"><span style={{ width: `${lecPct(l)}%`, background: l.color }} /></div>
            <div className="text-xs mt-1 font-bold">{lecPct(l)}% {ui("منجز", "done")}</div>
          </button>
        ))}
      </div>
      <div>
        <div className="view-sub">🧰 {ui("أدوات المراجعة", "Study tools")}</div>
        <div className="fill-grid tool-grid">{tools.map(([k, ic, t1, t2, bg]) => <button key={k} className="tool-card" style={{ background: bg }} onClick={() => go(k)}><span className="text-3xl">{ic}</span><span className="font-extrabold">{t1}</span><span className="text-xs">{t2}</span></button>)}</div>
      </div>
    </div>
  );
}

/* ---------------- Lecture ---------------- */
function LectureView({ l, si, go }: { l: Lecture; si: number; go: (h: string) => void }) {
  const { tr, ui, isDone, toggle, setDone } = useStore();
  const { secDone } = useProgress();
  const s = l.sections[si];
  const st = secDone(l, si);
  const flat = LECS.flatMap((L) => L.sections.map((S) => ({ L, S })));
  const gi = flat.findIndex((x) => x.L.id === l.id && x.S.id === s.id);
  const prev = flat[gi - 1], next = flat[gi + 1];
  useEffect(() => { window.scrollTo({ top: 0 }); }, [l.id, s.id]);
  return (
    <div className="space-y-5">
      <div className="lec-banner" style={{ ["--c" as string]: l.color }}>
        <div className="text-xs font-bold opacity-80">LEC {l.num} · {tr(l.title)} · {si + 1}/{l.sections.length}</div>
        <h1 className="text-2xl md:text-3xl font-black mt-1 flex items-center gap-3"><span className="sticker" style={{ background: "#fffdf8" }}>{s.icon}</span>{tr(s.title)}</h1>
        {st.tot > 0 && <div className="mt-3 flex items-center gap-3"><div className="progress-line flex-1"><span style={{ width: `${(st.dn / st.tot) * 100}%`, background: "#3f3d38" }} /></div><span className="text-sm font-bold">{st.dn}/{st.tot}</span></div>}
      </div>
      {si === 0 && (
        <div className="check-card">
          <div className="block-title">🎯 {ui("أهداف المحاضرة", "Lecture objectives")}</div>
          {l.objectives.map((o, i) => { const k = `obj/${l.id}/${i}`; const on = isDone(k); return <button key={i} onClick={() => toggle(k)} className={"check-item " + (on ? "on" : "")}><span className="check-box">{on ? "✓" : ""}</span><span className="check-text">{tr(o)}</span></button>; })}
        </div>
      )}
      {s.blocks.map((b, bi) => <div key={bi} className="block-wrap"><BlockView b={b} scope={`${l.id}/${s.id}/${bi}`} /></div>)}
      <div className="section-end">
        <button className={"done-btn " + (st.complete ? "on" : "")} onClick={() => setDone(`section/${l.id}/${s.id}`, !isDone(`section/${l.id}/${s.id}`))}>{st.complete ? "✅ " + ui("أكملت هذه الفئة", "Section completed") : "☐ " + ui("علّم الفئة كمكتملة", "Mark section as completed")}</button>
        <div className="flex gap-2 flex-wrap justify-between w-full">
          {prev ? <button className="nav-btn" onClick={() => go(`lec/${prev.L.id}/${prev.S.id}`)}>‹ {tr(prev.S.title)}</button> : <span />}
          {next ? <button className="nav-btn" onClick={() => go(`lec/${next.L.id}/${next.S.id}`)}>{tr(next.S.title)} ›</button> : <button className="nav-btn" onClick={() => go("mcq")}>✍️ MCQ ›</button>}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Shell ---------------- */
function Shell() {
  const { tr, ui, lang, setLang } = useStore();
  const { secDone, lecPct } = useProgress();
  const [route, setRoute] = useState<Route>(parse());
  const [drawer, setDrawer] = useState(false);
  const [openLec, setOpenLec] = useState<string | null>(route.l ?? "lec1");
  useEffect(() => { const f = () => setRoute(parse()); window.addEventListener("hashchange", f); return () => window.removeEventListener("hashchange", f); }, []);
  const go = (h: string) => { location.hash = "/" + h; setDrawer(false); window.scrollTo({ top: 0 }); };
  useEffect(() => { if (route.l) setOpenLec(route.l); }, [route.l]);
  const lec = LECS.find((l) => l.id === route.l);
  const si = lec ? Math.max(0, lec.sections.findIndex((s) => s.id === route.s)) : 0;
  const tools: [string, string, string][] = [["mcq", "✍️", ui("أسئلة MCQ", "MCQ")], ["flash", "🃏", ui("بطاقات المراجعة", "Flashcards")], ["mind", "🗺️", ui("الخريطة الذهنية", "Mind map")], ["ddx", "⚖️", ui("التشخيص التفريقي", "Differential Dx")], ["cases", "🩺", ui("حالات سريرية", "Clinical cases")], ["rad", "🩻", ui("مختبر الأشعة", "Radiology lab")], ["past", "📜", ui("أسئلة السنين", "Past papers")], ["review", "🧠", ui("المراجعة الذكية", "Smart review")]];
  const nav = (
    <nav className="space-y-3">
      <button className={"side-link " + (route.v === "home" ? "active" : "")} onClick={() => go("home")}>🏠 {ui("الرئيسية", "Home")}</button>
      {LECS.map((l) => (
        <div key={l.id}>
          <button className="side-lec" onClick={() => setOpenLec(openLec === l.id ? null : l.id)} style={{ ["--c" as string]: l.color }}>
            <span className="side-num">{l.num}</span><span className="flex-1 text-start leading-tight">{tr(l.title)}</span><span className="text-[0.7rem] font-bold opacity-70">{lecPct(l)}%</span><span className="text-xs">{openLec === l.id ? "▾" : "▸"}</span>
          </button>
          {openLec === l.id && <div className="side-secs" style={{ borderColor: l.color }}>
            {l.sections.map((s, i) => { const d = secDone(l, i); const act = route.v === "lec" && route.l === l.id && si === i; return (
              <button key={s.id} className={"side-link " + (act ? "active" : "")} onClick={() => go(`lec/${l.id}/${s.id}`)}>
                <span>{d.complete ? "✅" : s.icon}</span><span className="flex-1 text-start leading-snug">{tr(s.title)}</span>{d.tot > 0 && !d.complete && <span className="side-count">{d.dn}/{d.tot}</span>}
              </button>); })}
          </div>}
        </div>
      ))}
      <div className="side-sep">{ui("أدوات", "Tools")}</div>
      {tools.map(([k, ic, n]) => <button key={k} className={"side-link " + (route.v === k ? "active" : "")} onClick={() => go(k)}><span>{ic}</span><span>{n}</span></button>)}
    </nav>
  );
  let body;
  if (route.v === "lec" && lec) body = <LectureView l={lec} si={si} go={go} />;
  else if (route.v === "mcq") body = <McqView />;
  else if (route.v === "smart") body = <McqView smart key="smart" />;
  else if (route.v === "flash") body = <FlashView />;
  else if (route.v === "mind") body = <MindView />;
  else if (route.v === "ddx") body = <DdxView />;
  else if (route.v === "cases") body = <CasesView />;
  else if (route.v === "rad") body = <RadLab />;
  else if (route.v === "past") body = <PastView />;
  else if (route.v === "review") body = <ReviewView go={go} />;
  else body = <Home go={go} />;
  return (
    <div className="min-h-screen">
      <header className="hdr">
        <button className="hdr-btn lg:hidden" onClick={() => setDrawer(true)}>☰</button>
        <button className="flex items-center gap-2 font-black" onClick={() => go("home")}><span className="logo">🫁</span><span className="hidden sm:inline">{ui("صدرية – المحاضرات 1–3", "Respiratory – LEC 1–3")}</span></button>
        <div className="flex-1" />
        <Timer />
        <button className="hdr-btn lang-btn" onClick={() => setLang(lang === "ar" ? "en" : "ar")}>{lang === "ar" ? "🌐 English" : "🌐 AR"}</button>
      </header>
      <div className="layout">
        <aside className="side hidden lg:block">{nav}</aside>
        {drawer && <div className="drawer-bg lg:hidden" onClick={() => setDrawer(false)}><aside className="drawer" onClick={(e) => e.stopPropagation()}>{nav}</aside></div>}
        <main className="main" key={route.v + (route.l ?? "") + (route.s ?? "")}>{body}</main>
      </div>
    </div>
  );
}

export default function App() {
  return <StoreProvider><LightboxProvider><Shell /></LightboxProvider></StoreProvider>;
}
