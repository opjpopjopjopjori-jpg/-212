/// <reference types="vite/client" />
export type L = { ar: string; en: string };
export const t = (ar: string, en: string): L => ({ ar, en });

export type Img = { src: string; full?: string; cap: L; credit?: string };
export type Video = { id: string; title: string; channel: string; dur: string; lang: "EN" | "AR"; note: L };

export type AnimName =
  | "investigations-wheel" | "sputum-journey" | "xray-beam" | "ct-slices" | "us-echo" | "vq-match" | "pet-glucose"
  | "bronchoscope" | "spirometry" | "oximeter" | "abg-panel" | "pleural-tap" | "abrams"
  | "breath-3" | "type1-type2" | "vq-mismatch" | "hypovent-chain" | "cyanosis-o2" | "hypercapnia-brain" | "o2-copd"
  | "edema-compare" | "ards-cascade" | "peep" | "ippv" | "o2-timer" | "ards-phases" | "pf-ratio" | "mof";

export type ThreeName = "lungs" | "alveolus" | "ctgantry" | "pet" | "bronchtree" | "gas";

export type GameName = "triage-rush" | "vent-rescue" | "invest-match" | "chain-hunt" | "pleural-tap" | "ards-cause-catch";

export type Block =
  | { k: "lead"; text: L }
  | { k: "p"; text: L }
  | { k: "explain"; icon?: string; title: L; body: L; tone?: "mint" | "sand" | "sky" | "rose" | "lilac" }
  | { k: "list"; title?: L; items: L[]; check?: boolean; ordered?: boolean }
  | { k: "callout"; tone: "tip" | "exam" | "warn" | "def" | "memory" | "confuse"; title: L; body: L }
  | { k: "table"; title?: L; head: L[]; rows: L[][] }
  | { k: "images"; items: Img[] }
  | { k: "video"; items: Video[] }
  | { k: "anim"; name: AnimName; title: L; caption: L }
  | { k: "three"; name: ThreeName; title: L; caption: L }
  | { k: "game"; name: GameName; title: L; caption: L }
  | { k: "disease"; items: { name: string; icon?: string; what: L; cause?: L; sign?: L; why?: L }[] }
  | { k: "compare"; a: { title: L; points: L[] }; b: { title: L; points: L[] }; title?: L }
  | { k: "steps"; title?: L; items: { title: L; body: L }[] }
  | { k: "chips"; title?: L; items: { term: string; meaning: L }[] }
  | { k: "flow"; title?: L; items: L[] }
  | { k: "stats"; items: { value: string; label: L; tone?: string }[] }
  | { k: "past"; ids: string[] }
  | { k: "confuse"; items: { a: string; b: string; how: L }[] };

export type Section = { id: string; icon: string; title: L; blocks: Block[] };
export type Lecture = {
  id: string; num: number; title: L; lecturer: string; color: string; emoji: string;
  summary: L; objectives: L[]; sections: Section[];
};

export type Mcq = { id: string; lec: number; q: L; options: L[]; answer: number; why: L; img?: Img };
export type Flash = { id: string; lec: number; front: L; back: L };
export type Past = {
  id: string; lec: number; year?: string; q: L; options?: L[]; answer: number | string; why: L; img?: Img; type: "mcq" | "short";
};
