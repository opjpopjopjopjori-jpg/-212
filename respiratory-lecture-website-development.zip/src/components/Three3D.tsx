import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import type { ThreeName } from "../types";
import { useStore } from "../store";

type Built = { update: (t: number, mode: string) => void; camPos?: [number, number, number] };
const mat = (c: number, o = 1, e = 0) => new THREE.MeshStandardMaterial({ color: c, transparent: o < 1, opacity: o, roughness: 0.55, metalness: 0.05, emissive: e ? c : 0x000000, emissiveIntensity: e });

function branch(group: THREE.Group, start: THREE.Vector3, dir: THREE.Vector3, len: number, rad: number, depth: number, m: THREE.Material, tips: THREE.Vector3[], path?: THREE.Vector3[][], cur: THREE.Vector3[] = []) {
  const end = start.clone().add(dir.clone().multiplyScalar(len));
  const geo = new THREE.CylinderGeometry(rad * 0.75, rad, len, 10);
  const mesh = new THREE.Mesh(geo, m);
  mesh.position.copy(start.clone().add(end).multiplyScalar(0.5));
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
  group.add(mesh);
  const here = [...cur, end];
  if (depth === 0) { tips.push(end); path?.push(here); return; }
  const axis = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), depth * 1.3);
  for (const s of [-1, 1]) {
    const nd = dir.clone().applyAxisAngle(axis, s * (0.42 + depth * 0.04)).normalize();
    branch(group, end, nd, len * 0.74, rad * 0.68, depth - 1, m, tips, path, here);
  }
}

function lungShape(side: number, m: THREE.Material) {
  const g = new THREE.SphereGeometry(1, 40, 40);
  const p = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    x *= 0.62; y *= 1.15; z *= 0.75;
    if (x * side < -0.18) x = -0.18 * side + (x + 0.18 * side) * 0.35; // flat medial surface
    if (y < -0.7) y = -0.7 + (y + 0.7) * 0.3; // flat base
    const taper = 1 - Math.max(0, y) * 0.35; x *= taper; z *= taper;
    p.setXYZ(i, x, y, z);
  }
  g.computeVertexNormals();
  const mesh = new THREE.Mesh(g, m); mesh.position.x = side * 0.78; return mesh;
}

function build(name: ThreeName, scene: THREE.Scene): Built {
  if (name === "lungs" || name === "bronchtree") {
    const root = new THREE.Group(); scene.add(root);
    const lungM = mat(0xf2a9a0, name === "lungs" ? 0.38 : 0.16);
    const L = lungShape(-1, lungM), Rr = lungShape(1, lungM); root.add(L, Rr);
    const tree = new THREE.Group(); root.add(tree);
    const tm = mat(0xf3efe6);
    const tips: THREE.Vector3[] = []; const paths: THREE.Vector3[][] = [];
    const trTop = new THREE.Vector3(0, 1.9, 0), carina = new THREE.Vector3(0, 0.75, 0);
    const tr = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, trTop.y - carina.y, 14), tm); tr.position.y = (trTop.y + carina.y) / 2; tree.add(tr);
    branch(tree, carina, new THREE.Vector3(-0.75, -0.75, 0).normalize(), 0.6, 0.09, 4, tm, tips, paths, [trTop, carina]);
    branch(tree, carina, new THREE.Vector3(0.7, -0.8, 0).normalize(), 0.6, 0.09, 4, tm, tips, paths, [trTop, carina]);
    const alvM = mat(0xe58b8b, 0.9);
    const alvs: THREE.Mesh[] = [];
    tips.forEach((tp) => { for (let k = 0; k < 3; k++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 10), alvM); s.position.copy(tp).add(new THREE.Vector3((Math.random() - .5) * .12, (Math.random() - .5) * .12, (Math.random() - .5) * .12)); tree.add(s); alvs.push(s); } });
    let tip: THREE.Mesh | null = null; let light: THREE.PointLight | null = null;
    const pathPts = paths[5] ?? paths[0];
    const curve = new THREE.CatmullRomCurve3(pathPts);
    if (name === "bronchtree") {
      tip = new THREE.Mesh(new THREE.SphereGeometry(0.07, 16, 16), mat(0xfff2a8, 1, 1.4)); root.add(tip);
      light = new THREE.PointLight(0xfff2a8, 3, 1.5); root.add(light);
      const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 80, 0.025, 8), mat(0x333333)); root.add(tube);
      tube.visible = false; (root.userData as { tube: THREE.Mesh }).tube = tube;
    }
    return {
      camPos: [0, 0.6, 4.6],
      update: (t, mode) => {
        const amp = mode === "hypo" ? 0.015 : 0.06; const sp = mode === "hypo" ? 0.6 : 1.1;
        const s = 1 + Math.sin(t * sp) * amp; L.scale.set(s, s, s); Rr.scale.set(s, s, s);
        alvs.forEach((a, i) => { const k = 1 + Math.sin(t * sp + i) * amp * 3; a.scale.set(k, k, k); });
        if (tip && light) {
          const u = (t * 0.12) % 1; const p = curve.getPointAt(u); tip.position.copy(p); light.position.copy(p);
          const tube = (root.userData as { tube: THREE.Mesh }).tube; tube.visible = true;
          tube.geometry.dispose(); tube.geometry = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(curve.getSpacedPoints(60).slice(0, Math.max(2, Math.floor(u * 60)))), 40, 0.022, 6);
        }
      },
    };
  }
  if (name === "alveolus") {
    const root = new THREE.Group(); scene.add(root);
    const sacs: THREE.Mesh[] = []; const fluid: THREE.Mesh[] = [];
    const pos = [[0, 0, 0], [0.9, 0.3, 0], [-0.9, 0.3, 0], [0.45, -0.75, 0.3], [-0.45, -0.75, 0.3], [0, 0.9, -0.4], [0, -0.1, 0.9]];
    pos.forEach(([x, y, z]) => {
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.55, 32, 32), mat(0xbfe1f2, 0.35)); s.position.set(x, y, z); root.add(s); sacs.push(s);
      const f = new THREE.Mesh(new THREE.SphereGeometry(0.5, 24, 24), mat(0xf0cf63, 0.75)); f.position.set(x, y, z); f.scale.setScalar(0.01); root.add(f); fluid.push(f);
    });
    const duct = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 1.2, 16), mat(0xbfe1f2, 0.5)); duct.position.set(0, 1.6, -0.2); root.add(duct);
    const capM = mat(0xd9534f, 0.95);
    const caps: THREE.Mesh[] = [];
    pos.forEach(([x, y, z], i) => { const c = new THREE.Mesh(new THREE.TorusGeometry(0.58, 0.04, 8, 40), capM); c.position.set(x, y, z); c.rotation.set(i * 0.7, i * 1.1, 0); root.add(c); caps.push(c); });
    const parts: { m: THREE.Mesh; v: THREE.Vector3; home: THREE.Vector3; kind: string }[] = [];
    for (let i = 0; i < 70; i++) {
      const kind = i < 40 ? "o2" : i < 60 ? "leak" : "neut";
      const m = new THREE.Mesh(new THREE.SphereGeometry(kind === "neut" ? 0.07 : 0.035, 8, 8), kind === "o2" ? mat(0x4f8fe0, 1, .3) : kind === "leak" ? mat(0xf0b429, 1, .4) : mat(0xf5f5f5, 1, .2));
      const home = new THREE.Vector3(...(pos[i % pos.length] as [number, number, number]));
      m.position.copy(home).add(new THREE.Vector3().randomDirection().multiplyScalar(0.3)); root.add(m);
      parts.push({ m, v: new THREE.Vector3().randomDirection().multiplyScalar(0.01), home, kind });
    }
    let level = 0;
    return {
      camPos: [0, 0.4, 4.2],
      update: (t, mode) => {
        const ards = mode === "ards";
        level += ((ards ? 1 : 0) - level) * 0.01;
        sacs.forEach((s, i) => { const k = (1 + Math.sin(t * 1.2 + i * 0.3) * 0.05 * (1 - level)) * (1 - level * 0.12); s.scale.setScalar(k); (s.material as THREE.MeshStandardMaterial).color.setHex(ards ? 0xd8d0b0 : 0xbfe1f2); });
        fluid.forEach((f) => f.scale.setScalar(Math.max(0.01, level * 0.95)));
        caps.forEach((c) => { (c.material as THREE.MeshStandardMaterial).opacity = 0.95; c.scale.setScalar(1 + level * 0.06 * Math.sin(t * 6)); });
        parts.forEach((p) => {
          p.m.visible = p.kind === "o2" ? true : ards;
          if (p.kind === "o2") (p.m.material as THREE.MeshStandardMaterial).opacity = 1 - level * 0.7;
          p.m.position.add(p.v);
          if (p.m.position.distanceTo(p.home) > 0.45) { p.v.negate(); p.m.position.lerp(p.home, 0.1); }
          if (Math.random() < 0.02) p.v.randomDirection().multiplyScalar(p.kind === "leak" ? 0.014 : 0.01);
        });
      },
    };
  }
  if (name === "ctgantry") {
    const root = new THREE.Group(); scene.add(root);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.25, 0.32, 24, 80), mat(0xf4f1ea)); root.add(ring);
    const rot = new THREE.Group(); root.add(rot);
    const tube = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.3, 0.4), mat(0xe8c26a)); tube.position.y = 1.25; rot.add(tube);
    const det = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.12, 0.4), mat(0x6f8fc9)); det.position.y = -1.2; rot.add(det);
    const beam = new THREE.Mesh(new THREE.ConeGeometry(0.42, 2.2, 24, 1, true), new THREE.MeshBasicMaterial({ color: 0xfff1a8, transparent: true, opacity: 0.22, side: THREE.DoubleSide })); beam.rotation.x = Math.PI; rot.add(beam);
    const table = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 4), mat(0xbcc6cc)); table.position.set(0, -0.55, 0.8); root.add(table);
    const patient = new THREE.Group(); root.add(patient);
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 1.6, 8, 16), mat(0xf1d1bc)); body.rotation.x = Math.PI / 2; body.position.y = -0.22; patient.add(body);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 16, 16), mat(0xf1d1bc)); head.position.set(0, -0.2, -1.15); patient.add(head);
    const slices = new THREE.Group(); slices.position.set(2.4, 0, 0); root.add(slices);
    for (let i = 0; i < 10; i++) { const s = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.03, 32), mat(i % 2 ? 0x8a9aa6 : 0x5d6d78, 0.9)); s.rotation.z = Math.PI / 2; s.rotation.y = Math.PI / 2; s.position.z = -1 + i * 0.22; s.visible = false; slices.add(s); }
    return {
      camPos: [3.2, 1.8, 4.2],
      update: (t) => {
        rot.rotation.z = t * 3;
        const u = (t * 0.12) % 1; patient.position.z = 1.4 - u * 2.8;
        slices.children.forEach((s, i) => (s.visible = i < Math.floor(u * 11)));
      },
    };
  }
  if (name === "pet") {
    const root = new THREE.Group(); scene.add(root);
    const skin = mat(0x9fb8c9, 0.22);
    const add = (g: THREE.BufferGeometry, x: number, y: number, z = 0, rz = 0) => { const m = new THREE.Mesh(g, skin); m.position.set(x, y, z); m.rotation.z = rz; root.add(m); return m; };
    add(new THREE.SphereGeometry(0.32, 24, 24), 0, 1.85);
    add(new THREE.CapsuleGeometry(0.5, 1.1, 8, 20), 0, 0.75);
    add(new THREE.CapsuleGeometry(0.13, 1.0, 6, 12), -0.75, 0.75, 0, 0.18); add(new THREE.CapsuleGeometry(0.13, 1.0, 6, 12), 0.75, 0.75, 0, -0.18);
    add(new THREE.CapsuleGeometry(0.17, 1.2, 6, 12), -0.25, -0.75); add(new THREE.CapsuleGeometry(0.17, 1.2, 6, 12), 0.25, -0.75);
    const spots = [[0.2, 1.05, 0.15, 0.13], [-0.15, 0.55, 0.2, 0.08], [0.3, 0.35, 0.1, 0.07], [-0.25, -0.6, 0.05, 0.07]].map(([x, y, z, r]) => { const m = new THREE.Mesh(new THREE.SphereGeometry(r, 20, 20), mat(0xff7a3d, 1, 1.2)); m.position.set(x, y, z); root.add(m); return m; });
    const brain = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 16), mat(0xffb36b, 0.8, 0.6)); brain.position.set(0, 1.9, 0); root.add(brain);
    const parts = Array.from({ length: 90 }).map(() => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), mat(0xffe066, 1, 1)); root.add(m); return { m, target: spots[Math.floor(Math.random() * spots.length)], s: Math.random() }; });
    return {
      camPos: [0, 0.6, 4.4],
      update: (t) => {
        spots.forEach((s, i) => s.scale.setScalar(1 + 0.25 * Math.sin(t * 3 + i)));
        parts.forEach((p) => {
          const u = (t * 0.25 + p.s) % 1; const start = new THREE.Vector3(-0.85, 0.3, 0);
          p.m.position.lerpVectors(start, p.target.position, u).add(new THREE.Vector3(Math.sin(u * 9 + p.s * 20) * 0.15 * (1 - u), Math.cos(u * 7 + p.s * 13) * 0.15 * (1 - u), 0));
        });
      },
    };
  }
  // gas exchange
  const root = new THREE.Group(); scene.add(root);
  const alv = new THREE.Mesh(new THREE.SphereGeometry(1.2, 40, 40, 0, Math.PI * 2, 0, Math.PI / 2), mat(0xbfe1f2, 0.3)); alv.position.y = -0.2; root.add(alv);
  const memb = new THREE.Mesh(new THREE.CylinderGeometry(1.25, 1.25, 0.06, 48), mat(0xe6a5a0, 0.7)); memb.position.y = -0.22; root.add(memb);
  const vessel = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 3.4, 24, 1, true), new THREE.MeshStandardMaterial({ color: 0xd9534f, transparent: true, opacity: 0.35, side: THREE.DoubleSide })); vessel.rotation.z = Math.PI / 2; vessel.position.y = -0.65; root.add(vessel);
  const rbcs = Array.from({ length: 10 }).map((_, i) => { const m = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.06, 8, 16), mat(0x6a4fa0)); m.position.set(-1.7 + i * 0.34, -0.65, 0); m.rotation.y = Math.PI / 2; root.add(m); return m; });
  const o2 = Array.from({ length: 26 }).map(() => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 10), mat(0x4f8fe0, 1, .4)); root.add(m); return { m, s: Math.random(), x: (Math.random() - 0.5) * 2, z: (Math.random() - 0.5) * 1.2 }; });
  const co2 = Array.from({ length: 18 }).map(() => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 10), mat(0xf08a3c, 1, .4)); root.add(m); return { m, s: Math.random(), x: (Math.random() - 0.5) * 2, z: (Math.random() - 0.5) * 0.4 }; });
  return {
    camPos: [0, 0.8, 3.6],
    update: (t) => {
      rbcs.forEach((r) => { r.position.x += 0.01; if (r.position.x > 1.7) r.position.x = -1.7; const c = r.position.x > -0.2 ? 0xd23b3b : 0x6a4fa0; (r.material as THREE.MeshStandardMaterial).color.setHex(c); });
      o2.forEach((p) => { const u = (t * 0.2 + p.s) % 1; p.m.position.set(p.x, 0.9 - u * 1.55, p.z); });
      co2.forEach((p) => { const u = (t * 0.2 + p.s) % 1; p.m.position.set(p.x, -0.65 + u * 1.55, p.z); });
    },
  };
}

export function ThreeModel({ name }: { name: ThreeName }) {
  const { ui } = useStore();
  const ref = useRef<HTMLDivElement>(null);
  const modeRef = useRef("normal");
  const [mode, setMode] = useState("normal");
  const [visible, setVisible] = useState(false);
  useEffect(() => { modeRef.current = mode; }, [mode]);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), { threshold: 0.05 });
    io.observe(el); return () => io.disconnect();
  }, []);
  useEffect(() => {
    const el = ref.current; if (!el || !visible) return;
    const w = el.clientWidth, h = el.clientHeight;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio)); renderer.setSize(w, h); el.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    scene.add(new THREE.HemisphereLight(0xffffff, 0xd8cbb5, 1.6));
    const dl = new THREE.DirectionalLight(0xffffff, 1.4); dl.position.set(3, 4, 5); scene.add(dl);
    const built = build(name, scene);
    const cam = new THREE.PerspectiveCamera(45, w / h, 0.1, 100); cam.position.set(...(built.camPos ?? [0, 0, 5]));
    const ctl = new OrbitControls(cam, renderer.domElement); ctl.enableDamping = true; ctl.autoRotate = true; ctl.autoRotateSpeed = 1.2; ctl.enablePan = false; ctl.minDistance = 2; ctl.maxDistance = 9;
    let raf = 0; const clock = new THREE.Clock();
    const loop = () => { raf = requestAnimationFrame(loop); built.update(clock.getElapsedTime(), modeRef.current); ctl.update(); renderer.render(scene, cam); };
    loop();
    const ro = new ResizeObserver(() => { const W = el.clientWidth, H = el.clientHeight; renderer.setSize(W, H); cam.aspect = W / H; cam.updateProjectionMatrix(); });
    ro.observe(el);
    return () => {
      cancelAnimationFrame(raf); ro.disconnect(); ctl.dispose();
      scene.traverse((o) => { const m = o as THREE.Mesh; if (m.geometry) m.geometry.dispose(); const mm = m.material as THREE.Material | undefined; mm?.dispose?.(); });
      renderer.dispose(); el.removeChild(renderer.domElement);
    };
  }, [name, visible]);
  const modes: Partial<Record<ThreeName, [string, string][]>> = {
    lungs: [["normal", ui("تنفس طبيعي", "Normal breathing")], ["hypo", ui("نقص تهوية", "Hypoventilation")]],
    alveolus: [["normal", ui("سنخ طبيعي", "Normal alveolus")], ["ards", "ARDS"]],
  };
  const legend: Partial<Record<ThreeName, string>> = {
    alveolus: ui("🔵 O₂  🟡 سائل غني بالبروتين  ⚪ عدلات  🔴 شعيرات", "🔵 O₂  🟡 protein-rich fluid  ⚪ neutrophils  🔴 capillaries"),
    gas: ui("🔵 O₂ ينزل للدم  🟠 CO₂ يصعد للسنخ  الكريات: بنفسجي ← أحمر", "🔵 O₂ down to blood  🟠 CO₂ up to alveolus  RBC: purple → red"),
    pet: ui("🟡 غلوكوز مشع  🟠 بؤر ورمية تضوي", "🟡 radio-glucose  🟠 glowing tumour foci"),
    ctgantry: ui("🟡 أنبوب الأشعة  🔵 الكاشف  – الشرائح تتكون يمين", "🟡 X-ray tube  🔵 detector  – slices build on the right"),
    bronchtree: ui("💡 رأس المنظار يتقدم داخل القصبات", "💡 scope tip advancing through the bronchi"),
    lungs: ui("الشجرة القصبية داخل رئتين شفافتين – الكرات الحمراء = الأسناخ", "Bronchial tree inside translucent lungs – red beads = alveoli"),
  };
  return (
    <div>
      <div ref={ref} className="three-box"><span className="three-hint">🖐️ {ui("اسحب للتدوير • عجلة للتكبير", "Drag to rotate • scroll to zoom")}</span></div>
      <div className="flex flex-wrap gap-2 items-center justify-between mt-2">
        {modes[name] ? <div className="seg">{modes[name]!.map(([k, l]) => <button key={k} className={mode === k ? "on" : ""} onClick={() => setMode(k)}>{l}</button>)}</div> : <span />}
        <span className="text-xs text-[#7c776b]">{legend[name]}</span>
      </div>
    </div>
  );
}
