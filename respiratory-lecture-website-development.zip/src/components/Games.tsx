import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import type { GameName } from "../types";
import { useStore } from "../store";

const shuffle = <T,>(a: T[]) => [...a].sort(() => Math.random() - 0.5);
const Over = ({ title, score, onRetry, children }: { title: string; score: string; onRetry: () => void; children?: ReactNode }) => {
  const { ui } = useStore();
  return <div className="game-over animate-fade"><div className="text-4xl">🏁</div><div className="text-xl font-extrabold">{title}</div><div className="text-3xl font-black my-2">{score}</div>{children}<button className="btn-soft mt-3" onClick={onRetry}>{ui("العب مرة ثانية", "Play again")} ↻</button></div>;
};
const Start = ({ text, onStart }: { text: string; onStart: () => void }) => {
  const { ui } = useStore();
  return <div className="game-start"><p className="mb-3">{text}</p><button className="btn-soft text-lg px-6" onClick={onStart}>▶ {ui("ابدأ", "Start")}</button></div>;
};

/* 1. Triage rush – falling causes */
function TriageRush() {
  const { ui } = useStore();
  const pool: [string, string, 1 | 2][] = [
    ["ذات الرئة", "Pneumonia", 1], ["ARDS", "ARDS", 1], ["وذمة رئوية قلبية", "Cardiac pulmonary oedema", 1], ["استرواح مفاجئ", "Sudden pneumothorax", 1], ["انصباب مفاجئ", "Sudden pleural effusion", 1],
    ["أمراض رئوية ارتشاحية", "Infiltrative lung disease", 1], ["نوبة ربو حادة", "Acute asthma attack", 1], ["التهاب القصيبات الحاد", "Acute bronchiolitis", 1], ["الصمة الرئوية", "Pulmonary embolism", 1], ["التهاب الأوعية الرئوية", "Pulmonary vasculitis", 1],
    ["COPD", "COPD", 2], ["غيلان-باريه", "Guillain-Barré", 2], ["شلل الأطفال", "Poliomyelitis", 2], ["الوهن العضلي", "Myasthenia gravis", 2], ["اعتلال العضلات", "Myopathy", 2],
    ["الحداب الجنفي", "Kyphoscoliosis", 2], ["الصدر السائب", "Flail chest", 2], ["التخدير", "Anaesthesia", 2], ["جلطة دماغية", "Vascular accident (stroke)", 2], ["ورم دماغي", "Brain tumour", 2], ["نهاية النوع الأول", "End-stage type I", 2],
  ];
  const [state, setState] = useState<"start" | "play" | "over">("start");
  const [card, setCard] = useState(pool[0]);
  const [y, setY] = useState(0);
  const [score, setScore] = useState(0), [lives, setLives] = useState(3), [combo, setCombo] = useState(0);
  const [flash, setFlash] = useState<"" | "ok" | "bad">("");
  const [missed, setMissed] = useState<string[]>([]);
  const speed = 0.35 + score * 0.04;
  const next = useCallback(() => { setCard(pool[Math.floor(Math.random() * pool.length)]); setY(0); }, []); // eslint-disable-line
  useEffect(() => {
    if (state !== "play") return;
    const i = setInterval(() => setY((v) => v + speed), 16);
    return () => clearInterval(i);
  }, [state, speed]);
  useEffect(() => {
    if (state === "play" && y > 100) { setLives((l) => l - 1); setCombo(0); setFlash("bad"); setMissed((m) => [...m, `${ui(card[0], card[1])} → ${card[2] === 1 ? "Type I" : "Type II"}`]); next(); }
  }, [y, state]); // eslint-disable-line
  useEffect(() => { if (lives <= 0) setState("over"); }, [lives]);
  useEffect(() => { if (!flash) return; const t = setTimeout(() => setFlash(""), 300); return () => clearTimeout(t); }, [flash]);
  const answer = (k: 1 | 2) => {
    if (state !== "play") return;
    if (k === card[2]) { setScore((s) => s + 1 + Math.floor(combo / 3)); setCombo((c) => c + 1); setFlash("ok"); }
    else { setLives((l) => l - 1); setCombo(0); setFlash("bad"); setMissed((m) => [...m, `${ui(card[0], card[1])} → ${card[2] === 1 ? "Type I" : "Type II"}`]); }
    next();
  };
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === "ArrowLeft") answer(1); if (e.key === "ArrowRight") answer(2); }; window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); });
  const reset = () => { setScore(0); setLives(3); setCombo(0); setMissed([]); next(); setState("play"); };
  if (state === "start") return <Start text={ui("سبب مرضي ينزل من فوق – صنّفه للنوع الأول أو الثاني قبل ما يوصل للأرض. السرعة تزيد مع كل نقطة!", "A cause falls from above – classify it as type I or II before it lands. Speed rises with every point!")} onStart={reset} />;
  if (state === "over") return <Over title={ui("انتهت الأرواح!", "Out of lives!")} score={`${score} ⭐`} onRetry={reset}>{missed.length > 0 && <div className="text-sm text-start mt-2 max-h-32 overflow-auto"><b>{ui("راجع:", "Review:")}</b>{missed.map((m, i) => <div key={i}>• {m}</div>)}</div>}</Over>;
  return (
    <div className={"game-field rain " + flash}>
      <div className="game-hud"><span>⭐ {score}</span><span>{"❤️".repeat(Math.max(0, lives))}</span><span>🔥 x{combo}</span></div>
      <div className="rain-card" style={{ top: `${y * 0.72}%` }}>{ui(card[0], card[1])}</div>
      <div className="rain-floor" />
      <div className="rain-bins">
        <button onClick={() => answer(1)} className="bin bin1">⬅ Type I<small>V/Q mismatch</small></button>
        <button onClick={() => answer(2)} className="bin bin2">Type II ➡<small>Hypoventilation</small></button>
      </div>
    </div>
  );
}

/* 2. Ventilator rescue */
function VentRescue() {
  const { ui } = useStore();
  const [state, setState] = useState<"start" | "play" | "over">("start");
  const [fio2, setF] = useState(60), [peep, setP] = useState(5);
  const [hour, setHour] = useState(0), [sev, setSev] = useState(1), [tox, setTox] = useState(0), [score, setScore] = useState(0);
  const [log, setLog] = useState<string[]>([]);
  const [result, setResult] = useState("");
  const [lowH, setLowH] = useState(0);
  const recruit = Math.min(1, peep / 12);
  const baro = peep > 15 ? (peep - 15) * 0.06 : 0;
  const spo2 = Math.round(Math.max(60, Math.min(99, 76 + (fio2 - 21) * 0.32 + recruit * 16 - sev * 8 - Math.max(0, tox - 24) * 0.6)));
  const bp = Math.round(110 - Math.max(0, peep - 12) * 4);
  useEffect(() => {
    if (state !== "play") return;
    const i = setInterval(() => {
      setHour((h) => h + 1);
      setTox((t) => (fio2 >= 90 ? t + 1 : Math.max(0, t - 0.5)));
      setSev((s) => Math.max(0.4, Math.min(2.4, s + (Math.random() - 0.45) * 0.12)));
      setScore((sc) => sc + (spo2 >= 90 ? 2 : spo2 >= 88 ? 1 : 0));
      setLowH((n) => (spo2 < 82 ? n + 1 : 0));
      if (Math.random() < 0.08) { setSev((s) => s + 0.5); setLog((l) => [ui("⚠️ عدوى بكتيرية إضافية! الأكسجة ساءت", "⚠️ Bacterial super-infection! Oxygenation worse"), ...l].slice(0, 5)); }
    }, 1100);
    return () => clearInterval(i);
  }, [state, fio2, spo2, ui]);
  useEffect(() => {
    if (state !== "play") return;
    if (lowH >= 3) { setResult(ui("💔 التشبع بقى تحت 82% لـ 3 ساعات – المريض انهار", "💔 SpO₂ stayed below 82% for 3 hours – the patient collapsed")); setState("over"); }
    else if (bp < 80) { setResult(ui("💔 PEEP عالي جداً – هبط الضغط", "💔 PEEP too high – blood pressure crashed")); setState("over"); }
    else if (hour >= 72) { setResult(ui("🎉 المريض نجا من المرحلة الحادة (72 ساعة)!", "🎉 The patient survived the acute phase (72 h)!")); setState("over"); }
  }, [lowH, bp, hour, state, ui]);
  useEffect(() => { if (state === "play" && tox === 25) setLog((l) => [ui("☠️ تجاوزت 24 ساعة على أوكسجين نقي – تلف رئوي يبدأ!", "☠️ Over 24 h on pure O₂ – lung injury begins!"), ...l].slice(0, 5)); }, [tox, state, ui]);
  useEffect(() => { if (baro > 0.2 && state === "play") setLog((l) => [ui("⚠️ خطر رضح ضغطي (Barotrauma)", "⚠️ Barotrauma risk"), ...l].slice(0, 5)); }, [baro > 0.2]); // eslint-disable-line
  const reset = () => { setF(60); setP(5); setHour(0); setSev(1); setTox(0); setScore(0); setLog([]); setResult(""); setLowH(0); setState("play"); };
  if (state === "start") return <Start text={ui("مريض ARDS بالعناية بعد صدمة إنتانية. اضبط FiO₂ و PEEP حتى يبقى SpO₂ ≥ 90% لمدة 72 ساعة. انتبه: أوكسجين ≥90% لأكثر من 24 ساعة = سمية، و PEEP عالي جداً يهبط الضغط!", "ARDS patient in ICU after septic shock. Tune FiO₂ and PEEP to keep SpO₂ ≥ 90% for 72 h. Beware: O₂ ≥90% for >24 h = toxicity, and very high PEEP drops BP!")} onStart={reset} />;
  if (state === "over") return <Over title={result} score={`${score} ⭐ · ${hour}h`} onRetry={reset}><div className="text-sm">{ui("الدرس: أوكسجين Liberal بدون نقي > 24 ساعة + PEEP يبقي الأسناخ مفتوحة.", "Lesson: liberal O₂ but not pure > 24 h + PEEP keeps alveoli open.")}</div></Over>;
  return (
    <div className="vent">
      <div className="vent-monitor">
        <div className={"vm " + (spo2 < 88 ? "alarm" : "")}><span>SpO₂</span><b>{spo2}%</b></div>
        <div className={"vm " + (bp < 90 ? "alarm" : "")}><span>BP</span><b>{bp}/{Math.round(bp * 0.6)}</b></div>
        <div className="vm"><span>{ui("الساعة", "Hour")}</span><b>{hour}/72</b></div>
        <div className={"vm " + (tox > 24 ? "alarm" : "")}><span>{ui("ساعات O₂ نقي", "Pure-O₂ h")}</span><b>{Math.floor(tox)}</b></div>
      </div>
      <div className="grid md:grid-cols-2 gap-4 mt-3">
        <label className="slider big"><span>FiO₂ <b dir="ltr">{fio2}%</b></span><input type="range" min={21} max={100} value={fio2} onChange={(e) => setF(+e.target.value)} /></label>
        <label className="slider big"><span>PEEP <b dir="ltr">{peep} cmH₂O</b></span><input type="range" min={0} max={20} value={peep} onChange={(e) => setP(+e.target.value)} /></label>
      </div>
      <div className="vent-log">{log.length ? log.map((l, i) => <div key={i}>{l}</div>) : <div className="opacity-60">{ui("سجل الأحداث...", "Event log…")}</div>}</div>
    </div>
  );
}

/* 3. Investigation match */
function InvestMatch() {
  const { ui } = useStore();
  const rounds: [string, string, number, [string, string][]][] = [
    ["كحة 3 أسابيع، تعرق ليلي، نقص وزن", "Cough 3 weeks, night sweats, weight loss", 0, [["بصاق ZN (AFB)", "Sputum ZN (AFB)"], ["PET", "PET"], ["Spirometry", "Spirometry"], ["V/Q", "V/Q"]]],
    ["مدخن، نفث دم، شك بسرطان القصبات", "Smoker, hemoptysis, suspected bronchial cancer", 1, [["Oximetry", "Oximetry"], ["Cytology + Bronchoscopy", "Cytology + bronchoscopy"], ["Ultrasound", "Ultrasound"], ["ABG", "ABG"]]],
    ["سرطان رئة معروف – هل انتشر؟", "Known lung cancer – has it spread?", 2, [["Sputum culture", "Sputum culture"], ["Laryngoscopy", "Laryngoscopy"], ["PET", "PET"], ["Spirometry", "Spirometry"]]],
    ["أصمية صخرية أسفل الصدر – سائل؟", "Stony dullness at the base – fluid?", 3, [["PET", "PET"], ["V/Q", "V/Q"], ["Oximetry", "Oximetry"], ["Ultrasound", "Ultrasound"]]],
    ["ضيق نفس مفاجئ بعد DVT", "Sudden SOB after DVT", 0, [["CTPA (بدل V/Q)", "CTPA (replaced V/Q)"], ["Sputum", "Sputum"], ["Abram biopsy", "Abram biopsy"], ["Laryngoscopy", "Laryngoscopy"]]],
    ["صفير متكرر – نريد نثبت الانسداد", "Recurrent wheeze – prove obstruction", 1, [["CT", "CT"], ["Spirometry (FEV1/FVC)", "Spirometry (FEV1/FVC)"], ["PET", "PET"], ["Thoracoscopy", "Thoracoscopy"]]],
    ["مريض COPD نعسان – شنو الـ CO₂؟", "Drowsy COPD patient – what's the CO₂?", 2, [["Oximetry", "Oximetry"], ["CXR", "CXR"], ["ABG", "ABG"], ["Ultrasound", "Ultrasound"]]],
    ["انصباب نضحي غير مشخص – نريد نسيج", "Undiagnosed exudate – need tissue", 3, [["Spirometry", "Spirometry"], ["Oximetry", "Oximetry"], ["V/Q", "V/Q"], ["Abram needle / Thoracoscopy", "Abram needle / thoracoscopy"]]],
    ["كتلة رئوية طرفية تحتاج خزعة", "Peripheral lung mass needs biopsy", 0, [["CT-guided biopsy", "CT-guided biopsy"], ["Laryngoscopy", "Laryngoscopy"], ["ABG", "ABG"], ["Spirometry", "Spirometry"]]],
    ["عقد لمفاوية منصفية متضخمة", "Enlarged mediastinal lymph nodes", 1, [["Oximetry", "Oximetry"], ["Mediastinoscopy", "Mediastinoscopy"], ["Ultrasound", "Ultrasound"], ["Sputum", "Sputum"]]],
    ["بحة صوت مستمرة", "Persistent hoarseness", 2, [["PET", "PET"], ["V/Q", "V/Q"], ["Laryngoscopy", "Laryngoscopy"], ["Abram needle", "Abram needle"]]],
  ];
  const [state, setState] = useState<"start" | "play" | "over">("start");
  const [order, setOrder] = useState(rounds);
  const [i, setI] = useState(0), [score, setScore] = useState(0), [combo, setCombo] = useState(0), [time, setTime] = useState(100);
  const [pick, setPick] = useState<number | null>(null);
  useEffect(() => {
    if (state !== "play" || pick !== null) return;
    const t = setInterval(() => setTime((v) => v - 1.25), 100);
    return () => clearInterval(t);
  }, [state, pick, i]);
  useEffect(() => { if (time <= 0 && pick === null && state === "play") { setPick(-1); setCombo(0); } }, [time, pick, state]);
  const choose = (k: number) => { if (pick !== null) return; setPick(k); if (k === order[i][2]) { setScore((s) => s + 10 + combo * 5 + Math.round(time / 10)); setCombo((c) => c + 1); } else setCombo(0); };
  const next = () => { if (i + 1 >= order.length) setState("over"); else { setI(i + 1); setPick(null); setTime(100); } };
  const reset = () => { setOrder(shuffle(rounds)); setI(0); setScore(0); setCombo(0); setTime(100); setPick(null); setState("play"); };
  if (state === "start") return <Start text={ui("مرضى يوصلون للطوارئ! لكل مريض 8 ثواني تختار الفحص الأنسب. الأسرع = نقاط أكثر، والسلسلة تضاعف.", "Patients arrive at the ER! 8 seconds each to choose the best test. Faster = more points, streaks multiply.")} onStart={reset} />;
  if (state === "over") return <Over title={ui("انتهت المناوبة!", "Shift over!")} score={`${score} ⭐`} onRetry={reset} />;
  const r = order[i];
  return (
    <div className="game-field er">
      <div className="game-hud"><span>🧑‍⚕️ {i + 1}/{order.length}</span><span>⭐ {score}</span><span>🔥 x{combo}</span></div>
      <div className="timebar"><div style={{ width: `${Math.max(0, time)}%`, background: time < 30 ? "#e07a6a" : "#7fb39b" }} /></div>
      <div className="er-patient">🛏️ {ui(r[0], r[1])}</div>
      <div className="fill-grid tight">{r[3].map((o, k) => <button key={k} onClick={() => choose(k)} className={"opt " + (pick === null ? "" : k === r[2] ? "right" : k === pick ? "wrong" : "dim")}>{ui(o[0], o[1])}</button>)}</div>
      {pick !== null && <div className="text-center mt-3"><button className="btn-soft" onClick={next}>{ui("المريض التالي", "Next patient")} ›</button></div>}
    </div>
  );
}

/* 4. Chain hunt */
function ChainHunt() {
  const { ui } = useStore();
  const links = [["🧠", ui("مركز التنفس", "Centre")], ["⚡", ui("الأعصاب", "Nerves")], ["💪", ui("العضلات", "Muscles")], ["🦴", ui("القفص", "Cage")], ["🫁", ui("الرئة/المجاري", "Lung/airways")]];
  const ds: [string, string, number][] = [["جرعة مورفين زائدة", "Opiate overdose", 0], ["التخدير العام", "General anaesthesia", 0], ["رضة رأس", "Head trauma", 0], ["جلطة جذع الدماغ", "Brainstem stroke", 0], ["ورم دماغي", "Brain tumour", 0],
    ["غيلان-باريه", "Guillain-Barré", 1], ["شلل الأطفال", "Poliomyelitis", 1], ["إصابة العصب الحجابي", "Phrenic nerve injury", 1],
    ["الوهن العضلي", "Myasthenia gravis", 2], ["اعتلال عضلي", "Myopathy", 2], ["الحداب الجنفي", "Kyphoscoliosis", 3], ["الصدر السائب", "Flail chest", 3], ["COPD", "COPD", 4]];
  const [state, setState] = useState<"start" | "play" | "over">("start");
  const [cur, setCur] = useState(ds[0]); const [co2, setCo2] = useState(40); const [score, setScore] = useState(0); const [fb, setFb] = useState<number | null>(null);
  useEffect(() => { if (state !== "play") return; const t = setInterval(() => setCo2((c) => c + 0.35 + score * 0.03), 100); return () => clearInterval(t); }, [state, score]);
  useEffect(() => { if (co2 >= 90 && state === "play") setState("over"); }, [co2, state]);
  const hit = (k: number) => { if (k === cur[2]) { setScore((s) => s + 1); setCo2((c) => Math.max(40, c - 14)); setFb(k); setCur(ds[Math.floor(Math.random() * ds.length)]); } else { setCo2((c) => c + 8); setFb(-1); } setTimeout(() => setFb(null), 250); };
  const reset = () => { setCo2(40); setScore(0); setCur(ds[Math.floor(Math.random() * ds.length)]); setState("play"); };
  if (state === "start") return <Start text={ui("الـ CO₂ يرتفع باستمرار! اضغط الحلقة الصحيحة لكل مرض حتى تنزله. الغلط يرفعه أكثر – لا تخليه يوصل 90 (غيبوبة)!", "CO₂ keeps rising! Tap the correct link for each disease to lower it. Mistakes push it higher – don't let it reach 90 (coma)!")} onStart={reset} />;
  if (state === "over") return <Over title={ui("CO₂ narcosis! المريض دخل غيبوبة", "CO₂ narcosis! The patient is in a coma")} score={`${score} ⭐`} onRetry={reset} />;
  return (
    <div className={"game-field " + (fb === -1 ? "bad" : "")}>
      <div className="game-hud"><span>⭐ {score}</span><span>PaCO₂ {Math.round(co2)}</span></div>
      <div className="co2-bar"><div style={{ width: `${((co2 - 40) / 50) * 100}%`, background: co2 > 75 ? "#d9534f" : "#e8b04b" }} /></div>
      <div className="er-patient text-center text-xl">🧾 {ui(cur[0], cur[1])}</div>
      <div className="chain">{links.map((l, k) => <button key={k} onClick={() => hit(k)} className={"chain-link " + (fb === k ? "ok" : "")}><span className="text-2xl">{l[0]}</span><span className="text-sm font-bold">{l[1]}</span></button>)}</div>
    </div>
  );
}

/* 5. Pleural tap */
function PleuralTapGame() {
  const { ui } = useStore();
  const [state, setState] = useState<"start" | "find" | "needle" | "over">("start");
  const [probe, setProbe] = useState(20);
  const [found, setFound] = useState(false); const [time, setTime] = useState(30); const [result, setResult] = useState("");
  const fluidZone = useRef(60);
  useEffect(() => { if (state !== "find" && state !== "needle") return; const t = setInterval(() => setTime((v) => v - 1), 1000); return () => clearInterval(t); }, [state]);
  useEffect(() => { if (time <= 0 && (state === "find" || state === "needle")) { setResult(ui("⏰ انتهى الوقت!", "⏰ Time's up!")); setState("over"); } }, [time, state, ui]);
  const inFluid = Math.abs(probe - fluidZone.current) < 12;
  const reset = () => { fluidZone.current = 45 + Math.random() * 35; setProbe(15); setFound(false); setTime(30); setResult(""); setState("find"); };
  const pickNeedle = (k: number) => {
    setResult(k === 1 ? ui("✅ ممتاز! فوق الحافة العلوية للضلع السفلي – تجنبت الوعاء والعصب. السائل يرسل للون، البروتين، الجراثيم والخلايا.", "✅ Excellent! Above the upper border of the lower rib – vessels & nerve avoided. Fluid sent for colour, protein, bacteriology, cytology.")
      : k === 0 ? ui("❌ تحت الضلع = جرحت الوعاء والعصب الوربي!", "❌ Under the rib = you hit the intercostal vessels & nerve!") : ui("❌ عميق جداً – دخلت للرئة/الكبد!", "❌ Too deep – you entered the lung/liver!"));
    setState("over");
  };
  if (state === "start") return <Start text={ui("حرّك مجس السونار على ظهر المريض حتى تلقى السائل (أسود)، بعدين اختار مكان الإبرة الآمن. عندك 30 ثانية!", "Slide the ultrasound probe along the patient's back to find the fluid (black), then choose the safe needle spot. 30 seconds!")} onStart={reset} />;
  if (state === "over") return <Over title={result} score={`⏱ ${30 - time}s`} onRetry={reset} />;
  return (
    <div className="game-field">
      <div className="game-hud"><span>⏱ {time}s</span><span>{state === "find" ? ui("ابحث عن السائل", "Find the fluid") : ui("اختار نقطة الإدخال", "Choose entry point")}</span></div>
      {state === "find" && <div className="grid md:grid-cols-2 gap-3">
        <div className="tap-back"><div className="tap-ribs" />{[...Array(6)].map((_, i) => <div key={i} className="rib" style={{ top: `${10 + i * 15}%` }} />)}<div className="tap-probe" style={{ top: `${probe}%` }}>📡</div></div>
        <div>
          <div className="us-screen"><div className="us-fan" style={{ background: inFluid ? "radial-gradient(ellipse at 50% 0%, #bdbdbd 0 20%, #050505 22% 70%, #777 72%)" : "radial-gradient(ellipse at 50% 0%, #bdbdbd 0 20%, #8a8a8a 22% 60%, #5a5a5a 62%)" }} /><span>{inFluid ? ui("سائل! (Anechoic)", "Fluid! (anechoic)") : ui("نسيج رئة/عضلة", "Lung/muscle tissue")}</span></div>
          <input type="range" min={5} max={95} value={probe} onChange={(e) => setProbe(+e.target.value)} className="w-full mt-2" />
          <button className="btn-soft w-full mt-2" disabled={!inFluid} style={{ opacity: inFluid ? 1 : 0.4 }} onClick={() => { setFound(true); setState("needle"); }}>{ui("علّم المكان هنا ✓", "Mark this spot ✓")}</button>
        </div>
      </div>}
      {state === "needle" && found && <div>
        <svg viewBox="0 0 400 160" className="w-full"><rect width="400" height="160" fill="#f6eadc" rx="12" />{[30, 120].map((y) => <g key={y}><rect x="0" y={y} width="400" height="22" rx="11" fill="#f3f0e6" stroke="#8a857a" /><circle cx="200" cy={y + 20} r="4" fill="#d16a5c" /><circle cx="214" cy={y + 20} r="4" fill="#6f8fc9" /></g>)}<rect x="0" y="60" width="400" height="50" fill="#f0d98a" opacity=".6" /><text x="200" y="90" textAnchor="middle">{ui("سائل الجنب", "Pleural fluid")}</text></svg>
        <div className="fill-grid tight mt-2">
          <button className="opt" onClick={() => pickNeedle(0)}>A — {ui("تحت الضلع العلوي مباشرة", "Just under the upper rib")}</button>
          <button className="opt" onClick={() => pickNeedle(1)}>B — {ui("فوق الحافة العلوية للضلع السفلي", "Above the upper border of the lower rib")}</button>
          <button className="opt" onClick={() => pickNeedle(2)}>C — {ui("أدخل عميقاً قدر الإمكان", "Insert as deep as possible")}</button>
        </div>
      </div>}
    </div>
  );
}

/* 6. ARDS cause catcher */
function ArdsCatch() {
  const { ui } = useStore();
  const items: [string, string, boolean][] = [
    ["صدمة إنتانية", "Septic shock", true], ["التهاب البنكرياس الحاد", "Acute pancreatitis", true], ["حروق", "Burns", true], ["الغرق", "Drowning", true], ["الشنق", "Hanging", true], ["استنشاق الكلور", "Chlorine inhalation", true],
    ["نقل دم متعدد", "Multiple transfusion", true], ["صمة دهنية", "Fat embolism", true], ["صمة سائل أمنيوسي", "Amniotic fluid embolism", true], ["استنشاق حامض المعدة", "Gastric acid aspiration", true], ["إنفلونزا H1N1", "H1N1 influenza", true],
    ["O₂ 100% > 24 ساعة", "100% O₂ > 24 h", true], ["مجازة قلبية رئوية", "Cardiopulmonary bypass", true], ["إصابة رأس", "Head injury", true], ["جراحة طويلة", "Prolonged surgery", true], ["كسور", "Fractures", true],
    ["الوهن العضلي", "Myasthenia gravis", false], ["الحداب الجنفي", "Kyphoscoliosis", false], ["ربو مزمن مستقر", "Stable chronic asthma", false], ["التهاب الجيوب", "Sinusitis", false], ["عجز القلب الأيسر", "Left heart failure", false], ["شلل الأطفال", "Poliomyelitis", false], ["فقر الدم بنقص الحديد", "Iron-deficiency anaemia", false],
  ];
  type B = { id: number; x: number; y: number; vx: number; vy: number; it: [string, string, boolean]; pop?: "ok" | "bad" };
  const [state, setState] = useState<"start" | "play" | "over">("start");
  const [bubbles, setBubbles] = useState<B[]>([]); const [score, setScore] = useState(0); const [time, setTime] = useState(40); const idRef = useRef(0);
  const spawn = useCallback(() => { const it = items[Math.floor(Math.random() * items.length)]; idRef.current++; return { id: idRef.current, x: 10 + Math.random() * 70, y: 100, vx: (Math.random() - 0.5) * 0.25, vy: -(0.25 + Math.random() * 0.3), it } as B; }, []); // eslint-disable-line
  useEffect(() => {
    if (state !== "play") return;
    const m = setInterval(() => setBubbles((bs) => { let n = bs.map((b) => ({ ...b, x: Math.max(2, Math.min(80, b.x + b.vx)), y: b.y + b.vy })).filter((b) => b.y > -15 && !b.pop); if (n.length < 5 && Math.random() < 0.08) n = [...n, spawn()]; return n; }), 30);
    const t = setInterval(() => setTime((v) => v - 1), 1000);
    return () => { clearInterval(m); clearInterval(t); };
  }, [state, spawn]);
  useEffect(() => { if (time <= 0 && state === "play") setState("over"); }, [time, state]);
  const pop = (b: B) => { if (b.it[2]) setScore((s) => s + 1); else { setScore((s) => s - 1); setTime((v) => v - 3); } setBubbles((bs) => bs.map((x) => (x.id === b.id ? { ...x, pop: b.it[2] ? "ok" : "bad" } : x))); };
  const reset = () => { setBubbles([spawn(), spawn()]); setScore(0); setTime(40); setState("play"); };
  if (state === "start") return <Start text={ui("فقاعات تطلع من تحت – انفجر فقط اللي هي من أسباب ARDS الـ13. الغلط = -1 نقطة و -3 ثواني!", "Bubbles rise from below – pop only the 13 ARDS causes. Wrong = -1 point and -3 seconds!")} onStart={reset} />;
  if (state === "over") return <Over title={ui("انتهى الوقت!", "Time's up!")} score={`${score} ⭐`} onRetry={reset} />;
  return (
    <div className="game-field bubbles">
      <div className="game-hud"><span>⭐ {score}</span><span>⏱ {time}s</span></div>
      {bubbles.map((b) => <button key={b.id} className="bubble" style={{ left: `${b.x}%`, top: `${b.y}%` }} onClick={() => pop(b)}>{ui(b.it[0], b.it[1])}</button>)}
    </div>
  );
}

const MAP: Record<GameName, () => ReactNode> = { "triage-rush": TriageRush, "vent-rescue": VentRescue, "invest-match": InvestMatch, "chain-hunt": ChainHunt, "pleural-tap": PleuralTapGame, "ards-cause-catch": ArdsCatch };
export function Game({ name }: { name: GameName }) { const C = MAP[name]; return <C />; }
