import { useState } from "react";
import type { Block, Past } from "../types";
import { useStore } from "../store";
import { Gallery, Videos, SmartImg, useLightbox } from "./ui";
import { Anim } from "./Anims";
import { ThreeModel } from "./Three3D";
import { Game } from "./Games";
import { PAST } from "../data/practice";

const TONES: Record<string, [string, string]> = {
  tip: ["💡", "#eef5f0"], exam: ["🎯", "#fbefd9"], warn: ["⚠️", "#f9e4df"], def: ["📘", "#e7eef7"], memory: ["🧠", "#efe8f6"], confuse: ["🔀", "#fdf0e6"],
};
const EXPLAIN: Record<string, string> = { mint: "#e9f4ee", sand: "#f7efdf", sky: "#e6eff8", rose: "#f8e8e6", lilac: "#efeaf7" };

export function PastCard({ p }: { p: Past }) {
  const { tr, ui, grade } = useStore();
  const [pick, setPick] = useState<number | null>(null);
  const [show, setShow] = useState(false);
  const open = useLightbox();
  const choose = (i: number) => { if (pick !== null) return; setPick(i); setShow(true); grade(p.id, i === p.answer); };
  return (
    <div className="past-card">
      <div className="flex items-center gap-2 flex-wrap mb-2">
        <span className="past-badge">📜 {ui("سؤال سنين", "Past paper")}{p.year ? ` · ${p.year}` : ""}</span>
        <span className="tag">LEC {p.lec}</span>
        <span className="tag tag-c">{p.type === "mcq" ? "MCQ" : ui("جواب قصير", "Short answer")}</span>
      </div>
      <div className="font-bold leading-relaxed">{tr(p.q)}</div>
      {p.img && <button className="past-img" onClick={() => open([p.img!], 0)}><SmartImg img={p.img} /><span>{tr(p.img.cap)}</span></button>}
      {p.options ? (
        <div className="grid gap-2 mt-3">
          {p.options.map((o, i) => (
            <button key={i} onClick={() => choose(i)} className={"opt text-start " + (pick === null ? "" : i === p.answer ? "right" : i === pick ? "wrong" : "dim")}>
              <b className="me-2">{String.fromCharCode(65 + i)}.</b>{tr(o)}
            </button>
          ))}
        </div>
      ) : (
        <button className="btn-soft mt-3" onClick={() => setShow(!show)}>{show ? ui("إخفاء الجواب", "Hide answer") : ui("اكشف الجواب", "Reveal answer")}</button>
      )}
      {show && (
        <div className="past-why animate-fade">
          {!p.options && <div className="font-bold mb-1" dir="ltr">✅ {String(p.answer)}</div>}
          <b>{ui("الشرح: ", "Explanation: ")}</b>{tr(p.why)}
        </div>
      )}
    </div>
  );
}

export function BlockView({ b, scope }: { b: Block; scope: string }) {
  const { tr, ui, isDone, toggle } = useStore();
  switch (b.k) {
    case "lead": return <p className="lead-text">{tr(b.text)}</p>;
    case "p": return <p className="leading-loose">{tr(b.text)}</p>;
    case "explain": return (
      <div className="explain" style={{ background: EXPLAIN[b.tone ?? "mint"] }}>
        <div className="explain-icon">{b.icon ?? "💬"}</div>
        <div><div className="font-extrabold text-[1.05rem] mb-1">{tr(b.title)}</div><div className="whitespace-pre-line leading-loose">{tr(b.body)}</div></div>
      </div>
    );
    case "list": {
      if (b.check) {
        const done = b.items.filter((_, i) => isDone(`${scope}/${i}`)).length;
        return (
          <div className="check-card">
            <div className="flex items-center justify-between gap-2 mb-2">
              {b.title && <div className="block-title !mb-0">✅ {tr(b.title)}</div>}
              <span className="mini-progress"><span style={{ width: `${(done / b.items.length) * 100}%` }} />{done}/{b.items.length}</span>
            </div>
            <ul className="space-y-1.5">
              {b.items.map((it, i) => {
                const k = `${scope}/${i}`; const on = isDone(k);
                return <li key={i}><button onClick={() => toggle(k)} className={"check-item " + (on ? "on" : "")}><span className="check-box">{on ? "✓" : b.ordered ? i + 1 : ""}</span><span className="check-text">{tr(it)}</span></button></li>;
              })}
            </ul>
          </div>
        );
      }
      return (
        <div className="soft-card">
          {b.title && <div className="block-title">{tr(b.title)}</div>}
          <ul className="space-y-2">{b.items.map((it, i) => <li key={i} className="flex gap-3"><span className="num-dot">{b.ordered ? i + 1 : "•"}</span><span className="leading-relaxed">{tr(it)}</span></li>)}</ul>
        </div>
      );
    }
    case "callout": { const [ic, bg] = TONES[b.tone]; return <div className="callout" style={{ background: bg }}><span className="callout-ic">{ic}</span><div><div className="font-extrabold mb-1">{tr(b.title)}</div><div className="leading-loose">{tr(b.body)}</div></div></div>; }
    case "table": return (
      <div className="soft-card overflow-x-auto">
        {b.title && <div className="block-title">📊 {tr(b.title)}</div>}
        <table className="nice-table"><thead><tr>{b.head.map((h, i) => <th key={i}>{tr(h)}</th>)}</tr></thead><tbody>{b.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{tr(c)}</td>)}</tr>)}</tbody></table>
      </div>
    );
    case "images": return <div><div className="sec-label">📷 {ui("صور حقيقية توضيحية – اضغط للتكبير", "Real illustrative images – tap to enlarge")}</div><Gallery items={b.items} /></div>;
    case "video": return <div><div className="sec-label">🎬 {ui("فيديوهات قصيرة (إنجليزي) – تفتح مباشرة", "Short videos (English) – open directly")}</div><Videos items={b.items} /></div>;
    case "anim": return <div className="anim-card"><div className="anim-head"><span className="sticker" style={{ background: "#d9ecf5" }}>🎞️</span><div><div className="font-extrabold">{tr(b.title)}</div><div className="text-sm text-[#7c776b]">{tr(b.caption)}</div></div></div><Anim name={b.name} /></div>;
    case "three": return <div className="anim-card three-card"><div className="anim-head"><span className="sticker" style={{ background: "#efe1f5" }}>🧊</span><div><div className="font-extrabold">{tr(b.title)} <span className="tag tag-b">3D</span></div><div className="text-sm text-[#7c776b]">{tr(b.caption)}</div></div></div><ThreeModel name={b.name} /></div>;
    case "game": return <div className="game-card"><div className="anim-head"><span className="sticker" style={{ background: "#fbe3c4" }}>🎮</span><div><div className="font-extrabold">{tr(b.title)}</div><div className="text-sm text-[#7c776b]">{tr(b.caption)}</div></div></div><Game name={b.name} /></div>;
    case "disease": return (
      <div className="fill-grid disease-grid">
        {b.items.map((d, i) => (
          <div key={i} className="disease-card" style={{ ["--accent" as string]: ["#7fb39b", "#8fa9c9", "#d4a373", "#c99ab8", "#e0a08f", "#9cbf8a"][i % 6] }}>
            <div className="flex items-center gap-3 mb-2"><span className="disease-icon">{d.icon ?? "🩺"}</span><div className="font-extrabold" dir="ltr">{d.name}</div></div>
            <div className="text-[0.95rem] leading-relaxed"><span className="tag">{ui("شنو هو", "What")}</span>{tr(d.what)}</div>
            {d.cause && <div className="text-[0.95rem] leading-relaxed mt-2"><span className="tag tag-b">{ui("ليش/الآلية", "Why/How")}</span>{tr(d.cause)}</div>}
            {d.sign && <div className="text-[0.95rem] leading-relaxed mt-2"><span className="tag tag-c">{ui("شلون نعرفه", "How to spot")}</span>{tr(d.sign)}</div>}
          </div>
        ))}
      </div>
    );
    case "compare": return (
      <div>
        {b.title && <div className="block-title">⚖️ {tr(b.title)}</div>}
        <div className="grid md:grid-cols-2 gap-3">
          {[b.a, b.b].map((s, i) => <div key={i} className={"compare-card " + (i ? "compare-b" : "compare-a")}><div className="font-extrabold mb-2">{tr(s.title)}</div><ul className="space-y-1.5">{s.points.map((p, j) => <li key={j} className="flex gap-2"><span>{i ? "◆" : "●"}</span><span>{tr(p)}</span></li>)}</ul></div>)}
        </div>
      </div>
    );
    case "steps": return (
      <div>
        {b.title && <div className="block-title">🪜 {tr(b.title)}</div>}
        <div className="steps-row">{b.items.map((s, i) => <div key={i} className="step"><span className="step-num">{i + 1}</span><div><div className="font-bold">{tr(s.title)}</div><div className="text-sm leading-relaxed text-[#5b5546]">{tr(s.body)}</div></div></div>)}</div>
      </div>
    );
    case "chips": return (
      <div>
        {b.title && <div className="block-title">🏷️ {tr(b.title)}</div>}
        <div className="fill-grid tight">{b.items.map((c, i) => <div key={i} className="chip"><b dir="ltr">{c.term}</b><span className="text-sm">{tr(c.meaning)}</span></div>)}</div>
      </div>
    );
    case "flow": return (
      <div className="flow">{b.items.map((f, i) => <div key={i} className="flow-item"><span className="flow-box">{tr(f)}</span>{i < b.items.length - 1 && <span className="flow-arrow">➜</span>}</div>)}</div>
    );
    case "stats": return <div className="fill-grid tight">{b.items.map((s, i) => <div key={i} className="stat"><div className="stat-v" dir="ltr">{s.value}</div><div className="text-sm">{tr(s.label)}</div></div>)}</div>;
    case "past": {
      const ps = b.ids.map((id) => PAST.find((p) => p.id === id)).filter(Boolean) as Past[];
      if (!ps.length) return null;
      return <div className="past-wrap"><div className="sec-label">📜 {ui("أسئلة سنين جاية من هذا الجزء", "Past-paper questions from this part")}</div><div className="grid gap-3">{ps.map((p) => <PastCard key={p.id} p={p} />)}</div></div>;
    }
    case "confuse": return (
      <div className="confuse-wrap">
        <div className="sec-label">🔀 {ui("لا تتلخبط بينهم!", "Don't confuse them!")}</div>
        <div className="fill-grid">{b.items.map((c, i) => <div key={i} className="confuse-card"><div className="confuse-vs"><b dir="ltr">{c.a}</b><span>VS</span><b dir="ltr">{c.b}</b></div><div className="text-sm leading-relaxed">{tr(c.how)}</div></div>)}</div>
      </div>
    );
  }
}

export const countChecks = (blocks: Block[]) => blocks.reduce((n, b) => n + (b.k === "list" && b.check ? b.items.length : 0), 0);
export const countDone = (blocks: Block[], scope: string, isDone: (k: string) => boolean) =>
  blocks.reduce((n, b, bi) => n + (b.k === "list" && b.check ? b.items.filter((_, i) => isDone(`${scope}/${bi}/${i}`)).length : 0), 0);
