import { useEffect, useState, type ReactNode } from "react";
import type { AnimName } from "../types";
import { useStore } from "../store";

/* helpers */
const useTick = (ms = 50, on = true) => { const [t, setT] = useState(0); useEffect(() => { if (!on) return; const i = setInterval(() => setT((x) => x + 1), ms); return () => clearInterval(i); }, [ms, on]); return t; };
const Seg = ({ opts, v, set }: { opts: [string, string][]; v: string; set: (s: string) => void }) => (
  <div className="seg">{opts.map(([k, l]) => <button key={k} className={v === k ? "on" : ""} onClick={() => set(k)}>{l}</button>)}</div>
);
const Slider = ({ label, v, set, min, max, step = 1, unit = "" }: { label: string; v: number; set: (n: number) => void; min: number; max: number; step?: number; unit?: string }) => (
  <label className="slider"><span>{label}: <b dir="ltr">{v}{unit}</b></span><input type="range" min={min} max={max} step={step} value={v} onChange={(e) => set(+e.target.value)} /></label>
);
const LungR = "M70,28 C42,38 22,90 22,150 C22,186 44,198 72,192 C92,188 98,172 98,150 L98,46 C98,32 84,24 70,28Z";
const Lungs = ({ fillL = "#cfe3ef", fillR = "#cfe3ef", stroke = "#6b8aa3", children }: { fillL?: string; fillR?: string; stroke?: string; children?: ReactNode }) => (
  <g>
    <path d={LungR} fill={fillR} stroke={stroke} strokeWidth="2.5" />
    <path d={LungR} fill={fillL} stroke={stroke} strokeWidth="2.5" transform="translate(240,0) scale(-1,1)" />
    {children}
  </g>
);
const Info = ({ children, tone = "#eef5f0" }: { children: ReactNode; tone?: string }) => <div className="anim-info" style={{ background: tone }}>{children}</div>;

/* 1 investigations wheel */
function Wheel() {
  const { ui } = useStore();
  const items = [
    ["🧫", ui("البصاق", "Sputum"), ui("شنو الجرثومة؟ هل اكو خلايا خبيثة؟", "Which organism? Malignant cells?"), "#cfe6d9"],
    ["🩻", ui("الأشعة", "Radiology"), ui("شلون شكل الرئة والقلب والمنصف؟", "What do lung, heart & mediastinum look like?"), "#d6e4f2"],
    ["🌬️", ui("PFT", "PFT"), ui("شكد الرئة تشتغل؟ انسداد لو تقييد؟", "How well do lungs work? Obstruction or restriction?"), "#f3e3c6"],
    ["🩸", ui("ABG", "ABG"), ui("هل تبادل الغازات سليم؟", "Is gas exchange intact?"), "#f2d6d2"],
    ["🔦", ui("التنظير", "Endoscopy"), ui("نشوف من الداخل ونأخذ عينة", "Look inside and sample"), "#e2dbef"],
    ["💧", ui("الجنب", "Pleura"), ui("شنو بالسائل أو النسيج الجنبي؟", "What is in the pleural fluid/tissue?"), "#d8ece9"],
  ] as const;
  const [sel, setSel] = useState(0);
  const tk = useTick(60);
  return (
    <div className="grid md:grid-cols-[300px_1fr] gap-4 items-center">
      <svg viewBox="-110 -110 220 220" className="w-full max-w-[300px] mx-auto">
        <g transform={`rotate(${(tk * 0.15) % 360})`}>
          {items.map((it, i) => {
            const a0 = (i * 60 - 90) * Math.PI / 180, a1 = ((i + 1) * 60 - 90) * Math.PI / 180;
            const r = sel === i ? 104 : 96;
            const d = `M0,0 L${r * Math.cos(a0)},${r * Math.sin(a0)} A${r},${r} 0 0 1 ${r * Math.cos(a1)},${r * Math.sin(a1)} Z`;
            const am = (a0 + a1) / 2;
            return <g key={i} onClick={() => setSel(i)} style={{ cursor: "pointer" }}>
              <path d={d} fill={it[3]} stroke="#3f3d38" strokeWidth={sel === i ? 3 : 1.5} />
              <text x={62 * Math.cos(am)} y={62 * Math.sin(am)} textAnchor="middle" dominantBaseline="middle" fontSize="22" transform={`rotate(${-(tk * 0.15) % 360} ${62 * Math.cos(am)} ${62 * Math.sin(am)})`}>{it[0]}</text>
            </g>;
          })}
        </g>
        <circle r="26" fill="#fffdf8" stroke="#3f3d38" strokeWidth="2" /><text textAnchor="middle" dy="6" fontSize="18">🫁</text>
      </svg>
      <div key={sel} className="animate-fade">
        <div className="text-3xl">{items[sel][0]}</div>
        <div className="text-xl font-extrabold mt-1">{items[sel][1]}</div>
        <Info>❓ {items[sel][2]}</Info>
        <div className="flex flex-wrap gap-1 mt-3">{items.map((it, i) => <button key={i} onClick={() => setSel(i)} className={"pill " + (i === sel ? "on" : "")}>{it[0]} {it[1]}</button>)}</div>
      </div>
    </div>
  );
}

/* 2 sputum journey */
function SputumJourney() {
  const { ui } = useStore();
  const [st, setSt] = useState(0);
  const tk = useTick(60);
  useEffect(() => { const i = setInterval(() => setSt((s) => (s + 1) % 4), 3200); return () => clearInterval(i); }, []);
  const labels = [ui("1. كحة عميقة → علبة معقمة", "1. Deep cough → sterile cup"), ui("2. فرش العينة على شريحة", "2. Smear on a slide"), ui("3. صبغة Ziehl-Neelsen", "3. Ziehl-Neelsen stain"), ui("4. تحت المجهر: عصيات حمراء = AFB+", "4. Microscope: red rods = AFB+")];
  return (
    <div>
      <svg viewBox="0 0 480 200" className="w-full">
        <rect x="0" y="0" width="480" height="200" rx="16" fill="#fbf7ee" />
        {st === 0 && <g>
          <circle cx="90" cy="80" r="34" fill="#f3d9c4" stroke="#3f3d38" strokeWidth="2" /><ellipse cx="112" cy="90" rx="8" ry="5" fill="#3f3d38" />
          <circle cx={130 + (tk % 40) * 4} cy={92 + ((tk % 40) * (tk % 40)) / 25} r="7" fill="#e8d36a" stroke="#a89530" />
          <path d="M300 120 L310 180 L370 180 L380 120 Z" fill="#e6f0f6" stroke="#3f3d38" strokeWidth="2" /><rect x="296" y="112" width="88" height="12" rx="3" fill="#c9d9e3" stroke="#3f3d38" />
        </g>}
        {st === 1 && <g>
          <rect x="120" y="80" width="240" height="50" rx="4" fill="#eef4f8" stroke="#3f3d38" strokeWidth="2" />
          <ellipse cx="240" cy="105" rx={Math.min(80, (tk % 50) * 3)} ry="14" fill="#e8d36a" opacity=".7" />
          <line x1={150 + (tk % 50) * 4} y1="60" x2={170 + (tk % 50) * 4} y2="100" stroke="#8a857a" strokeWidth="4" strokeLinecap="round" />
        </g>}
        {st === 2 && <g>
          <rect x="120" y="100" width="240" height="50" rx="4" fill="#eef4f8" stroke="#3f3d38" strokeWidth="2" />
          <ellipse cx="240" cy="125" rx="80" ry="14" fill={tk % 60 < 30 ? "#d36d8f" : "#6f8fc9"} opacity=".8" />
          <path d="M220 20 L260 20 L256 60 L224 60 Z" fill={tk % 60 < 30 ? "#d36d8f" : "#6f8fc9"} stroke="#3f3d38" />
          {[0, 1, 2].map((i) => <circle key={i} cx={240} cy={68 + ((tk * 3 + i * 12) % 30)} r="3.5" fill={tk % 60 < 30 ? "#d36d8f" : "#6f8fc9"} />)}
          <text x="240" y="185" textAnchor="middle" fontSize="13" fill="#5b5546">{tk % 60 < 30 ? "Carbol fuchsin (red) + heat" : "Acid-alcohol → Methylene blue"}</text>
        </g>}
        {st === 3 && <g>
          <circle cx="240" cy="100" r="85" fill="#cfdcf0" stroke="#3f3d38" strokeWidth="4" />
          {Array.from({ length: 14 }).map((_, i) => <circle key={"b" + i} cx={240 + 60 * Math.cos(i * 2.1)} cy={100 + 55 * Math.sin(i * 1.7)} r={6 + (i % 3) * 3} fill="#6f8fc9" opacity=".6" />)}
          {Array.from({ length: 9 }).map((_, i) => <rect key={"r" + i} x={210 + ((i * 29) % 70)} y={60 + ((i * 41) % 80)} width="16" height="3.5" rx="2" fill="#d1365e" transform={`rotate(${i * 40} ${218 + ((i * 29) % 70)} ${62 + ((i * 41) % 80)})`} opacity={Math.min(1, (tk % 50) / 10)} />)}
        </g>}
      </svg>
      <div className="flex flex-wrap gap-1 justify-center mt-2">{labels.map((l, i) => <button key={i} onClick={() => setSt(i)} className={"pill " + (st === i ? "on" : "")}>{l}</button>)}</div>
    </div>
  );
}

/* 3 x-ray beam */
function XrayBeam() {
  const { ui } = useStore();
  const tissues = [[ui("هواء", "Air"), 0.05, "#111"], [ui("دهون", "Fat"), 0.3, "#555"], [ui("سائل/عضلة", "Fluid/muscle"), 0.55, "#9a9a9a"], [ui("عظم", "Bone"), 0.85, "#e6e6e6"], [ui("معدن", "Metal"), 1, "#fff"]] as const;
  const [i, setI] = useState(0);
  const tk = useTick(40);
  const absorb = tissues[i][1];
  return (
    <div>
      <svg viewBox="0 0 480 190" className="w-full">
        <rect width="480" height="190" rx="16" fill="#1f2326" />
        <rect x="20" y="70" width="50" height="50" rx="8" fill="#e8c26a" /><text x="45" y="100" textAnchor="middle" fontSize="11" fill="#3f3d38">X-ray</text>
        {Array.from({ length: 7 }).map((_, k) => {
          const y = 60 + k * 12; const x = 70 + ((tk * 6 + k * 30) % 330);
          const passed = x > 250; const op = passed ? 1 - absorb : 1;
          return <circle key={k} cx={x} cy={y} r="3" fill="#f6e27a" opacity={op} />;
        })}
        <rect x="200" y="40" width="50" height="110" rx="6" fill={tissues[i][2]} stroke="#cfcfcf" strokeWidth="1.5" />
        <text x="225" y="165" textAnchor="middle" fill="#ddd" fontSize="12">{tissues[i][0]}</text>
        <rect x="410" y="40" width="40" height="110" rx="4" fill={`rgb(${Math.round(255 * absorb)},${Math.round(255 * absorb)},${Math.round(255 * absorb)})`} stroke="#888" />
        <text x="430" y="165" textAnchor="middle" fill="#ddd" fontSize="11">{ui("الفلم", "Detector")}</text>
      </svg>
      <div className="flex flex-wrap gap-1 justify-center mt-2">{tissues.map((t, k) => <button key={k} onClick={() => setI(k)} className={"pill " + (k === i ? "on" : "")}>{t[0]}</button>)}</div>
      <Info>{ui(`يمتص ${Math.round(absorb * 100)}% من الأشعة ← كلما امتص أكثر، وصل أقل للفلم فيظهر أبيض أكثر.`, `Absorbs ${Math.round(absorb * 100)}% of X-rays ← the more absorbed, the less reaches the detector so it looks whiter.`)}</Info>
    </div>
  );
}

/* 4 CT slices */
function CtSlices() {
  const { ui } = useStore();
  const [lv, setLv] = useState(45);
  const lungW = lv < 75 ? Math.max(10, 70 - Math.abs(lv - 45) * 1.2) : 0;
  const heart = lv > 40 && lv < 80;
  const liver = lv > 72;
  return (
    <div className="grid md:grid-cols-2 gap-3 items-center">
      <svg viewBox="0 0 200 260" className="w-full max-h-[280px]">
        <path d="M100 10 C130 10 135 40 125 55 L165 70 C180 75 182 95 180 120 L172 250 L28 250 L20 120 C18 95 20 75 35 70 L75 55 C65 40 70 10 100 10Z" fill="#f2e3d3" stroke="#3f3d38" strokeWidth="2" />
        <g transform="translate(-20,40) scale(1)"><path d={LungR} transform="translate(30,20) scale(.75)" fill="#cfe3ef" stroke="#6b8aa3" /><path d={LungR} transform="translate(210,20) scale(-.75,.75)" fill="#cfe3ef" stroke="#6b8aa3" /></g>
        <rect x="10" y={30 + lv * 2.1} width="180" height="5" fill="#d16a5c" opacity=".85" />
      </svg>
      <div>
        <svg viewBox="0 0 240 180" className="w-full bg-[#15181a] rounded-2xl">
          <ellipse cx="120" cy="90" rx="105" ry="70" fill="#5a5a5a" />
          <ellipse cx="120" cy="90" rx="95" ry="60" fill="#7a7a7a" />
          {lungW > 0 && <><ellipse cx={120 - 45} cy="88" rx={lungW * 0.55} ry={lungW * 0.75} fill="#111" /><ellipse cx={120 + 45} cy="88" rx={lungW * 0.5} ry={lungW * 0.72} fill="#111" /></>}
          {heart && <ellipse cx="132" cy="100" rx="28" ry="24" fill="#b0b0b0" />}
          {liver && <path d="M40 90 C60 40 160 50 200 95 C170 140 70 140 40 90Z" fill="#a8a8a8" />}
          <circle cx="120" cy="150" r="11" fill="#eee" /><circle cx="120" cy="60" r={lv < 30 ? 6 : 0} fill="#111" />
        </svg>
        <Slider label={ui("مستوى الشريحة", "Slice level")} v={lv} set={setLv} min={0} max={95} />
        <Info>{lv < 30 ? ui("مستوى القصبة وقمة الرئتين", "Trachea & lung apices") : lv < 75 ? ui("الرئتين (سود) + القلب + المنصف", "Lungs (black) + heart + mediastinum") : ui("قاعدة الرئة والكبد تحت الحجاب", "Lung bases & liver below diaphragm")}</Info>
      </div>
    </div>
  );
}

/* 5 ultrasound */
function UsEcho() {
  const { ui } = useStore();
  const tk = useTick(50);
  const r = (tk * 4) % 170;
  return (
    <div>
      <svg viewBox="0 0 480 220" className="w-full">
        <rect width="480" height="220" rx="16" fill="#101214" />
        <path d="M240 20 L60 210 L420 210 Z" fill="#2a2d30" />
        <path d="M240 20 L100 168 L380 168 Z" fill="#000" opacity="0" />
        <path d="M240 20 L60 210 L420 210 Z" fill="url(#usg)" opacity=".9" />
        <defs><linearGradient id="usg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#bdbdbd" /><stop offset=".28" stopColor="#d6d6d6" /><stop offset=".3" stopColor="#060606" /><stop offset=".62" stopColor="#060606" /><stop offset=".65" stopColor="#9c9c9c" /><stop offset="1" stopColor="#6e6e6e" /></linearGradient></defs>
        <rect x="215" y="4" width="50" height="20" rx="6" fill="#d9c8a5" />
        <path d={`M ${240 - r * 0.9} ${20 + r} A ${r} ${r * 0.35} 0 0 0 ${240 + r * 0.9} ${20 + r}`} fill="none" stroke="#7fd1b9" strokeWidth="2" opacity={1 - r / 170} />
        <text x="430" y="70" fill="#ddd" fontSize="12" textAnchor="end">{ui("جدار الصدر", "Chest wall")}</text>
        <text x="300" y="110" fill="#7fd1b9" fontSize="14" fontWeight="bold">{ui("سائل = أسود (بدون صدى)", "Fluid = black (anechoic)")}</text>
        <text x="420" y="190" fill="#ddd" fontSize="12" textAnchor="end">{ui("الرئة / الحجاب", "Lung / diaphragm")}</text>
      </svg>
    </div>
  );
}

/* 6 V/Q match */
function VqMatch() {
  const { ui } = useStore();
  const [pe, setPe] = useState(false);
  return (
    <div>
      <Seg opts={[["n", ui("طبيعي", "Normal")], ["pe", ui("صمة رئوية", "Pulmonary embolism")]]} v={pe ? "pe" : "n"} set={(s) => setPe(s === "pe")} />
      <div className="grid grid-cols-2 gap-3 mt-3">
        {["V", "Q"].map((k) => (
          <div key={k} className="text-center">
            <svg viewBox="0 0 240 210" className="w-full bg-[#14171a] rounded-2xl">
              <Lungs fillL="#4fb39b" fillR="#4fb39b" stroke="#9fe0cf" />
              {k === "Q" && pe && <path d="M160 70 L210 60 L215 130 L170 120 Z" fill="#14171a" className="pulse" />}
            </svg>
            <div className="font-bold mt-1">{k === "V" ? ui("التهوية (V)", "Ventilation (V)") : ui("التروية (Q)", "Perfusion (Q)")}</div>
          </div>
        ))}
      </div>
      <Info tone={pe ? "#f8e7e3" : "#eef5f0"}>{pe ? ui("التهوية كاملة بس منطقة بالتروية مفقودة = Mismatch → صمة رئوية", "Ventilation complete but a perfusion defect = mismatch → PE") : ui("التهوية والتروية متطابقتين = طبيعي", "Matched ventilation and perfusion = normal")}</Info>
    </div>
  );
}

/* 7 PET glucose */
function PetGlucose() {
  const { ui } = useStore();
  const tk = useTick(40);
  return (
    <div>
      <svg viewBox="0 0 480 200" className="w-full">
        <rect width="480" height="200" rx="16" fill="#fbf7ee" />
        <circle cx="130" cy="110" r="55" fill="#dfeee6" stroke="#5f8f7b" strokeWidth="3" />
        <circle cx="350" cy="110" r="60" fill={`rgba(240,140,90,${0.35 + 0.25 * Math.sin(tk / 6)})`} stroke="#d16a5c" strokeWidth="3" />
        <circle cx="130" cy="110" r="16" fill="#9fc7b4" /><circle cx="350" cy="110" r="24" fill="#c9705f" />
        {Array.from({ length: 16 }).map((_, i) => {
          const toCancer = i % 5 !== 0; const p = ((tk * 2 + i * 23) % 100) / 100;
          const tx = toCancer ? 350 : 130; const x = 240 + (tx - 240) * p; const y = 20 + (110 - 20) * p + Math.sin(i + p * 6) * 10;
          return <g key={i}><circle cx={x} cy={y} r="5" fill="#f1c84b" stroke="#a88a1c" /></g>;
        })}
        <text x="130" y="190" textAnchor="middle" fontSize="13" fill="#3f3d38">{ui("خلية طبيعية", "Normal cell")}</text>
        <text x="350" y="190" textAnchor="middle" fontSize="13" fill="#3f3d38">{ui("خلية سرطانية تضوي ✨", "Cancer cell glows ✨")}</text>
        <text x="240" y="18" textAnchor="middle" fontSize="12" fill="#a88a1c">FDG (radio-glucose)</text>
      </svg>
    </div>
  );
}

/* 8 bronchoscope camera */
function Bronchoscope() {
  const { ui } = useStore();
  const stations = [ui("الحنجرة", "Larynx"), ui("القصبة", "Trachea"), ui("الجؤجؤ (Carina)", "Carina"), ui("القصبة اليمنى", "Right bronchus")];
  const [s, setS] = useState(0);
  const tk = useTick(60);
  return (
    <div className="grid md:grid-cols-[1fr_220px] gap-4 items-center">
      <svg viewBox="0 0 260 260" className="w-full max-w-[320px] mx-auto">
        <defs><radialGradient id="bg8"><stop offset="0" stopColor="#5a1f1f" /><stop offset=".6" stopColor="#c46a5e" /><stop offset="1" stopColor="#f0b4a0" /></radialGradient></defs>
        <circle cx="130" cy="130" r="125" fill="url(#bg8)" stroke="#3f3d38" strokeWidth="5" />
        {s === 0 && <g><path d="M95 70 Q130 210 165 70" fill="#3a1010" /><path d="M105 75 Q130 190 130 200" stroke="#f6e7e0" strokeWidth="7" fill="none" /><path d="M155 75 Q130 190 130 200" stroke="#f6e7e0" strokeWidth="7" fill="none" /></g>}
        {s === 1 && <g>{[100, 80, 60, 40].map((r, i) => <circle key={i} cx="130" cy="130" r={r + ((tk * 2) % 20)} fill="none" stroke="#f3c9b8" strokeWidth="6" opacity={0.7 - i * 0.12} />)}<circle cx="130" cy="130" r="30" fill="#2a0c0c" /></g>}
        {s === 2 && <g><ellipse cx="95" cy="135" rx="32" ry="40" fill="#2a0c0c" /><ellipse cx="168" cy="140" rx="28" ry="36" fill="#2a0c0c" /><path d="M128 95 L132 180" stroke="#f6dfd4" strokeWidth="10" strokeLinecap="round" /></g>}
        {s === 3 && <g><ellipse cx="105" cy="120" rx="22" ry="26" fill="#2a0c0c" /><ellipse cx="160" cy="110" rx="18" ry="22" fill="#2a0c0c" /><ellipse cx="140" cy="175" rx="20" ry="18" fill="#2a0c0c" /></g>}
      </svg>
      <div className="space-y-2">
        {stations.map((n, i) => <button key={i} onClick={() => setS(i)} className={"pill w-full " + (s === i ? "on" : "")}>{i + 1}. {n}</button>)}
        <Info>{[ui("الأحبال الصوتية على شكل V", "V-shaped vocal cords"), ui("حلقات غضروفية بشكل حرف C", "C-shaped cartilage rings"), ui("نقطة تفرع القصبة لليمين واليسار", "Where trachea splits right & left"), ui("فتحات الفصوص – هنا نأخذ خزعة أو غسل", "Lobar orifices – biopsy or lavage here")][s]}</Info>
      </div>
    </div>
  );
}

/* 9 spirometry */
function Spirometry() {
  const { ui } = useStore();
  const [m, setM] = useState("n");
  const tk = useTick(30);
  const P = { n: { fev1: 4, fvc: 5, c: "#5f8f7b" }, o: { fev1: 1.8, fvc: 4.3, c: "#d16a5c" }, r: { fev1: 2.6, fvc: 2.9, c: "#6f8fc9" } } as Record<string, { fev1: number; fvc: number; c: string }>;
  const d = P[m];
  const prog = Math.min(1, (tk % 120) / 80);
  const pts = Array.from({ length: 61 }).map((_, i) => { const tt = i / 10; const k = d.fev1 / d.fvc; const tau = -1 / Math.log(1 - Math.min(0.98, k)); const v = d.fvc * (1 - Math.exp(-tt / tau)); return [40 + tt * 60, 190 - v * 30]; });
  const shown = pts.slice(0, Math.max(2, Math.floor(prog * pts.length)));
  const ratio = Math.round((d.fev1 / d.fvc) * 100);
  return (
    <div>
      <Seg opts={[["n", ui("طبيعي", "Normal")], ["o", ui("انسدادي", "Obstructive")], ["r", ui("تقييدي", "Restrictive")]]} v={m} set={setM} />
      <div className="grid md:grid-cols-[1fr_200px] gap-3 mt-3 items-center">
        <svg viewBox="0 0 440 210" className="w-full bg-white rounded-2xl border border-[#e8e1d2]">
          <line x1="40" y1="190" x2="420" y2="190" stroke="#3f3d38" /><line x1="40" y1="20" x2="40" y2="190" stroke="#3f3d38" />
          <line x1="100" y1="20" x2="100" y2="190" stroke="#c9a27e" strokeDasharray="4 4" /><text x="100" y="205" textAnchor="middle" fontSize="11">1s</text>
          <text x="12" y="105" fontSize="11" transform="rotate(-90 12 105)">Volume (L)</text>
          <polyline points={shown.map((p) => p.join(",")).join(" ")} fill="none" stroke={d.c} strokeWidth="4" strokeLinecap="round" />
          <line x1="40" y1={190 - d.fev1 * 30} x2="100" y2={190 - d.fev1 * 30} stroke={d.c} strokeDasharray="3 3" />
          <text x="44" y={186 - d.fev1 * 30} fontSize="11" fill={d.c}>FEV1</text>
          <line x1="40" y1={190 - d.fvc * 30} x2="420" y2={190 - d.fvc * 30} stroke="#999" strokeDasharray="2 4" /><text x="380" y={185 - d.fvc * 30} fontSize="11">FVC</text>
        </svg>
        <div className="space-y-2">
          <div className="stat-mini"><span>FEV1</span><b>{d.fev1} L</b></div>
          <div className="stat-mini"><span>FVC</span><b>{d.fvc} L</b></div>
          <div className="stat-mini" style={{ background: ratio < 70 ? "#f8e1dc" : "#e3f0e9" }}><span>FEV1/FVC</span><b>{ratio}%</b></div>
        </div>
      </div>
      <Info>{m === "n" ? ui("أغلب الهواء يطلع بأول ثانية (≥70%)", "Most air leaves in 1 s (≥70%)") : m === "o" ? ui("الهواء يطلع ببطء – النسبة <70% (ربو/COPD)", "Air leaves slowly – ratio <70% (asthma/COPD)") : ui("الحجم الكلي صغير بس يطلع بسرعة – النسبة طبيعية/عالية (تليف)", "Small total volume but exits fast – ratio normal/high (fibrosis)")}</Info>
    </div>
  );
}

/* 10 oximeter */
function Oximeter() {
  const { ui } = useStore();
  const [sat, setSat] = useState(97);
  const tk = useTick(40);
  const red = Math.round(120 + (sat - 70) * 4.5), blue = Math.round(120 - (sat - 70) * 3);
  const wave = Array.from({ length: 60 }).map((_, i) => { const x = i * 5; const ph = ((i + tk) % 20) / 20; const y = 50 - (ph < 0.3 ? Math.sin(ph / 0.3 * Math.PI) * 30 : Math.sin((ph - 0.3) / 0.7 * Math.PI) * 8); return `${x},${y}`; }).join(" ");
  return (
    <div className="grid md:grid-cols-2 gap-3 items-center">
      <svg viewBox="0 0 240 200" className="w-full">
        <rect x="70" y="20" width="100" height="160" rx="45" fill="#f1d1bc" stroke="#3f3d38" strokeWidth="2" />
        <rect x="56" y="60" width="128" height="70" rx="14" fill="#7fb3c9" stroke="#3f3d38" strokeWidth="2" opacity=".9" />
        <circle cx="120" cy="68" r="6" fill="#ff4b4b" /><line x1="120" y1="74" x2="120" y2="122" stroke="#ff4b4b" strokeWidth="3" opacity={0.4 + 0.4 * Math.sin(tk / 3)} />
        <rect x="100" y="95" width="40" height="10" rx="5" fill={`rgb(${red},40,${Math.max(40, blue)})`} />
        <text x="120" y="160" textAnchor="middle" fontSize="11">{ui("الدم بالشعيرات", "Capillary blood")}</text>
      </svg>
      <div>
        <div className="oxi-screen"><svg viewBox="0 0 300 80" className="w-full"><polyline points={wave} fill="none" stroke="#6ee7b7" strokeWidth="2.5" /></svg><div className="flex justify-between px-3 pb-2"><span>SpO₂ <b className="text-2xl">{sat}%</b></span><span>♥ 82</span></div></div>
        <Slider label="SaO₂" v={sat} set={setSat} min={70} max={100} unit="%" />
        <Info tone={sat < 90 ? "#f8e1dc" : "#eef5f0"}>{sat >= 95 ? ui("طبيعي", "Normal") : sat >= 90 ? ui("منخفض قليلاً", "Mildly low") : ui("نقص أكسجين واضح – نحتاج ABG حتى نعرف CO₂", "Clear hypoxia – need ABG to know CO₂")}</Info>
      </div>
    </div>
  );
}

/* 11 ABG panel */
function AbgPanel() {
  const { ui } = useStore();
  const [o2, setO2] = useState(90), [co2, setCo2] = useState(40), [ph, setPh] = useState(7.4);
  const hyp = o2 < 60, hcap = co2 > 45;
  const typ = !hyp ? ui("طبيعي (لا يوجد فشل تنفسي)", "Normal (no respiratory failure)") : hcap ? ui("فشل تنفسي – النوع الثاني", "Respiratory failure – type II") : ui("فشل تنفسي – النوع الأول", "Respiratory failure – type I");
  const acid = ph < 7.35 ? (hcap ? ui("حموضة تنفسية", "Respiratory acidosis") : ui("حموضة", "Acidosis")) : ph > 7.45 ? (co2 < 35 ? ui("قلوية تنفسية (لهاث)", "Respiratory alkalosis (hyperventilation)") : ui("قلوية", "Alkalosis")) : ui("pH طبيعي", "Normal pH");
  return (
    <div className="grid md:grid-cols-2 gap-4 items-center">
      <div>
        <Slider label="PaO₂ (mmHg)" v={o2} set={setO2} min={30} max={110} />
        <Slider label="PaCO₂ (mmHg)" v={co2} set={setCo2} min={20} max={100} />
        <Slider label="pH" v={ph} set={setPh} min={7.0} max={7.6} step={0.01} />
        <div className="flex flex-wrap gap-1 mt-2">
          <button className="pill" onClick={() => { setO2(52); setCo2(32); setPh(7.47); }}>{ui("مثال: ذات رئة", "e.g. pneumonia")}</button>
          <button className="pill" onClick={() => { setO2(50); setCo2(72); setPh(7.25); }}>{ui("مثال: COPD", "e.g. COPD")}</button>
          <button className="pill" onClick={() => { setO2(92); setCo2(40); setPh(7.4); }}>{ui("طبيعي", "Normal")}</button>
        </div>
      </div>
      <div className="abg-card">
        <div className={"abg-row " + (hyp ? "bad" : "")}><span>PaO₂</span><b>{o2}</b><em>{hyp ? "↓ Hypoxia" : "OK"}</em></div>
        <div className={"abg-row " + (hcap ? "bad" : co2 < 35 ? "warn" : "")}><span>PaCO₂</span><b>{co2}</b><em>{hcap ? "↑ Hypercapnia" : co2 < 35 ? "↓ Hypocapnia" : "OK"}</em></div>
        <div className={"abg-row " + (ph < 7.35 || ph > 7.45 ? "warn" : "")}><span>pH</span><b>{ph.toFixed(2)}</b><em>{acid}</em></div>
        <div className="abg-verdict">{typ}</div>
      </div>
    </div>
  );
}

/* 12 pleural tap */
function PleuralTap() {
  const { ui } = useStore();
  const [play, setPlay] = useState(true);
  const tk = useTick(50, play);
  const ph = tk % 120;
  const nx = ph < 40 ? 20 + ph * 3.2 : ph < 100 ? 148 : 148 - (ph - 100) * 6;
  const fill = ph < 40 ? 0 : ph < 100 ? (ph - 40) / 60 : 1;
  return (
    <div>
      <svg viewBox="0 0 480 220" className="w-full">
        <rect width="480" height="220" rx="16" fill="#fbf7ee" />
        <rect x="140" y="10" width="40" height="200" fill="#f1d1bc" />
        {[30, 100, 170].map((y) => <g key={y}><ellipse cx="160" cy={y} rx="24" ry="14" fill="#f3f0e6" stroke="#8a857a" strokeWidth="2" /><circle cx="168" cy={y + 12} r="3" fill="#d16a5c" /><circle cx="160" cy={y + 13} r="3" fill="#6f8fc9" /><circle cx="152" cy={y + 12} r="3" fill="#e5c45a" /></g>)}
        <rect x="182" y="10" width="140" height="200" fill="#e0eef5" />
        <rect x="182" y={110 + fill * 40} width="140" height={100 - fill * 40} fill="#f0d98a" opacity=".85" />
        <path d="M322 10 C350 60 340 160 322 210" fill="#cfe3ef" stroke="#6b8aa3" strokeWidth="2" />
        <g transform={`translate(${nx},0)`}>
          <line x1="0" y1="140" x2="70" y2="140" stroke="#7c7c7c" strokeWidth="3" />
          <rect x="-90" y="128" width="90" height="24" rx="4" fill="#ffffff" stroke="#3f3d38" />
          <rect x="-88" y="130" width={86 * fill} height="20" fill="#f0d98a" />
        </g>
        <text x="250" y="200" textAnchor="middle" fontSize="12">{ui("سائل الجنب", "Pleural fluid")}</text>
        <text x="160" y="215" textAnchor="middle" fontSize="10" fill="#8a857a">{ui("الوعاء والعصب تحت الضلع", "Vessels & nerve under rib")}</text>
      </svg>
      <div className="flex justify-between items-center mt-2">
        <button className="pill" onClick={() => setPlay(!play)}>{play ? "⏸" : "▶"}</button>
        <Info>{ph < 40 ? ui("الإبرة تدخل فوق الحافة العلوية للضلع السفلي", "Needle enters above the upper border of the lower rib") : ph < 100 ? ui("السحب: العينة للون والبروتين والجراثيم والخلايا", "Aspirating: sample for colour, protein, bacteria, cells") : ui("سحب الإبرة", "Withdraw")}</Info>
      </div>
    </div>
  );
}

/* 13 Abrams */
function Abrams() {
  const { ui } = useStore();
  const [s, setS] = useState(0);
  useEffect(() => { const i = setInterval(() => setS((x) => (x + 1) % 4), 2600); return () => clearInterval(i); }, []);
  const tx = [0, 60, 50, -40][s];
  return (
    <div>
      <svg viewBox="0 0 480 170" className="w-full">
        <rect width="480" height="170" rx="16" fill="#fbf7ee" />
        <rect x="250" y="20" width="18" height="130" fill="#e6a5a0" /><text x="259" y="165" textAnchor="middle" fontSize="11">{ui("الجنب الجداري", "Parietal pleura")}</text>
        <rect x="268" y="20" width="200" height="130" fill="#f2e6b8" opacity=".6" />
        <g style={{ transition: "transform .8s" }} transform={`translate(${tx},0)`}>
          <rect x="40" y="76" width="230" height="18" rx="9" fill="#c9ccd0" stroke="#3f3d38" />
          <rect x="230" y="76" width="22" height="9" fill="#fbf7ee" stroke="#3f3d38" />
          <path d="M270 76 L290 85 L270 94Z" fill="#c9ccd0" stroke="#3f3d38" />
          {s >= 2 && <rect x="232" y="78" width="18" height="6" fill="#e6a5a0" />}
          <rect x="30" y="70" width="20" height="30" rx="4" fill="#8a857a" />
          {s === 2 && <path d="M60 60 A30 30 0 0 1 100 60" fill="none" stroke="#d16a5c" strokeWidth="3" markerEnd="url(#ar)" />}
        </g>
        <defs><marker id="ar" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8Z" fill="#d16a5c" /></marker></defs>
      </svg>
      <div className="flex flex-wrap gap-1 justify-center mt-2">{[ui("1. إدخال", "1. Insert"), ui("2. الفتحة تمسك الجنب", "2. Notch hooks pleura"), ui("3. تدوير وقص", "3. Rotate & cut"), ui("4. سحب العينة", "4. Withdraw sample")].map((l, i) => <button key={i} onClick={() => setS(i)} className={"pill " + (s === i ? "on" : "")}>{l}</button>)}</div>
    </div>
  );
}

/* shared alveolus scene for 14 & 16 */
function AlvScene({ air, blood, membrane, tk }: { air: number; blood: number; membrane: number; tk: number }) {
  const sat = Math.round(Math.min(air, blood > 0 ? 1 : 0, membrane) * 100);
  const outC = sat > 80 ? "#d23b3b" : sat > 40 ? "#a2476a" : "#5b4a9a";
  return (
    <svg viewBox="0 0 480 220" className="w-full">
      <rect width="480" height="220" rx="16" fill="#fbf7ee" />
      <path d="M240 10 L240 60" stroke="#8fb3c9" strokeWidth="18" strokeLinecap="round" opacity={air > 0 ? 1 : 0.3} />
      <circle cx="240" cy="100" r="58" fill={air > 0 ? "#e3f1f8" : "#f2e6c8"} stroke="#6b8aa3" strokeWidth={membrane < 1 ? 7 : 3} strokeDasharray={membrane < 1 ? "10 6" : ""} />
      {air > 0 && Array.from({ length: 8 }).map((_, i) => <circle key={i} cx={240 + 30 * Math.cos(i + tk / 10)} cy={100 + 30 * Math.sin(i * 1.3 + tk / 12)} r="5" fill="#6f9fd8" />)}
      <path d="M20 180 C140 180 170 165 240 165 C310 165 340 180 460 180" stroke="#e7b3ab" strokeWidth="26" fill="none" opacity={blood > 0 ? 1 : 0.25} />
      {blood > 0 && Array.from({ length: 9 }).map((_, i) => { const x = (tk * 4 + i * 55) % 460 + 10; const c = x < 200 ? "#5b4a9a" : outC; return <ellipse key={i} cx={x} cy={x > 160 && x < 320 ? 168 : 180} rx="9" ry="6" fill={c} />; })}
      <text x="30" y="210" fontSize="11">{"→ venous"}</text><text x="400" y="210" fontSize="11">{"arterial →"}</text>
    </svg>
  );
}

/* 14 breath-3 */
function Breath3() {
  const { ui } = useStore();
  const [v, setV] = useState(true), [q, setQ] = useState(true), [e, setE] = useState(true);
  const tk = useTick(50);
  return (
    <div>
      <AlvScene air={v ? 1 : 0} blood={q ? 1 : 0} membrane={e ? 1 : 0.3} tk={tk} />
      <div className="flex flex-wrap gap-2 justify-center mt-2">
        <button className={"pill " + (v ? "on" : "off")} onClick={() => setV(!v)}>🌬️ {ui("تهوية", "Ventilation")} {v ? "✓" : "✗"}</button>
        <button className={"pill " + (q ? "on" : "off")} onClick={() => setQ(!q)}>🩸 {ui("تروية", "Perfusion")} {q ? "✓" : "✗"}</button>
        <button className={"pill " + (e ? "on" : "off")} onClick={() => setE(!e)}>🔄 {ui("تبادل", "Exchange")} {e ? "✓" : "✗"}</button>
      </div>
      <Info tone={v && q && e ? "#eef5f0" : "#f8e7e3"}>{v && q && e ? ui("كل الوظائف سليمة ← الدم الخارج أحمر مؤكسج", "All functions intact → red oxygenated blood leaves") : ui("وظيفة وحدة عاطلة تكفي حتى يطلع الدم ناقص أكسجين (أزرق)", "One broken function is enough to send out deoxygenated (blue) blood")}</Info>
    </div>
  );
}

/* 15 type1 vs type2 gauges */
function Gauge({ v, max, label, danger, unit }: { v: number; max: number; label: string; danger: "low" | "high"; unit: string }) {
  const a = -120 + (v / max) * 240;
  return (
    <svg viewBox="0 0 160 120" className="w-full">
      <path d="M20 100 A60 60 0 1 1 140 100" fill="none" stroke="#e8e1d2" strokeWidth="14" />
      <path d={danger === "low" ? "M20 100 A60 60 0 0 1 35 45" : "M125 45 A60 60 0 0 1 140 100"} fill="none" stroke="#e59b8f" strokeWidth="14" />
      <g style={{ transition: "transform .8s" }} transform={`rotate(${a} 80 80)`}><line x1="80" y1="80" x2="80" y2="30" stroke="#3f3d38" strokeWidth="4" strokeLinecap="round" /></g>
      <circle cx="80" cy="80" r="7" fill="#3f3d38" />
      <text x="80" y="112" textAnchor="middle" fontSize="13" fontWeight="bold">{label}: {v} {unit}</text>
    </svg>
  );
}
function Type12() {
  const { ui } = useStore();
  const [m, setM] = useState("1");
  const vals = { n: [95, 40], "1": [50, 32], "2": [50, 70] } as Record<string, number[]>;
  return (
    <div>
      <Seg opts={[["n", ui("طبيعي", "Normal")], ["1", ui("النوع الأول", "Type I")], ["2", ui("النوع الثاني", "Type II")]]} v={m} set={setM} />
      <div className="grid grid-cols-2 gap-3 mt-2">
        <Gauge v={vals[m][0]} max={120} label="PaO₂" danger="low" unit="mmHg" />
        <Gauge v={vals[m][1]} max={90} label="PaCO₂" danger="high" unit="mmHg" />
      </div>
      <Info tone={m === "2" ? "#f8e7e3" : m === "1" ? "#fdf3dc" : "#eef5f0"}>{m === "n" ? ui("O₂ و CO₂ طبيعيين", "Normal O₂ and CO₂") : m === "1" ? ui("O₂ نازل + CO₂ طبيعي/نازل ← V/Q mismatch", "O₂ low + CO₂ normal/low ← V/Q mismatch") : ui("O₂ نازل + CO₂ صاعد ← Hypoventilation", "O₂ low + CO₂ high ← hypoventilation")}</Info>
    </div>
  );
}

/* 16 V/Q mismatch */
function VqMismatch() {
  const { ui } = useStore();
  const [m, setM] = useState("n");
  const tk = useTick(50);
  return (
    <div>
      <Seg opts={[["n", ui("طبيعي V=Q", "Normal V=Q")], ["s", ui("تحويلة (V↓)", "Shunt (V↓)")], ["d", ui("حيز ميت (Q↓)", "Dead space (Q↓)")]]} v={m} set={setM} />
      <AlvScene air={m === "s" ? 0 : 1} blood={m === "d" ? 0 : 1} membrane={1} tk={tk} />
      <Info tone={m === "n" ? "#eef5f0" : "#f8e7e3"}>{m === "n" ? ui("هواء ودم متناسقين ← أكسجة كاملة", "Matched air & blood → full oxygenation") : m === "s" ? ui("السنخ مليان سائل/قيح – الدم يعبر بدون أكسجين (ذات رئة، وذمة، ARDS)", "Alveolus filled with fluid/pus – blood passes unoxygenated (pneumonia, oedema, ARDS)") : ui("الهواء موجود بس الدم ما يوصل – تهوية ضائعة (صمة رئوية)", "Air present but no blood – wasted ventilation (PE)")}</Info>
    </div>
  );
}

/* 17 hypoventilation chain */
function HypoChain() {
  const { ui } = useStore();
  const links = [
    ["🧠", ui("مركز التنفس", "Resp. centre"), ui("رضة، ورم، جلطة، تخدير", "Trauma, tumour, stroke, anaesthesia")],
    ["⚡", ui("الأعصاب", "Nerves"), ui("غيلان-باريه، شلل الأطفال", "Guillain-Barré, polio")],
    ["💪", ui("العضلات", "Muscles"), ui("Myopathies، الوهن العضلي", "Myopathies, myasthenia gravis")],
    ["🦴", ui("القفص الصدري", "Thoracic cage"), ui("الحداب الجنفي، الصدر السائب", "Kyphoscoliosis, flail chest")],
    ["🫁", ui("الرئة/المجاري", "Lung/airways"), ui("COPD", "COPD")],
  ];
  const [broken, setBroken] = useState<number | null>(null);
  const tk = useTick(60);
  const co2 = broken === null ? 40 : Math.min(85, 40 + ((tk * 1.2) % 50));
  return (
    <div>
      <div className="chain">
        {links.map((l, i) => (
          <button key={i} onClick={() => setBroken(broken === i ? null : i)} className={"chain-link " + (broken === i ? "broken" : "")}>
            <span className="text-2xl">{l[0]}</span><span className="font-bold text-sm">{l[1]}</span>
            {i < links.length - 1 && <span className="chain-arrow">{broken === i ? "✂" : "➜"}</span>}
          </button>
        ))}
      </div>
      <div className="co2-bar"><div style={{ width: `${(co2 / 90) * 100}%`, background: co2 > 45 ? "#e07a6a" : "#7fb39b" }} /><span>PaCO₂ {Math.round(co2)} mmHg</span></div>
      <Info tone={broken === null ? "#eef5f0" : "#f8e7e3"}>{broken === null ? ui("اضغط على حلقة لتكسرها", "Tap a link to break it") : <>{ui("مكسورة: ", "Broken: ")}<b>{links[broken][1]}</b> — {links[broken][2]} → {ui("نقص تهوية ← CO₂ يتراكم (النوع الثاني)", "hypoventilation → CO₂ accumulates (type II)")}</>}</Info>
    </div>
  );
}

/* 18 cyanosis vs O2 */
function CyanosisO2() {
  const { ui } = useStore();
  const [fio2, setF] = useState(21);
  const [ards, setArds] = useState(false);
  const sat = ards ? Math.min(88, 72 + (fio2 - 21) * 0.2) : Math.min(98, 78 + (fio2 - 21) * 1.6);
  const lip = sat > 92 ? "#d9777a" : sat > 85 ? "#a7708f" : "#6a6aa8";
  return (
    <div className="grid md:grid-cols-2 gap-3 items-center">
      <svg viewBox="0 0 200 200" className="w-full max-w-[240px] mx-auto">
        <circle cx="100" cy="100" r="80" fill="#f3d9c4" stroke="#3f3d38" strokeWidth="2" />
        <circle cx="72" cy="82" r="7" fill="#3f3d38" /><circle cx="128" cy="82" r="7" fill="#3f3d38" />
        <path d="M70 135 Q100 155 130 135 Q100 125 70 135Z" fill={lip} stroke="#3f3d38" style={{ transition: "fill .6s" }} />
        <path d="M60 60 Q72 54 84 60" stroke="#3f3d38" fill="none" strokeWidth="2" /><path d="M116 60 Q128 54 140 60" stroke="#3f3d38" fill="none" strokeWidth="2" />
      </svg>
      <div>
        <Seg opts={[["1", ui("نوع أول عادي", "Ordinary type I")], ["a", "ARDS"]]} v={ards ? "a" : "1"} set={(s) => setArds(s === "a")} />
        <Slider label="FiO₂" v={fio2} set={setF} min={21} max={60} unit="%" />
        <div className="stat-mini"><span>SpO₂</span><b>{Math.round(sat)}%</b></div>
        <Info tone={sat > 92 ? "#eef5f0" : "#f8e7e3"}>{ards ? ui("بـ ARDS الزرقة مقاومة للعلاج – حتى مع أوكسجين عالي", "In ARDS cyanosis is resistant – even with high O₂") : fio2 > 30 ? ui("فوق 30% الزرقة تتصحح ✓", "Above 30% cyanosis corrects ✓") : ui("زرقة مركزية بالشفاه", "Central cyanosis of the lips")}</Info>
      </div>
    </div>
  );
}

/* 19 hypercapnia */
function Hypercapnia() {
  const { ui } = useStore();
  const [co2, setCo2] = useState(45);
  const sym = [[50, "🤕", ui("صداع (توسع أوعية الدماغ)", "Headache (cerebral vasodilation)")], [55, "💓", ui("خفقان ونبض قوي", "Palpitation, bounding pulse")], [62, "🖐️", ui("رجفة رفرفية", "Flapping tremor")], [70, "😪", ui("نعاس", "Drowsiness")], [80, "😵", ui("تشوش", "Confusion")], [90, "🛌", ui("غيبوبة (CO₂ narcosis)", "Coma (CO₂ narcosis)")]] as const;
  return (
    <div className="grid md:grid-cols-[220px_1fr] gap-4 items-center">
      <svg viewBox="0 0 200 180" className="w-full">
        <ellipse cx="100" cy="85" rx="80" ry="65" fill="#f2d6e0" stroke="#3f3d38" strokeWidth="2" />
        <path d="M40 80 Q70 50 100 80 T160 80" fill="none" stroke="#c98aa2" strokeWidth="3" />
        {[50, 80, 110, 140].map((x, i) => <path key={i} d={`M${x} 40 Q${x + 8} 85 ${x} 130`} fill="none" stroke="#d16a5c" strokeWidth={2 + Math.max(0, co2 - 45) / 8} opacity=".7" />)}
        <text x="100" y="170" textAnchor="middle" fontSize="12">{ui("أوعية الدماغ تتوسع", "Brain vessels dilate")}</text>
      </svg>
      <div>
        <Slider label="PaCO₂" v={co2} set={setCo2} min={40} max={95} unit=" mmHg" />
        <div className="fill-grid tight mt-2">{sym.map(([th, e, l]) => <div key={l} className={"sym " + (co2 >= th ? "on" : "")}><span>{e}</span>{l}</div>)}</div>
      </div>
    </div>
  );
}

/* 20 O2 in COPD */
function O2Copd() {
  const { ui } = useStore();
  const [mode, setMode] = useState("v");
  const [h, setH] = useState(0);
  useEffect(() => { setH(0); const i = setInterval(() => setH((x) => (x < 24 ? x + 1 : x)), 220); return () => clearInterval(i); }, [mode]);
  const co2 = mode === "v" ? 62 - h * 0.25 : 62 + h * 1.4;
  const o2 = mode === "v" ? 50 + Math.min(h, 8) * 1.8 : 50 + Math.min(h, 6) * 9;
  const face = co2 > 85 ? "😵" : co2 > 72 ? "😪" : "🙂";
  return (
    <div>
      <Seg opts={[["v", ui("فنتوري 24–28% (مضبوط)", "Venturi 24–28% (controlled)")], ["h", ui("قناع عالي غير مضبوط", "High uncontrolled mask")]]} v={mode} set={setMode} />
      <div className="grid grid-cols-3 gap-2 mt-3 text-center">
        <div className="stat-mini"><span>{ui("الساعة", "Hour")}</span><b>{h}</b></div>
        <div className="stat-mini"><span>PaO₂</span><b>{Math.round(o2)}</b></div>
        <div className="stat-mini" style={{ background: co2 > 70 ? "#f8e1dc" : "#e3f0e9" }}><span>PaCO₂</span><b>{Math.round(co2)}</b></div>
      </div>
      <div className="text-5xl text-center my-2">{face}</div>
      <Info tone={mode === "h" && h > 8 ? "#f8e1dc" : "#eef5f0"}>{mode === "v" ? ui("الأكسجين يتحسن تدريجياً بدون ما يرتفع CO₂ – هذا الصحيح بالنوع الثاني", "O₂ improves gradually without CO₂ rising – correct for type II") : ui("الأكسجين يرتفع بسرعة بس CO₂ يتراكم ← نعاس وتشوش (سؤال سنين!)", "O₂ jumps but CO₂ accumulates → drowsiness & confusion (past-paper Q!)")}</Info>
    </div>
  );
}

/* 21 edema compare */
function EdemaCompare() {
  const { ui } = useStore();
  const [m, setM] = useState("c");
  const tk = useTick(50);
  return (
    <div>
      <Seg opts={[["c", ui("قلبية (ضغط عالي)", "Cardiac (high pressure)")], ["a", ui("ARDS (غشاء مثقوب)", "ARDS (leaky membrane)")]]} v={m} set={setM} />
      <svg viewBox="0 0 480 220" className="w-full mt-2">
        <rect width="480" height="220" rx="16" fill="#fbf7ee" />
        <rect x="20" y="120" width="440" height="60" rx="30" fill="#f1c0b8" stroke={m === "c" ? "#c0392b" : "#d48a7f"} strokeWidth={m === "c" ? 6 : 3} strokeDasharray={m === "a" ? "18 10" : ""} />
        <rect x="60" y="20" width="360" height="90" rx="40" fill="#e3f1f8" stroke="#6b8aa3" strokeWidth="2" />
        <rect x="60" y={110 - ((tk % 80) / 80) * 50} width="360" height={((tk % 80) / 80) * 50} rx="10" fill={m === "a" ? "#f0d98a" : "#bfe0f0"} opacity=".8" />
        {Array.from({ length: 8 }).map((_, i) => { const p = ((tk * 2 + i * 12) % 60) / 60; return <circle key={i} cx={90 + i * 45} cy={120 - p * 40} r={m === "a" ? 6 : 4} fill={m === "a" ? "#d9a520" : "#6fb0d6"} />; })}
        <text x="240" y="205" textAnchor="middle" fontSize="13">{m === "c" ? ui("ضغط الأوردة الرئوية ↑↑ (الأذين الأيسر)", "Pulmonary venous pressure ↑↑ (left atrium)") : ui("ضغط طبيعي – بس الجدار مثقوب: سائل غني بالبروتين", "Normal pressure – leaky wall: protein-rich fluid")}</text>
        <text x="240" y="60" textAnchor="middle" fontSize="13">{ui("السنخ", "Alveolus")}</text>
      </svg>
    </div>
  );
}

/* 22 ARDS cascade */
function ArdsCascade() {
  const { ui } = useStore();
  const steps = [
    ["⚡", ui("السبب (صدمة، التهاب، بنكرياس...)", "Trigger (shock, sepsis, pancreatitis…)")],
    ["🔥", ui("تفعيل الوسائط الالتهابية والعدلات", "Activation of mediators & neutrophils")],
    ["🧱", ui("تلف البطانة والظهارة ← نفاذية ↑", "Endothelial & epithelial damage → ↑ permeability")],
    ["💧", ui("تدفق سائل غني بالبروتين وخلايا التهابية للأسناخ", "Protein-rich fluid & cells flood alveoli")],
    ["🫧", ui("خلل السيرفاكتانت ← انكماش الأسناخ", "Surfactant dysfunction → alveolar collapse")],
    ["🪨", ui("رئة متيبسة + نقص أكسجين مقاوم", "Stiff lung + refractory hypoxia")],
  ];
  const [s, setS] = useState(0);
  return (
    <div>
      <div className="cascade">{steps.map((st, i) => <div key={i} className={"casc " + (i <= s ? "on" : "")} onClick={() => setS(i)}><span className="text-2xl">{st[0]}</span><span>{st[1]}</span></div>)}</div>
      <div className="flex gap-2 justify-center mt-3"><button className="pill" onClick={() => setS(Math.max(0, s - 1))}>‹ {ui("السابق", "Back")}</button><button className="pill on" onClick={() => setS((s + 1) % steps.length)}>{ui("التالي", "Next")} ›</button></div>
    </div>
  );
}

/* 23 PEEP */
function Peep() {
  const { ui } = useStore();
  const [peep, setPeep] = useState(0);
  const tk = useTick(50);
  const br = (Math.sin(tk / 10) + 1) / 2;
  const minR = 12 + peep * 2.6;
  const r = minR + br * (60 - minR);
  const fluid = Math.max(0, 50 - peep * 3.2);
  return (
    <div className="grid md:grid-cols-2 gap-3 items-center">
      <svg viewBox="0 0 220 200" className="w-full max-w-[260px] mx-auto">
        <rect x="100" y="0" width="20" height="40" fill="#8fb3c9" />
        <circle cx="110" cy="110" r={r} fill="#e3f1f8" stroke="#6b8aa3" strokeWidth="3" />
        <clipPath id="cp23"><circle cx="110" cy="110" r={r} /></clipPath>
        <rect x="40" y={110 + r - fluid * (r / 60)} width="140" height={fluid} fill="#f0d98a" clipPath="url(#cp23)" opacity=".85" />
        <text x="110" y="195" textAnchor="middle" fontSize="12">{r < 18 ? ui("انكماش!", "Collapse!") : ui("السنخ", "Alveolus")}</text>
      </svg>
      <div>
        <Slider label="PEEP" v={peep} set={setPeep} min={0} max={15} unit=" cmH₂O" />
        <Info tone={peep < 5 ? "#f8e7e3" : "#eef5f0"}>{peep < 5 ? ui("بدون PEEP: السنخ ينكمش بنهاية كل زفير لأن السيرفاكتانت ناقص", "No PEEP: alveolus collapses at each end-expiration (surfactant deficient)") : ui("PEEP يبقي السنخ مفتوح ويدفع السائل للخارج ← أكسجة أفضل", "PEEP keeps the alveolus open and pushes fluid out → better oxygenation")}</Info>
      </div>
    </div>
  );
}

/* 24 IPPV vs PEEP waveform */
function Ippv() {
  const { ui } = useStore();
  const [peep, setPeep] = useState(true);
  const tk = useTick(40);
  const base = peep ? 10 : 0;
  const pts = Array.from({ length: 100 }).map((_, i) => { const ph = ((i + tk) % 25) / 25; const p = ph < 0.35 ? base + Math.sin(ph / 0.35 * Math.PI / 2) * 22 : ph < 0.45 ? base + 22 : base + 22 * Math.exp(-(ph - 0.45) * 14); return `${i * 4.4},${170 - p * 4.5}`; }).join(" ");
  return (
    <div>
      <Seg opts={[["0", "IPPV (PEEP 0)"], ["1", "IPPV + PEEP 10"]]} v={peep ? "1" : "0"} set={(s) => setPeep(s === "1")} />
      <svg viewBox="0 0 440 190" className="w-full bg-[#14181b] rounded-2xl mt-2">
        <line x1="0" y1="170" x2="440" y2="170" stroke="#555" /><text x="6" y="165" fill="#888" fontSize="10">0</text>
        <line x1="0" y1={170 - base * 4.5} x2="440" y2={170 - base * 4.5} stroke="#e6c35c" strokeDasharray="5 5" />
        <polyline points={pts} fill="none" stroke="#7fd1b9" strokeWidth="3" />
        <text x="430" y="20" fill="#ddd" fontSize="11" textAnchor="end">Airway pressure</text>
      </svg>
      <Info>{peep ? ui("الخط الأصفر: الضغط ما يرجع للصفر بنهاية الزفير = PEEP", "Yellow line: pressure never returns to zero at end-expiration = PEEP") : ui("IPPV: ضغط إيجابي مع كل نفس ثم يرجع للصفر", "IPPV: positive pressure each breath, then back to zero")}</Info>
    </div>
  );
}

/* 25 O2 toxicity clock */
function O2Timer() {
  const { ui } = useStore();
  const [fio2, setF] = useState(100);
  const [h, setH] = useState(0);
  const [run, setRun] = useState(false);
  useEffect(() => { if (!run) return; const i = setInterval(() => setH((x) => (x >= 48 ? 48 : x + 1)), 150); return () => clearInterval(i); }, [run]);
  const dmg = fio2 >= 90 && h > 24 ? Math.min(1, (h - 24) / 20) : 0;
  return (
    <div className="grid md:grid-cols-2 gap-3 items-center">
      <svg viewBox="0 0 200 200" className="w-full max-w-[220px] mx-auto">
        <circle cx="100" cy="100" r="88" fill="#fffdf8" stroke="#3f3d38" strokeWidth="3" />
        <path d={`M100 100 L100 12 A88 88 0 ${h > 24 ? 1 : 0} 1 ${100 + 88 * Math.sin((h / 48) * 2 * Math.PI)} ${100 - 88 * Math.cos((h / 48) * 2 * Math.PI)} Z`} fill={dmg > 0 ? "#f2b8ad" : "#cfe6d9"} />
        <line x1="100" y1="100" x2="100" y2="188" stroke="#d16a5c" strokeWidth="2" strokeDasharray="4 3" />
        <text x="104" y="180" fontSize="10" fill="#d16a5c">24h</text>
        <text x="100" y="108" textAnchor="middle" fontSize="22" fontWeight="bold">{h}h</text>
      </svg>
      <div>
        <Seg opts={[["40", "FiO₂ 40%"], ["100", "FiO₂ 100%"]]} v={String(fio2)} set={(s) => { setF(+s); setH(0); }} />
        <div className="flex gap-2 mt-2"><button className="pill on" onClick={() => setRun(!run)}>{run ? "⏸" : "▶"}</button><button className="pill" onClick={() => { setH(0); setRun(false); }}>⟲</button></div>
        <div className="co2-bar mt-2"><div style={{ width: `${dmg * 100}%`, background: "#e07a6a" }} /><span>{ui("تلف الرئة", "Lung injury")} {Math.round(dmg * 100)}%</span></div>
        <Info tone={dmg > 0 ? "#f8e1dc" : "#eef5f0"}>{dmg > 0 ? ui("تجاوزنا 24 ساعة على أوكسجين نقي ← تهيج وتلف رئوي (سبب ARDS!)", "Beyond 24 h of pure O₂ → irritation & lung injury (an ARDS cause!)") : fio2 < 90 ? ui("التركيز المعتدل آمن لفترات أطول", "Moderate concentration is safe for longer") : ui("آمن مؤقتاً – بس لا تتجاوز 24 ساعة", "Safe temporarily – but do not exceed 24 h")}</Info>
      </div>
    </div>
  );
}

/* 26 ARDS phases timeline */
function ArdsPhases() {
  const { ui } = useStore();
  const [d, setD] = useState(0);
  const alveolar = d === 0 ? 0 : d < 7 ? Math.min(1, d / 3) : Math.max(0.3, 1 - (d - 7) / 14);
  const inter = d < 5 ? 0 : Math.min(1, (d - 5) / 10);
  const fib = d < 14 ? 0 : Math.min(1, (d - 14) / 14);
  return (
    <div className="grid md:grid-cols-2 gap-3 items-center">
      <svg viewBox="0 0 240 220" className="w-full bg-[#121416] rounded-2xl">
        <Lungs fillL="#1b1e21" fillR="#1b1e21" stroke="#555" />
        <defs><filter id="blur26"><feGaussianBlur stdDeviation="6" /></filter></defs>
        <g opacity={alveolar} filter="url(#blur26)">{Array.from({ length: 22 }).map((_, i) => <circle key={i} cx={i % 2 ? 60 + (i * 13) % 40 : 140 + (i * 17) % 50} cy={60 + (i * 23) % 120} r="16" fill="#cfcfcf" />)}</g>
        <g opacity={inter} stroke="#bdbdbd" strokeWidth="1.2">{Array.from({ length: 30 }).map((_, i) => <line key={i} x1={i % 2 ? 35 + (i * 7) % 60 : 150 + (i * 11) % 60} y1={50 + (i * 19) % 130} x2={i % 2 ? 50 + (i * 7) % 60 : 165 + (i * 11) % 60} y2={60 + (i * 19) % 130} />)}</g>
        <g opacity={fib} fill="none" stroke="#e6e6e6" strokeWidth="1.5">{Array.from({ length: 14 }).map((_, i) => <circle key={i} cx={i % 2 ? 50 + (i * 9) % 40 : 160 + (i * 13) % 40} cy={150 + (i * 7) % 35} r="6" />)}</g>
        <ellipse cx="128" cy="150" rx="26" ry="30" fill="#8a8a8a" opacity=".55" />
      </svg>
      <div>
        <Slider label={ui("اليوم", "Day")} v={d} set={setD} min={0} max={28} />
        <Info tone={d === 0 ? "#eef5f0" : d < 7 ? "#fdf3dc" : "#f8e7e3"}>{d === 0 ? ui("رئة طبيعية – قلب طبيعي", "Normal lung – normal heart") : d < 7 ? ui("المرحلة الحادة: ظلال سنخية ثنائية، قلب طبيعي، بدون خطوط كيرلي", "Acute: bilateral alveolar opacities, normal heart, no Kerley lines") : d < 14 ? ui("انتقال من ظلال سنخية إلى بينية (تدمير متزايد)", "Transition alveolar → interstitial (progressive destruction)") : ui("المرحلة المزمنة: تليف + انتفاخ بؤري", "Chronic: fibrosis + focal emphysema")}</Info>
      </div>
    </div>
  );
}

/* 27 P/F ratio */
function PfRatio() {
  const { ui } = useStore();
  const [pao2, setP] = useState(80), [fio2, setF] = useState(60);
  const pf = Math.round(pao2 / (fio2 / 100));
  return (
    <div className="grid md:grid-cols-2 gap-3 items-center">
      <div>
        <Slider label="PaO₂" v={pao2} set={setP} min={40} max={120} unit=" mmHg" />
        <Slider label="FiO₂" v={fio2} set={setF} min={21} max={100} unit="%" />
      </div>
      <div className="text-center">
        <div className="pf-big" style={{ color: pf < 200 ? "#c0392b" : pf < 300 ? "#b7791f" : "#2f7d5f" }}>{pf}</div>
        <div className="font-mono text-sm" dir="ltr">{pao2} ÷ {(fio2 / 100).toFixed(2)}</div>
        <div className="pf-bar"><div style={{ left: `${Math.min(100, (pf / 500) * 100)}%` }} /><span style={{ left: "40%" }}>200</span></div>
        <Info tone={pf < 200 ? "#f8e1dc" : "#eef5f0"}>{pf < 200 ? ui("< 200 + ارتشاحات ثنائية = ALI/ARDS شديد", "< 200 + bilateral infiltrates = severe ALI/ARDS") : ui("فوق 200 – ما ينطبق معيار الشدة", "Above 200 – severity criterion not met")}</Info>
      </div>
    </div>
  );
}

/* 28 multi-organ failure */
function Mof() {
  const { ui } = useStore();
  const tk = useTick(60);
  const organs = [["🧠", ui("الدماغ", "Brain"), 100, 30], ["🫀", ui("القلب", "Heart"), 360, 60], ["🟤", ui("الكبد", "Liver"), 90, 170], ["🫘", ui("الكلية", "Kidney"), 370, 170]] as const;
  const wave = (tk * 3) % 220;
  return (
    <svg viewBox="0 0 460 220" className="w-full">
      <rect width="460" height="220" rx="16" fill="#fbf7ee" />
      <circle cx="230" cy="110" r={wave} fill="none" stroke="#e07a6a" strokeWidth="3" opacity={1 - wave / 220} />
      <text x="230" y="118" textAnchor="middle" fontSize="34">🫁</text>
      <text x="230" y="150" textAnchor="middle" fontSize="12">{ui("تسمم الدم", "Septicaemia")}</text>
      {organs.map(([e, n, x, y], i) => { const dist = Math.hypot(x - 230, y - 110); const hit = wave > dist || (tk * 3) % 220 < 20 && false; return <g key={i}><circle cx={x} cy={y} r="28" fill={hit ? "#f6c9c0" : "#e3efe8"} stroke="#3f3d38" /><text x={x} y={y + 8} textAnchor="middle" fontSize="24">{e}</text><text x={x} y={y + 44} textAnchor="middle" fontSize="12">{n}</text></g>; })}
    </svg>
  );
}

const MAP: Record<AnimName, () => ReactNode> = {
  "investigations-wheel": Wheel, "sputum-journey": SputumJourney, "xray-beam": XrayBeam, "ct-slices": CtSlices, "us-echo": UsEcho, "vq-match": VqMatch, "pet-glucose": PetGlucose,
  bronchoscope: Bronchoscope, spirometry: Spirometry, oximeter: Oximeter, "abg-panel": AbgPanel, "pleural-tap": PleuralTap, abrams: Abrams,
  "breath-3": Breath3, "type1-type2": Type12, "vq-mismatch": VqMismatch, "hypovent-chain": HypoChain, "cyanosis-o2": CyanosisO2, "hypercapnia-brain": Hypercapnia, "o2-copd": O2Copd,
  "edema-compare": EdemaCompare, "ards-cascade": ArdsCascade, peep: Peep, ippv: Ippv, "o2-timer": O2Timer, "ards-phases": ArdsPhases, "pf-ratio": PfRatio, mof: Mof,
};
export function Anim({ name }: { name: AnimName }) { const C = MAP[name]; return <C />; }
