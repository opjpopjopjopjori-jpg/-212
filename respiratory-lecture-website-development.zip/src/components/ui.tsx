import { createContext, useContext, useEffect, useRef, useState, type ReactNode, type PointerEvent as RPE } from "react";
import type { Img, Video } from "../types";
import { useStore } from "../store";

/* ---------- Smart image with fallback to original file ---------- */
export function SmartImg({ img, className, style, draggable }: { img: Img; className?: string; style?: React.CSSProperties; draggable?: boolean }) {
  const [src, setSrc] = useState(img.src);
  const [failed, setFailed] = useState(false);
  useEffect(() => { setSrc(img.src); setFailed(false); }, [img.src]);
  if (failed) return <div className={"img-fail " + (className ?? "")}>🖼️</div>;
  return <img src={src} alt={img.cap.en} loading="lazy" draggable={draggable} referrerPolicy="no-referrer" className={className} style={style}
    onError={() => { if (img.full && src !== img.full) setSrc(img.full); else setFailed(true); }} />;
}

/* ---------- Zoom & pan surface ---------- */
export function ZoomPan({ children, className, minH = 300, controls = true }: { children: ReactNode; className?: string; minH?: number; controls?: boolean }) {
  const [z, setZ] = useState(1);
  const [p, setP] = useState({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null);
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = box.current; if (!el) return;
    const wheel = (e: WheelEvent) => { e.preventDefault(); setZ((v) => Math.min(6, Math.max(1, v * (e.deltaY < 0 ? 1.15 : 0.87)))); };
    el.addEventListener("wheel", wheel, { passive: false });
    return () => el.removeEventListener("wheel", wheel);
  }, []);
  useEffect(() => { if (z === 1) setP({ x: 0, y: 0 }); }, [z]);
  const down = (e: RPE) => { drag.current = { x: e.clientX, y: e.clientY, px: p.x, py: p.y }; (e.target as HTMLElement).setPointerCapture?.(e.pointerId); };
  const move = (e: RPE) => { if (!drag.current || z === 1) return; setP({ x: drag.current.px + (e.clientX - drag.current.x) / z, y: drag.current.py + (e.clientY - drag.current.y) / z }); };
  const up = () => { drag.current = null; };
  return (
    <div className={"zoompan " + (className ?? "")} style={{ minHeight: minH }}>
      <div ref={box} className="zp-stage" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerLeave={up} onDoubleClick={() => setZ((v) => (v > 1 ? 1 : 2.5))}
        style={{ cursor: z > 1 ? "grab" : "zoom-in" }}>
        <div className="zp-inner" style={{ transform: `scale(${z}) translate(${p.x}px, ${p.y}px)` }}>{children}</div>
      </div>
      {controls && <div className="zp-ctrls">
        <button onClick={() => setZ((v) => Math.min(6, v * 1.3))} aria-label="zoom in">＋</button>
        <span>{Math.round(z * 100)}%</span>
        <button onClick={() => setZ((v) => Math.max(1, v / 1.3))} aria-label="zoom out">－</button>
        <button onClick={() => { setZ(1); setP({ x: 0, y: 0 }); }} aria-label="reset">⟲</button>
      </div>}
    </div>
  );
}

/* ---------- Lightbox ---------- */
const LB = createContext<(list: Img[], i: number) => void>(() => {});
export const useLightbox = () => useContext(LB);
export function LightboxProvider({ children }: { children: ReactNode }) {
  const [st, setSt] = useState<{ list: Img[]; i: number } | null>(null);
  const { tr } = useStore();
  useEffect(() => {
    if (!st) return;
    const k = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSt(null);
      if (e.key === "ArrowRight") setSt((s) => s && { ...s, i: (s.i + 1) % s.list.length });
      if (e.key === "ArrowLeft") setSt((s) => s && { ...s, i: (s.i - 1 + s.list.length) % s.list.length });
    };
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, [st]);
  const img = st?.list[st.i];
  return (
    <LB.Provider value={(list, i) => setSt({ list, i })}>
      {children}
      {st && img && (
        <div className="lb" onClick={() => setSt(null)}>
          <div className="lb-body" onClick={(e) => e.stopPropagation()}>
            <ZoomPan className="lb-zp" minH={0} key={img.src}>
              <SmartImg img={{ ...img, src: img.full && img.full.length < 400 ? img.src : img.src }} className="lb-img" draggable={false} />
            </ZoomPan>
            <div className="lb-bar">
              <button className="lb-btn" onClick={() => setSt({ ...st, i: (st.i - 1 + st.list.length) % st.list.length })}>‹</button>
              <div className="flex-1 text-center px-2"><div className="font-semibold">{tr(img.cap)}</div><div className="text-xs opacity-70">{img.credit} · {st.i + 1}/{st.list.length}</div></div>
              <button className="lb-btn" onClick={() => setSt({ ...st, i: (st.i + 1) % st.list.length })}>›</button>
              <button className="lb-btn" onClick={() => setSt(null)}>✕</button>
            </div>
          </div>
        </div>
      )}
    </LB.Provider>
  );
}

/* ---------- Gallery: fills the full row, never leaves gaps ---------- */
export function Gallery({ items }: { items: Img[] }) {
  const open = useLightbox();
  const { tr } = useStore();
  return (
    <div className={"fill-grid gallery n" + items.length}>
      {items.map((img, i) => (
        <figure key={img.src + i} className="photo-card" style={{ ["--r" as string]: `${((i * 37) % 5) - 2}deg` }}>
          <span className="tape" />
          <button className="photo-frame" onClick={() => open(items, i)} aria-label="open">
            <SmartImg img={img} className="photo-img" />
            <span className="zoom-hint">⤢</span>
          </button>
          <figcaption className="photo-cap"><span>{tr(img.cap)}</span><span className="credit">{img.credit?.replace("Wikimedia Commons · ", "WM · ")}</span></figcaption>
        </figure>
      ))}
    </div>
  );
}

/* ---------- Videos: direct watch links (never a search page) ---------- */
export function Videos({ items }: { items: Video[] }) {
  const { tr, ui } = useStore();
  return (
    <div className={"fill-grid videos n" + items.length}>
      {items.map((v) => (
        <a key={v.id} className="video-card" href={`https://www.youtube.com/watch?v=${v.id}`} target="_blank" rel="noopener noreferrer">
          <div className="vc-inner">
          <div className="video-thumb">
            <img src={`https://i.ytimg.com/vi/${v.id}/hqdefault.jpg`} alt={v.title} loading="lazy" />
            <span className="play-btn">▶</span>
            <span className="dur">{v.dur}</span>
            <span className="vlang">{v.lang === "EN" ? "English" : "عربي"}</span>
          </div>
          <div className="p-3">
            <div className="font-bold text-[0.95rem] leading-snug" dir="ltr">{v.title}</div>
            <div className="text-xs text-[#8a857a] mt-1" dir="ltr">{v.channel} · YouTube</div>
            <div className="text-sm mt-2 text-[#5b5546]">🎯 {tr(v.note)}</div>
            <div className="text-xs mt-2 font-semibold text-[#5f8f7b]">{ui("يفتح الفيديو مباشرة ↗", "Opens the video directly ↗")}</div>
          </div>
          </div>
        </a>
      ))}
    </div>
  );
}

export function Sticker({ children, color = "#f6e3b4", rot = -6 }: { children: ReactNode; color?: string; rot?: number }) {
  return <span className="sticker" style={{ background: color, transform: `rotate(${rot}deg)` }}>{children}</span>;
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={"soft-card " + className}>{children}</div>;
}
