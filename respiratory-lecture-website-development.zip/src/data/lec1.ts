import { t, type Lecture } from "../types";
import { IMG, VID } from "./media";

export const lec1: Lecture = {
  id: "lec1", num: 1, emoji: "🔬", color: "#7fb39b", lecturer: "Prof. Dr. Mohammed Waheeb",
  title: t("مقدمة في طب الجهاز التنفسي: الفحوصات", "Introduction to Respiratory Medicine: Investigations"),
  summary: t(
    "هاي المحاضرة تعلمك 'صندوق العدة' مال طبيب الصدرية: كل فحص شنو يشوف، ولأي مرض نستخدمه، وشلون تبين النتيجة غير الطبيعية.",
    "This lecture is the chest physician's 'toolbox': what each test shows, which disease it is used for, and how an abnormal result looks."
  ),
  objectives: [
    t("التعرف على أنواع الفحوصات المختلفة المستخدمة في أمراض الجهاز التنفسي.", "Recognize the different types of investigations used in respiratory diseases."),
    t("الربط بين أمراض الجهاز التنفسي الشائعة والفحص الخاص بكل منها.", "Relate common respiratory diseases to their specific investigation."),
    t("تحديد النتائج غير الطبيعية للفحوصات في بعض الأمراض الشائعة.", "Identify investigational abnormalities in some common respiratory disorders."),
  ],
  sections: [
    {
      id: "overview", icon: "🧭", title: t("نظرة عامة: الفحوصات الست", "Overview: The Six Investigations"),
      blocks: [
        { k: "lead", text: t(
          "قبل ما نبدي: الطبيب يشخص من القصة المرضية والفحص السريري، بس الفحوصات (Investigations) هي اللي تأكد التشخيص وتبين شدته وتتابع العلاج. بالجهاز التنفسي عدنا 6 مجاميع رئيسية من الفحوصات، كل وحدة تجاوب على سؤال مختلف.",
          "Before we start: the doctor diagnoses from history and examination, but investigations confirm the diagnosis, show its severity and follow treatment. In the respiratory system there are 6 main groups of investigations, each answering a different question."
        )},
        { k: "anim", name: "investigations-wheel", title: t("عجلة الفحوصات التفاعلية", "Interactive investigations wheel"), caption: t("اضغط على كل قطعة حتى تعرف السؤال اللي يجاوب عليه الفحص", "Tap each slice to see the question each test answers") },
        { k: "list", check: true, title: t("الفحوصات المذكورة في المحاضرة (أشّر على اللي فهمته)", "Investigations listed in the lecture (tick what you understood)"), items: [
          t("تحليل البصاق (Sputum Analysis) – شنو الجرثومة؟ هل اكو خلايا سرطانية؟", "Sputum analysis – which organism? Any malignant cells?"),
          t("الأشعة (Radiology) – شكل الرئة والقلب والمنصف من الداخل", "Radiology – the structure of lung, heart and mediastinum"),
          t("فحص وظائف الرئة (Pulmonary function testing) – شكد الرئة تشتغل زين؟", "Pulmonary function testing – how well do the lungs work?"),
          t("قياس الأكسجين وغازات الدم الشرياني (Oximetry & ABG) – هل تبادل الغازات سليم؟", "Oximetry & arterial blood gases – is gas exchange intact?"),
          t("التنظير (Endoscopic examination) – نشوف من الداخل ونأخذ عينات", "Endoscopy – look inside and take samples"),
          t("فحوصات أمراض الجنب (Pleural investigations) – سائل أو نسيج من غشاء الجنب", "Pleural investigations – fluid or tissue from the pleura"),
        ]},
        { k: "three", name: "lungs", title: t("نموذج ثلاثي الأبعاد: الرئتين والشجرة القصبية", "3D model: lungs & bronchial tree"), caption: t("اسحب للتدوير – لاحظ القصبة والقصيبات والأسناخ. كل فحص يستهدف جزء منها", "Drag to rotate – notice trachea, bronchi and alveoli. Each test targets a part") },
        { k: "callout", tone: "memory", title: t("حيلة للحفظ: S-R-P-O-E-P", "Memory trick: S-R-P-O-E-P"), body: t(
          "Sputum → Radiology → PFT → Oximetry/ABG → Endoscopy → Pleura. فكر بيها كرحلة: من اللي يطلع من المريض (بصاق) ← صورته (أشعة) ← وظيفته (PFT) ← دمه (ABG) ← ندخل داخله (منظار) ← غلافه (الجنب).",
          "Sputum → Radiology → PFT → Oximetry/ABG → Endoscopy → Pleura. Think of a journey: what comes out (sputum) → its picture (radiology) → its function (PFT) → its blood (ABG) → go inside (scope) → its covering (pleura)."
        )},
      ],
    },
    {
      id: "sputum", icon: "🧫", title: t("تحليل البصاق (Sputum)", "Sputum Analysis"),
      blocks: [
        { k: "lead", text: t(
          "البصاق (Sputum) هو المخاط اللي يطلع من الرئة والقصبات بالكحة – مو اللعاب اللي بالفم. لأنه جاي من داخل الرئة، فهو يحمل معاه الجراثيم والخلايا الموجودة هناك، فيصير 'رسالة' من الرئة نقدر نقرأها بالمختبر.",
          "Sputum is mucus coughed up from the lungs and bronchi – not saliva from the mouth. Because it comes from inside the lung it carries the organisms and cells present there, making it a 'message' from the lung we can read in the lab."
        )},
        { k: "explain", icon: "🎯", tone: "mint", title: t("ليش نفحص البصاق؟ سببين رئيسيين", "Why test sputum? Two main reasons"), body: t(
          "1) الالتهابات البكتيرية والفطرية (Bacterial & fungal infection): نزرع البصاق ونصبغه حتى نعرف نوع الجرثومة ونختار المضاد المناسب. أهم مثال هو السل (Tuberculosis) – وهو فحص شائع جداً بالعراق.\n2) فحص الخلايا (Cytology): إذا شكينا بسرطان القصبات (Bronchial cancer)، نفحص البصاق تحت المجهر نبحث عن خلايا خبيثة (Malignant cells) انفصلت من الورم وطلعت ويا البصاق.",
          "1) Bacterial & fungal infection: we culture and stain sputum to identify the organism and choose the right antibiotic. The key example is tuberculosis – very commonly tested in Iraq.\n2) Cytology: when bronchial cancer is suspected, we examine sputum under the microscope looking for malignant cells shed from the tumour."
        )},
        { k: "disease", items: [
          { name: "Pulmonary Tuberculosis (PTB)", icon: "🦠", what: t("التهاب مزمن بالرئة تسببه بكتيريا Mycobacterium tuberculosis، تنتقل بالرذاذ (الكحة والعطاس).", "Chronic lung infection caused by Mycobacterium tuberculosis, spread by droplets (cough & sneeze)."), cause: t("الأعراض: كحة أكثر من أسبوعين، حمى مسائية، تعرق ليلي، نقص وزن، وأحياناً نفث دم.", "Symptoms: cough > 2 weeks, evening fever, night sweats, weight loss, sometimes hemoptysis."), sign: t("بالبصاق: صبغة Ziehl-Neelsen تبين العصيات بلون أحمر/وردي = Acid-Fast Bacilli (AFB) لأنها تقاوم إزالة الصبغة بالحامض.", "In sputum: Ziehl-Neelsen stain shows red/pink rods = Acid-Fast Bacilli (AFB) because they resist acid decolourisation.") },
          { name: "Malignant cells", icon: "🔴", what: t("خلايا سرطانية شكلها شاذ: نواة كبيرة وداكنة، شكل غير منتظم، وحجم مختلف عن الخلايا الطبيعية.", "Cancer cells with abnormal shape: large dark nuclei, irregular outline, variable size."), cause: t("تنفصل من ورم القصبات وتطلع ويا البصاق، خصوصاً الأورام المركزية القريبة من القصبات الكبيرة.", "Shed from a bronchial tumour into sputum, especially central tumours near large bronchi."), sign: t("فحص الخلايا (Cytology) إيجابي = يدعم تشخيص سرطان القصبات، بس التشخيص النهائي يحتاج خزعة.", "Positive cytology supports bronchial cancer, but final diagnosis needs biopsy.") },
          { name: "Hemoptysis", icon: "🩸", what: t("نفث الدم = خروج دم مع الكحة من الجهاز التنفسي السفلي (مو من المعدة ولا من الأنف).", "Coughing up blood from the lower respiratory tract (not from stomach or nose)."), cause: t("أهم أسبابه: السل، سرطان القصبات، توسع القصبات، الصمة الرئوية، والتهاب الرئة.", "Main causes: TB, bronchial cancer, bronchiectasis, pulmonary embolism, pneumonia."), sign: t("في السلايد ظهر كمثال على بصاق مدمى – هذا إنذار يستوجب فحص البصاق للسل والخلايا الخبيثة.", "Shown in the slides as blood-stained sputum – an alarm requiring sputum testing for TB and malignant cells.") },
        ]},
        { k: "images", items: [IMG.afb, IMG.zn, IMG.hemoptysis, IMG.cytology] },
        { k: "anim", name: "sputum-journey", title: t("رحلة عينة البصاق من المريض للمجهر", "The sputum sample journey: from patient to microscope"), caption: t("شاهد شلون العينة تنجمع، تنصبغ، وتنفحص – وشنو يطلع إذا كانت إيجابية", "Watch how the sample is collected, stained and examined – and what a positive result looks like") },
        { k: "steps", title: t("شلون نجمع عينة بصاق صحيحة؟", "How to collect a good sputum sample?"), items: [
          { title: t("الصبح على الريك", "Early morning"), body: t("أول عينة بالصبح تكون الأغنى بالجراثيم لأن الإفرازات تتجمع طول الليل.", "The first morning sample is richest in organisms as secretions accumulate overnight.") },
          { title: t("مضمضة بالماء فقط", "Rinse with water only"), body: t("حتى نقلل التلوث بجراثيم الفم، بدون معجون أو غسول.", "To reduce mouth-flora contamination – no toothpaste or mouthwash.") },
          { title: t("كحة عميقة من الصدر", "Deep cough from the chest"), body: t("المطلوب بصاق من الرئة مو لعاب. العينة الجيدة سميكة وملونة.", "We need lung sputum, not saliva. A good sample is thick and coloured.") },
          { title: t("علبة معقمة ومحكمة", "Sterile sealed container"), body: t("وتنرسل للمختبر بسرعة. للسل عادة نطلب عينتين إلى ثلاث عينات.", "Sent quickly to the lab. For TB we usually request 2–3 samples.") },
        ]},
        { k: "video", items: [VID.sputum, VID.zn, VID.afb, VID.sputumTb] },
        { k: "confuse", items: [
          { a: "Hemoptysis", b: "Hematemesis", how: t("نفث الدم: دم أحمر فاتح رغوي مع كحة، قلوي. قيء الدم: دم داكن (مثل تفل القهوة) مع قيء، حامضي، وقد يكون معه بقايا أكل.", "Hemoptysis: bright red frothy blood with cough, alkaline. Hematemesis: dark (coffee-ground) blood with vomiting, acidic, may contain food.") },
          { a: "Sputum", b: "Saliva", how: t("البصاق من الرئة (سميك، يحتوي خلايا التهابية وخلايا بلعمية Macrophages). اللعاب من الفم (مائي شفاف) وما يفيد بالفحص.", "Sputum is from the lung (thick, contains inflammatory cells & macrophages). Saliva is from the mouth (watery clear) and is useless for testing.") },
        ]},
      ],
    },
    {
      id: "cxr", icon: "🩻", title: t("الأشعة: صورة الصدر (Chest X-ray)", "Radiology: Chest X-ray"),
      blocks: [
        { k: "lead", text: t(
          "المحاضرة تذكر 5 أنواع أشعة: (1) صورة الصدر (2) المفراس CT (3) السونار (4) فحص التهوية-التروية (5) PET. نبدأ بأولها وأكثرها استخداماً: صورة الصدر البسيطة، وهي تنعمل لأغلب المرضى المشكوك عندهم مرض صدري.",
          "The lecture lists 5 imaging types: (1) chest X-ray (2) CT (3) ultrasound (4) ventilation–perfusion imaging (5) PET. We start with the first and most used: the plain chest X-ray, performed on the majority of patients suspected of chest disease."
        )},
        { k: "list", check: true, title: t("صورة الصدر تعطي معلومات عن 5 أشياء:", "The chest X-ray gives information on 5 things:"), items: [
          t("حقول الرئة (Lung fields): سوداء لأنها مليانة هواء – أي بياض فيها = شي غير طبيعي (سائل، التهاب، ورم).", "Lung fields: black because full of air – any whiteness = abnormal (fluid, infection, tumour)."),
          t("القلب (Heart): حجمه وشكله – عرض القلب أقل من نصف عرض الصدر بالـ PA.", "Heart: size and shape – cardiac width less than half chest width on PA."),
          t("المنصف (Mediastinum): المنطقة الوسطية بين الرئتين (القلب، القصبة، المريء، الأوعية الكبيرة، العقد اللمفاوية).", "Mediastinum: central area between lungs (heart, trachea, oesophagus, great vessels, lymph nodes)."),
          t("التراكيب الوعائية (Vascular structures): الأوعية الرئوية والسرّة (Hilum).", "Vascular structures: pulmonary vessels and the hila."),
          t("القفص الصدري (Thoracic cage): الأضلاع، الترقوة، الفقرات، والحجاب الحاجز.", "Thoracic cage: ribs, clavicles, vertebrae and diaphragm."),
        ]},
        { k: "anim", name: "xray-beam", title: t("ليش الهواء أسود والعظم أبيض؟", "Why is air black and bone white?"), caption: t("حرّك الشريط: كل نسيج يمتص كمية مختلفة من الأشعة", "Move the slider: each tissue absorbs a different amount of X-rays") },
        { k: "table", title: t("سلم الكثافات بالأشعة (من الأسود للأبيض)", "Density scale on X-ray (black → white)"), head: [t("النسيج", "Tissue"), t("اللون", "Colour"), t("مثال بالصدر", "Chest example")], rows: [
          [t("هواء", "Air"), t("أسود", "Black"), t("الرئة الطبيعية، استرواح الصدر", "Normal lung, pneumothorax")],
          [t("دهون", "Fat"), t("رمادي غامق", "Dark grey"), t("تحت الجلد", "Subcutaneous")],
          [t("سوائل/أنسجة رخوة", "Fluid / soft tissue"), t("رمادي فاتح-أبيض", "Light grey-white"), t("القلب، الانصباب، الالتهاب", "Heart, effusion, consolidation")],
          [t("عظم", "Bone"), t("أبيض", "White"), t("الأضلاع والترقوة", "Ribs and clavicles")],
          [t("معدن", "Metal"), t("أبيض ناصع", "Bright white"), t("أسلاك، صمامات", "Wires, valves")],
        ]},
        { k: "images", items: [IMG.cxr, IMG.pneumonia, IMG.effCxr, IMG.ptx] },
        { k: "callout", tone: "tip", title: t("لماذا هي أول فحص؟", "Why is it the first test?"), body: t("رخيصة، سريعة، متوفرة بكل مستشفى، وجرعة إشعاعها قليلة جداً – وتعطي صورة شاملة تحدد شنو الفحص اللي بعدها.", "Cheap, fast, available everywhere, very low radiation – and gives an overview that decides the next test.") },
      ],
    },
    {
      id: "ct", icon: "🌀", title: t("المفراس (CT)", "Computed Tomography (CT)"),
      blocks: [
        { k: "lead", text: t(
          "المفراس (Computed Tomography) يستخدم نفس أشعة X بس الأنبوب يدور حول المريض 360 درجة، والكمبيوتر يجمع الصور ويطلع 'شرائح' عرضية للجسم مثل تقطيع رغيف الخبز. هيج نشوف كل شي بدون تداخل التراكيب فوق بعضها.",
          "CT uses the same X-rays but the tube rotates 360° around the patient, and the computer builds cross-sectional 'slices' of the body like slicing a loaf of bread. This shows everything without structures overlapping."
        )},
        { k: "list", check: true, title: t("شنو يميز الـ CT حسب المحاضرة؟", "What makes CT special (per the lecture)?"), items: [
          t("يعطي صور مفصلة لنسيج الرئة (Pulmonary parenchyma)، المنصف (Mediastinum)، الجنب (Pleura)، والعظام (Bony structures).", "Gives detailed images of the pulmonary parenchyma, mediastinum, pleura and bony structures."),
          t("التراكيب الطبيعية وغير الطبيعية تظهر 'بوضوح' بالـ CT.", "Normal and abnormal structures are seen 'clearly' by CT."),
          t("أخذ عينة (خزعة) من كتلة بالرئة أو الجنب ممكن يكون موجّه بالـ CT (CT-guided biopsy).", "Sampling of a lung/pleural mass can be guided by CT (CT-guided biopsy)."),
        ]},
        { k: "three", name: "ctgantry", title: t("نموذج 3D: جهاز المفراس وهو يصنع الشرائح", "3D model: CT gantry building slices"), caption: t("لاحظ دوران الأنبوب وحركة السرير وتكوّن الشرائح واحدة بعد الأخرى", "Watch the tube rotate, the table move and slices form one after another") },
        { k: "anim", name: "ct-slices", title: t("من الجسم إلى الشريحة", "From body to slice"), caption: t("اسحب الشريط لتنقل مستوى الشريحة من الأعلى للأسفل", "Drag the slider to move the slice level from top to bottom") },
        { k: "images", items: [IMG.ctScanner, IMG.ctpa, IMG.uip, IMG.emphysema] },
        { k: "explain", icon: "🪡", tone: "sky", title: t("شنو يعني CT-guided biopsy؟", "What does CT-guided biopsy mean?"), body: t(
          "إذا عدنا كتلة (Mass) بالرئة أو الجنب ونريد نعرف هل هي سرطان أو سل أو غيرها، لازم نأخذ قطعة صغيرة منها (خزعة). الطبيب يدخل إبرة من جلد الصدر، والمفراس يصور أثناء الإدخال حتى يشوف مكان رأس الإبرة بالضبط ويوصل للكتلة بدون ما يضر الأوعية.",
          "If there is a lung or pleural mass and we need to know if it is cancer, TB or other, we must take a small piece (biopsy). The doctor inserts a needle through the chest wall while CT images during insertion to see the needle tip exactly and reach the mass without injuring vessels."
        )},
        { k: "video", items: [VID.ct, VID.ctBiopsy] },
        { k: "compare", title: t("صورة الصدر مقابل المفراس", "Chest X-ray vs CT"), a: { title: t("Chest X-ray", "Chest X-ray"), points: [t("صورة واحدة مسطحة (2D) والتراكيب فوق بعضها", "Single flat (2D) image, structures overlap"), t("إشعاع قليل جداً، رخيصة", "Very low radiation, cheap"), t("أول فحص لأغلب المرضى", "First test for most patients")] }, b: { title: t("CT", "CT"), points: [t("شرائح عرضية مفصلة بدون تداخل", "Detailed cross-sections without overlap"), t("إشعاع أكثر، أغلى", "More radiation, more expensive"), t("لتوضيح التفاصيل وتوجيه الخزعة", "To clarify details and guide biopsy")] } },
      ],
    },
    {
      id: "us", icon: "📡", title: t("السونار (Ultrasound)", "Ultrasound"),
      blocks: [
        { k: "lead", text: t(
          "السونار يستخدم موجات صوتية عالية التردد (مو إشعاع). الموجة ترتد من الأنسجة وترجع للجهاز فيكوّن صورة. السائل ما يعكس الصوت فيظهر أسود، لهذا السونار حساس جداً لكشف سائل الجنب (Pleural effusion) حتى لو كمية قليلة.",
          "Ultrasound uses high-frequency sound waves (not radiation). Waves echo back from tissues to form an image. Fluid doesn't reflect sound so it appears black – that is why ultrasound is very sensitive for detecting pleural fluid (effusion), even small amounts."
        )},
        { k: "explain", icon: "💧", tone: "sky", title: t("شنو هو الانصباب الجنبي (Pleural effusion)؟", "What is a pleural effusion?"), body: t(
          "الرئة مغلفة بغشائين (الجنب – Pleura) وبيناتهم مسافة فيها كمية قليلة جداً من السائل للتزليق. إذا تجمع سائل زايد بهاي المسافة يسمى انصباب جنبي. أسبابه كثيرة: عجز القلب، الالتهابات، السل، السرطان. المريض يحس بضيق نفس، وبالفحص نسمع أصمية (Stony dullness) وغياب أصوات التنفس.",
          "The lung is covered by two membranes (the pleura) with a tiny amount of lubricating fluid between them. Excess fluid accumulating in this space is a pleural effusion. Causes: heart failure, infection, TB, cancer. The patient feels breathless; on exam there is stony dullness and absent breath sounds."
        )},
        { k: "anim", name: "us-echo", title: t("شلون السونار يشوف السائل؟", "How ultrasound sees fluid"), caption: t("الموجات ترتد من النسيج (أبيض) وتعبر السائل بدون صدى (أسود)", "Waves echo from tissue (white) and pass through fluid without echo (black)") },
        { k: "images", items: [IMG.usEff, IMG.effCxr] },
        { k: "callout", tone: "exam", title: t("نقطة امتحانية", "Exam point"), body: t("السونار هو الأكثر حساسية لكشف الانصباب الجنبي، ويستخدم كمان لتوجيه الإبرة أثناء بزل الجنب حتى نعرف أحسن مكان للسحب.", "Ultrasound is the most sensitive for detecting pleural effusion, and is also used to guide the needle during pleural aspiration.") },
        { k: "video", items: [VID.lungUs, VID.lungUs2] },
      ],
    },
    {
      id: "vq", icon: "☢️", title: t("فحص التهوية-التروية (V/Q)", "Ventilation–Perfusion Imaging"),
      blocks: [
        { k: "lead", text: t(
          "V = Ventilation (التهوية: الهواء الواصل للأسناخ)، Q = Perfusion (التروية: الدم الواصل للأسناخ). بهذا الفحص المريض يستنشق مادة مشعة (لتصوير التهوية) وتنزرق له مادة مشعة بالوريد (لتصوير التروية)، وتنصور الرئتين بكاميرا كاما (Gamma camera).",
          "V = ventilation (air reaching alveoli), Q = perfusion (blood reaching alveoli). The patient inhales a radioactive tracer (ventilation) and receives an IV tracer (perfusion), and the lungs are imaged with a gamma camera."
        )},
        { k: "list", check: true, title: t("نقاط المحاضرة", "Lecture points"), items: [
          t("الرئتين تتصور باستخدام كاميرا كاما (Gamma camera).", "The lungs are imaged using a gamma camera."),
          t("الصمة الرئوية (Pulmonary embolism) ممكن تنكشف بهذا الفحص.", "Pulmonary embolism can be detected with this test."),
          t("هذا الفحص استُبدل بالمفراس (CT chest – CTPA).", "This test has been replaced by CT chest (CTPA)."),
        ]},
        { k: "explain", icon: "🧩", tone: "lilac", title: t("شنو هي الصمة الرئوية؟ وليش V/Q يكشفها؟", "What is pulmonary embolism, and why does V/Q detect it?"), body: t(
          "الصمة الرئوية = خثرة دم (غالباً من أوردة الساق – DVT) تنفصل وتمشي بالدم إلى أن تسد شريان بالرئة. النتيجة: المنطقة اللي وراها يوصلها هواء طبيعي (V طبيعي) بس ما يوصلها دم (Q = صفر). هذا اسمه 'عدم تطابق' (Mismatch) وهو العلامة المميزة للصمة بفحص V/Q: تهوية موجودة + تروية مفقودة.",
          "Pulmonary embolism = a blood clot (usually from leg veins – DVT) that breaks off and travels until it blocks a lung artery. The area beyond still receives air (normal V) but no blood (Q = zero). This 'mismatch' is the hallmark of PE on V/Q: ventilation present + perfusion absent."
        )},
        { k: "anim", name: "vq-match", title: t("تطابق مقابل عدم تطابق", "Matched vs mismatched"), caption: t("بدّل بين الرئة الطبيعية والصمة: لاحظ الفرق بين صورة التهوية وصورة التروية", "Toggle normal vs PE: compare the ventilation and perfusion images") },
        { k: "images", items: [IMG.vq, IMG.gamma, IMG.ctpa, IMG.ctpaRv] },
        { k: "video", items: [VID.vq, VID.pe, VID.vq2] },
        { k: "past", ids: ["p14"] },
      ],
    },
    {
      id: "pet", icon: "✨", title: t("التصوير المقطعي بالإصدار البوزيتروني (PET)", "Positron Emission Tomography (PET)"),
      blocks: [
        { k: "lead", text: t(
          "الخلايا السرطانية 'شرهة' – تنقسم بسرعة وتحتاج طاقة هواية، فتسحب الغلوكوز أكثر بكثير من الخلايا الطبيعية. بالـ PET نزرق غلوكوز مُعلّم بمادة مشعة (FDG)، فالأماكن اللي تلتهمه بشراهة تضوي بالصورة.",
          "Cancer cells are 'greedy' – they divide fast and need lots of energy, so they absorb far more glucose than normal cells. In PET we inject radio-labelled glucose (FDG), and areas that avidly consume it light up."
        )},
        { k: "list", check: true, title: t("نقاط المحاضرة", "Lecture points"), items: [
          t("أجهزة PET تبين قابلية النسيج الخبيث العالية (Avid ability) لامتصاص الغلوكوز وأيضه.", "PET scanners show the avid ability of malignant tissue to absorb and metabolize glucose."),
          t("يستخدم بشكل رئيسي لكشف انتشار الأورام الخبيثة (Metastasis).", "Used largely in detecting malignant tumour metastasis."),
        ]},
        { k: "three", name: "pet", title: t("نموذج 3D: الغلوكوز المشع يتجمع بالورم", "3D model: radioactive glucose collects in the tumour"), caption: t("جزيئات الغلوكوز تتوزع بالجسم وتتجمع بالبؤر السرطانية فتضوي", "Glucose particles spread through the body and accumulate in tumour foci, which glow") },
        { k: "anim", name: "pet-glucose", title: t("خلية طبيعية مقابل خلية سرطانية", "Normal cell vs cancer cell"), caption: t("شوف منو يسحب الغلوكوز أكثر", "See which one pulls more glucose") },
        { k: "images", items: [IMG.pet] },
        { k: "callout", tone: "def", title: t("شنو يعني Metastasis؟", "What is metastasis?"), body: t("انتشار الخلايا السرطانية من مكانها الأصلي إلى أعضاء ثانية (مثل العقد اللمفاوية، الكبد، العظم، الدماغ). الـ PET يمسح الجسم كله مرة وحدة، فيكشف هاي البؤر البعيدة.", "Spread of cancer cells from their origin to other organs (lymph nodes, liver, bone, brain). PET scans the whole body at once, revealing these distant foci.") },
        { k: "video", items: [VID.pet, VID.petCt] },
      ],
    },
    {
      id: "endo", icon: "🔦", title: t("التنظير (Endoscopy)", "Endoscopic Examination"),
      blocks: [
        { k: "lead", text: t(
          "التنظير = إدخال أنبوب فيه كاميرا وضوء حتى نشوف من الداخل مباشرة، ونقدر نأخذ عينات (خزعة، غسل، سحب). المحاضرة تذكر 5 أنواع، كل واحد يدخل لمكان مختلف.",
          "Endoscopy = inserting a tube with a camera and light to look inside directly and take samples (biopsy, washing, aspiration). The lecture lists 5 types, each entering a different place."
        )},
        { k: "disease", items: [
          { name: "Bronchoscopy", icon: "🫁", what: t("تنظير القصبات: المنظار يدخل من الأنف أو الفم ← الحنجرة ← القصبة الهوائية ← القصبات.", "Bronchoscope enters via nose/mouth → larynx → trachea → bronchi."), cause: t("نشوف الأورام داخل القصبات، نأخذ خزعة، نغسل القصبات (BAL) لفحص الجراثيم والخلايا، ونشيل الأجسام الغريبة.", "See endobronchial tumours, take biopsies, perform lavage (BAL) for organisms and cells, remove foreign bodies."), sign: t("نوعين: مرن (Flexible) – الأكثر استخداماً بتخدير موضعي؛ صلب (Rigid) – بتخدير عام ويحتاج مد الرقبة للخلف.", "Two types: flexible – most common, local anaesthesia; rigid – general anaesthesia, requires neck hyperextension.") },
          { name: "Mediastinoscopy", icon: "🎯", what: t("تنظير المنصف: فتحة صغيرة فوق عظم القص والمنظار ينزل للمنصف.", "Small incision above the sternum; scope passes into the mediastinum."), cause: t("لأخذ خزعات من العقد اللمفاوية المنصفية – مهم لتحديد مرحلة سرطان الرئة أو تشخيص السل والساركويد واللمفوما.", "To biopsy mediastinal lymph nodes – important for lung cancer staging or diagnosing TB, sarcoid, lymphoma.") },
          { name: "Laryngoscopy", icon: "🗣️", what: t("تنظير الحنجرة: نشوف الحنجرة والأحبال الصوتية.", "View the larynx and vocal cords."), cause: t("لتقييم بحة الصوت، أورام الحنجرة، شلل الحبل الصوتي (مثلاً من ورم رئوي يضغط على العصب الراجع)، وتستخدم أثناء إدخال أنبوب التنفس.", "To assess hoarseness, laryngeal tumours, vocal cord palsy (e.g. lung tumour compressing the recurrent laryngeal nerve), and during intubation.") },
          { name: "Thoracoscopy", icon: "🔭", what: t("تنظير الصدر: المنظار يدخل بين الأضلاع إلى تجويف الجنب.", "Scope enters between ribs into the pleural cavity."), cause: t("نشوف سطح الجنب والرئة مباشرة، نأخذ خزعات من الجنب، ونسحب السائل – وجراحياً يسمى VATS.", "Directly view pleura and lung surface, biopsy the pleura, drain fluid – surgically called VATS.") },
          { name: "Pleuroscope", icon: "💡", what: t("تنظير الجنب الطبي (Medical thoracoscopy): نسخة أبسط تنعمل من طبيب الصدرية بتخدير موضعي.", "Medical thoracoscopy: a simpler version performed by the chest physician under local anaesthesia."), cause: t("يستخدم بشكل خاص لتشخيص سبب الانصباب الجنبي (سل أو سرطان) وأخذ خزعات موجهة بالنظر.", "Used especially to diagnose the cause of pleural effusion (TB or cancer) with visually guided biopsies.") },
        ]},
        { k: "three", name: "bronchtree", title: t("نموذج 3D: رحلة المنظار داخل الشجرة القصبية", "3D model: the bronchoscope journey through the bronchial tree"), caption: t("تابع رأس المنظار المضيء وهو يتفرع من القصبة إلى القصيبات", "Follow the glowing scope tip branching from trachea to bronchioles") },
        { k: "anim", name: "bronchoscope", title: t("شنو يشوف الطبيب من الكاميرا؟", "What does the doctor see on the camera?"), caption: t("اضغط على المحطات: الحنجرة ← القصبة ← الجؤجؤ (Carina) ← القصبات", "Tap the stations: larynx → trachea → carina → bronchi") },
        { k: "images", items: [IMG.bronch, IMG.bronchView, IMG.vats] },
        { k: "video", items: [VID.bronch, VID.bronch2, VID.medscope, VID.laryngo, VID.thoraco] },
        { k: "past", ids: ["p4"] },
      ],
    },
    {
      id: "pft", icon: "🌬️", title: t("فحص وظائف الرئة (PFT)", "Pulmonary Function Testing"),
      blocks: [
        { k: "lead", text: t(
          "الأشعة تبين 'شكل' الرئة، أما فحص وظائف الرئة فيبين 'شغلها'. أشهر جزء منه هو قياس التنفس (Spirometry): المريض ياخذ أعمق نفس ممكن وبعدين ينفخ بأقوى وأسرع ما يقدر بجهاز.",
          "Imaging shows lung 'structure'; PFT shows lung 'function'. Its best-known part is spirometry: the patient takes the deepest breath possible then blows out as hard and fast as possible into a device."
        )},
        { k: "list", check: true, title: t("استخدامات الفحص حسب المحاضرة", "Uses per the lecture"), items: [
          t("المساعدة في التشخيص (Aid diagnosis).", "Aid diagnosis."),
          t("تقييم درجة العجز الوظيفي (Assess functional impairment).", "Assess functional impairment."),
          t("متابعة العلاج أو تطور المرض (Monitor treatment or progression).", "Monitor treatment or disease progression."),
          t("تقييم الأمراض الانسدادية (مثل الربو) والتقييدية (مثل تليف الرئة).", "Assess obstructive (e.g. asthma) and restrictive (e.g. pulmonary fibrosis) diseases."),
        ]},
        { k: "chips", title: t("المصطلحات اللازمة لتفهم الفحص", "Terms you need"), items: [
          { term: "FEV1", meaning: t("كمية الهواء اللي تطلع بأول ثانية من النفخ القوي", "Air forcefully exhaled in the first second") },
          { term: "FVC", meaning: t("كل الهواء اللي تنفخه بعد أعمق شهيق", "Total air forcefully exhaled after deepest breath") },
          { term: "FEV1/FVC", meaning: t("النسبة الطبيعية > 70%. أقل من 70% = انسداد", "Normal > 70%. Below 70% = obstruction") },
          { term: "TLC", meaning: t("السعة الكلية للرئة – تزيد بالانسدادي (احتباس هواء) وتقل بالتقييدي", "Total lung capacity – ↑ in obstructive (air trapping), ↓ in restrictive") },
          { term: "RV", meaning: t("الهواء المتبقي بعد الزفير الكامل – يزيد بالانتفاخ", "Residual volume after full exhalation – ↑ in emphysema") },
          { term: "DLCO", meaning: t("قدرة انتشار الغاز عبر الغشاء – تقل بالتليف والانتفاخ", "Gas diffusion capacity – ↓ in fibrosis and emphysema") },
          { term: "PEFR", meaning: t("أقصى سرعة نفخ – جهاز صغير للمتابعة البيتية للربو", "Peak expiratory flow – small device for home asthma monitoring") },
        ]},
        { k: "anim", name: "spirometry", title: t("منحنى قياس التنفس: طبيعي / انسدادي / تقييدي", "Spirometry curve: normal / obstructive / restrictive"), caption: t("اختار نوع المرض وشوف شلون يتغير المنحنى والأرقام", "Pick a disease type and watch the curve and numbers change") },
        { k: "compare", title: t("انسدادي مقابل تقييدي", "Obstructive vs restrictive"), a: { title: t("انسدادي (Obstructive) – مثل الربو و COPD", "Obstructive – e.g. asthma & COPD"), points: [t("المشكلة: الهواء يدخل بس يطلع بصعوبة (القصبات ضيقة)", "Problem: air gets in but struggles out (narrow airways)"), t("FEV1 ينخفض كثير، FVC طبيعي أو قليل الانخفاض", "FEV1 markedly ↓, FVC normal or mildly ↓"), t("FEV1/FVC < 70%", "FEV1/FVC < 70%"), t("TLC و RV يزيدان (احتباس هواء)", "TLC and RV ↑ (air trapping)")] }, b: { title: t("تقييدي (Restrictive) – مثل التليف الرئوي", "Restrictive – e.g. pulmonary fibrosis"), points: [t("المشكلة: الرئة ما تتمدد زين (متيبسة أو مضغوطة)", "Problem: lung can't expand (stiff or compressed)"), t("FEV1 و FVC ينخفضان سوية", "FEV1 and FVC both ↓"), t("FEV1/FVC طبيعي أو مرتفع", "FEV1/FVC normal or ↑"), t("TLC ينخفض، و DLCO ينخفض بالتليف", "TLC ↓, DLCO ↓ in fibrosis")] } },
        { k: "images", items: [IMG.spiro, IMG.flow] },
        { k: "video", items: [VID.spiro, VID.flow] },
        { k: "past", ids: ["p1", "p2", "p3"] },
      ],
    },
    {
      id: "abg", icon: "🩸", title: t("قياس الأكسجين وغازات الدم (Oximetry & ABG)", "Oximetry & Arterial Blood Gases"),
      blocks: [
        { k: "lead", text: t(
          "الوظيفة الأساسية للجهاز التنفسي هي تبادل الغازات (Gas exchange): ندخل O₂ للدم ونطلع CO₂ منه. فإذا نريد نعرف الرئة شغالة لو لا، نقيس هاي الغازات بالدم مباشرة – وهذا الفحص يعطي فكرة جيدة جداً عن الوظيفة.",
          "The main function of the respiratory system is gas exchange: bring O₂ into blood and remove CO₂. To know if the lung works, we measure these gases in blood directly – this test gives a very good idea of that function."
        )},
        { k: "compare", a: { title: t("جهاز قياس الأكسجين (Oximeter)", "Pulse oximeter"), points: [t("جهاز صغير يتركب على الإصبع", "Small device clipped on a finger"), t("يقيس تشبع الأكسجين (O₂ saturation – SpO₂) فقط", "Measures O₂ saturation (SpO₂) only"), t("بدون إبرة، سريع، للمراقبة المستمرة", "Needle-free, fast, continuous monitoring"), t("الطبيعي ≥ 95%", "Normal ≥ 95%"), t("ما يقيس CO₂ – فما يكشف الفشل التنفسي من النوع الثاني", "Doesn't measure CO₂ – misses type II failure")] }, b: { title: t("جهاز غازات الدم (ABG machine)", "Arterial blood gas machine"), points: [t("يحتاج عينة دم من الشريان (غالباً الكعبري Radial)", "Needs arterial blood (usually radial)"), t("يقيس: O₂ و CO₂ و pH و البيكربونات", "Measures O₂, CO₂, pH & bicarbonate"), t("يحدد نوع الفشل التنفسي ويكشف اضطرابات الحامض-القاعدة", "Defines type of respiratory failure and acid-base disorders"), t("هو الفحص المؤكد لتشخيص الفشل التنفسي", "The confirmatory test for respiratory failure")] } },
        { k: "anim", name: "oximeter", title: t("شلون جهاز الإصبع يقيس الأكسجين؟", "How does the finger oximeter measure oxygen?"), caption: t("ضوء أحمر وتحت أحمر يعبر الإصبع؛ الهيموغلوبين المؤكسج يمتص بشكل مختلف", "Red and infrared light pass through the finger; oxygenated Hb absorbs differently") },
        { k: "anim", name: "abg-panel", title: t("لوحة غازات الدم التفاعلية", "Interactive ABG panel"), caption: t("حرّك القيم وشوف التفسير يتغير تلقائياً (طبيعي / نوع 1 / نوع 2)", "Move the values and watch the interpretation change (normal / type 1 / type 2)") },
        { k: "table", title: t("القيم الطبيعية لغازات الدم الشرياني", "Normal arterial blood gas values"), head: [t("المؤشر", "Parameter"), t("الطبيعي", "Normal"), t("معناه", "Meaning")], rows: [
          [t("PaO₂", "PaO₂"), t("10.6–13.3 kPa (80–100 mmHg)", "10.6–13.3 kPa (80–100 mmHg)"), t("كمية الأكسجين الذائب بالدم الشرياني", "Oxygen dissolved in arterial blood")],
          [t("PaCO₂", "PaCO₂"), t("4.7–6.0 kPa (35–45 mmHg)", "4.7–6.0 kPa (35–45 mmHg)"), t("يعكس التهوية: يرتفع إذا التهوية قليلة", "Reflects ventilation: rises when ventilation is low")],
          [t("pH", "pH"), t("7.35–7.45", "7.35–7.45"), t("أقل = حموضة (Acidosis)، أكثر = قلوية (Alkalosis)", "Lower = acidosis, higher = alkalosis")],
          [t("HCO₃⁻", "HCO₃⁻"), t("22–26 mmol/L", "22–26 mmol/L"), t("الجزء الكلوي/الأيضي من التوازن", "Renal/metabolic component of balance")],
          [t("SaO₂", "SaO₂"), t("> 95%", "> 95%"), t("نسبة الهيموغلوبين المحمّل بالأكسجين", "Percentage of Hb carrying oxygen")],
        ]},
        { k: "images", items: [IMG.oxi, IMG.abg] },
        { k: "video", items: [VID.oxi, VID.abg] },
        { k: "past", ids: ["p21"] },
      ],
    },
    {
      id: "pleural", icon: "💧", title: t("فحوصات أمراض الجنب", "Investigations for Pleural Diseases"),
      blocks: [
        { k: "lead", text: t(
          "الجنب (Pleura) هو الغلاف المزدوج حول الرئة. إذا صار بيه مرض (سائل، سماكة، كتلة) عدنا 3 طرق للفحص حسب المحاضرة: بزل سائل الجنب، خزعة نسيج الجنب، والمنظار الجنبي.",
          "The pleura is the double layer around the lung. When it is diseased (fluid, thickening, mass) we have 3 ways to investigate per the lecture: pleural fluid aspiration, pleural tissue biopsy, and pleuroscopy."
        )},
        { k: "list", check: true, items: [
          t("بزل سائل الجنب (Pleural fluid aspiration)", "Pleural fluid aspiration"),
          t("خزعة نسيج الجنب (Pleural tissue biopsy)", "Pleural tissue biopsy"),
          t("المنظار الجنبي (Pleuroscope)", "Pleuroscope"),
        ]},
        { k: "explain", icon: "💉", tone: "mint", title: t("1) بزل سائل الجنب (Thoracentesis)", "1) Pleural fluid aspiration (thoracentesis)"), body: t(
          "نسحب السائل المتجمع غير الطبيعي (الانصباب) بإبرة من بين الأضلاع والمريض جالس ومنحني للأمام. العينة تنفحص لـ: اللون، البروتين، الجراثيم (Bacteriology)، الخلايا (Cytology)، وفحوصات أخرى حسب الحاجة (مثل LDH، الغلوكوز، الـ pH).",
          "Abnormal fluid (effusion) is aspirated by needle between the ribs with the patient sitting and leaning forward. The sample is analysed for: colour, protein, bacteriology, cytology, and other tests accordingly (e.g. LDH, glucose, pH)."
        )},
        { k: "anim", name: "pleural-tap", title: t("بزل الجنب خطوة بخطوة", "Pleural tap step by step"), caption: t("الإبرة تدخل فوق الضلع (حتى نتجنب الأوعية والأعصاب تحت الضلع) وتسحب السائل", "Needle enters above the rib (avoiding vessels & nerve under the rib) and draws fluid") },
        { k: "table", title: t("شنو يكشف كل فحص بالسائل؟", "What each fluid test reveals"), head: [t("الفحص", "Test"), t("النتيجة", "Finding"), t("التفسير", "Interpretation")], rows: [
          [t("اللون", "Colour"), t("أصفر قشي / دموي / قيحي / حليبي", "Straw / bloody / purulent / milky"), t("قشي: عادي أو التهابي؛ دموي: سرطان، رضة، صمة؛ قيح: تقيح الجنب (Empyema)؛ حليبي: تجمع لمفاوي", "Straw: transudate or exudate; bloody: malignancy, trauma, PE; pus: empyema; milky: chylothorax")],
          [t("البروتين", "Protein"), t("> 30 g/L", "> 30 g/L"), t("نضحي (Exudate) – التهاب، سل، سرطان. أقل = رشحي (Transudate) – عجز قلب، تشمع", "Exudate – infection, TB, cancer. Lower = transudate – heart failure, cirrhosis")],
          [t("الجراثيم", "Bacteriology"), t("صبغة غرام، زرع، AFB", "Gram stain, culture, AFB"), t("تحديد البكتيريا أو السل", "Identify bacteria or TB")],
          [t("الخلايا", "Cytology"), t("خلايا خبيثة", "Malignant cells"), t("انصباب سرطاني", "Malignant effusion")],
          [t("الـ pH", "pH"), t("< 7.2", "< 7.2"), t("تقيح الجنب/انصباب معقد ← نحتاج أنبوب تصريف", "Empyema/complicated effusion → chest drain needed")],
        ]},
        { k: "explain", icon: "🪝", tone: "sand", title: t("2) خزعة الجنب (Pleural biopsy)", "2) Pleural tissue biopsy"), body: t(
          "نأخذ قطعة صغيرة من غشاء الجنب نفسه بإبرة أبرامز (Abram needle) – إبرة خاصة بيها فتحة جانبية وحافة قاطعة 'تمسك' النسيج وتقصه – أو عن طريق تنظير الصدر (Thoracoscopy). العينة تنفحص نسيجياً (Histology) للبحث عن السل (أورام حبيبية Granulomas) أو السرطان.",
          "A small piece of the pleura itself is taken with an Abram needle – a special needle with a side notch and cutting edge that 'hooks' and cuts tissue – or via thoracoscopy. The sample is examined histologically for TB (granulomas) or malignancy."
        )},
        { k: "anim", name: "abrams", title: t("شلون تشتغل إبرة أبرامز؟", "How does the Abram needle work?"), caption: t("الفتحة الجانبية تمسك الجنب ← الأنبوب الداخلي يدور ويقص القطعة", "Side notch hooks the pleura → inner tube rotates and cuts the piece") },
        { k: "game", name: "pleural-tap", title: t("لعبة: بزل الجنب الموجّه بالسونار", "Game: ultrasound-guided pleural tap"), caption: t("حرك المجس لتلقى السائل، وبعدين اختار نقطة الإدخال الآمنة قبل ما ينتهي الوقت!", "Move the probe to find fluid, then choose a safe entry point before time runs out!") },
        { k: "images", items: [IMG.tap, IMG.tapWm, IMG.abrams, IMG.usEff] },
        { k: "video", items: [VID.tap, VID.tap2, VID.abrams, VID.abrams2, VID.pleuroscope] },
        { k: "past", ids: ["p5", "p6"] },
      ],
    },
    {
      id: "summary1", icon: "📌", title: t("الخلاصة + لعبة الربط", "Summary + Matching Game"),
      blocks: [
        { k: "list", check: true, title: t("خلاصة المحاضرة", "Lecture summary"), items: [
          t("أمراض الجهاز التنفسي شائعة.", "Respiratory diseases are common."),
          t("الفحوصات تشمل: البصاق، الأشعة، وظائف الرئة، قياس الأكسجين، غازات الدم، والتنظير.", "Investigations include sputum, radiology, PFT, oximetry, blood gas analysis and endoscopy."),
          t("من المهم معرفة النتائج غير الطبيعية في الأمراض الشائعة.", "It is important to identify investigational abnormality in common diseases."),
          t("المصدر: Davidson's Principles and Practice of Medicine.", "Reference: Davidson's Principles and Practice of Medicine."),
        ]},
        { k: "table", title: t("جدول الربط الذهبي: المرض ← الفحص المناسب", "Golden matching table: disease → right test"), head: [t("الحالة", "Condition"), t("الفحص", "Test"), t("شنو نشوف", "What we see")], rows: [
          [t("السل الرئوي", "Pulmonary TB"), t("البصاق (ZN stain)", "Sputum (ZN stain)"), t("عصيات حمراء AFB", "Red AFB rods")],
          [t("سرطان القصبات", "Bronchial cancer"), t("Cytology / Bronchoscopy / CT-guided biopsy", "Cytology / bronchoscopy / CT-guided biopsy"), t("خلايا خبيثة / كتلة", "Malignant cells / mass")],
          [t("انتشار الورم", "Tumour metastasis"), t("PET", "PET"), t("بؤر مضيئة", "Bright foci")],
          [t("الصمة الرئوية", "Pulmonary embolism"), t("V/Q (قديماً) ← CTPA", "V/Q (old) → CTPA"), t("عدم تطابق / خثرة داخل الشريان", "Mismatch / clot in artery")],
          [t("الانصباب الجنبي", "Pleural effusion"), t("Ultrasound + aspiration", "Ultrasound + aspiration"), t("سائل أسود بالسونار", "Black fluid on US")],
          [t("الربو / التليف", "Asthma / fibrosis"), t("PFT", "PFT"), t("انسدادي / تقييدي", "Obstructive / restrictive")],
          [t("الفشل التنفسي", "Respiratory failure"), t("ABG", "ABG"), t("O₂ و CO₂ و pH", "O₂, CO₂, pH")],
          [t("سل أو سرطان الجنب", "Pleural TB / cancer"), t("Abram biopsy / thoracoscopy", "Abram biopsy / thoracoscopy"), t("نسيجياً", "Histology")],
        ]},
        { k: "game", name: "invest-match", title: t("لعبة: طوارئ التشخيص – اختار الفحص الصح!", "Game: Diagnostic ER – pick the right test!"), caption: t("المرضى يوصلون واحد ورا الثاني والوقت يخلص – كل جواب صح يزيد السلسلة (Combo)", "Patients arrive one after another and time is running – each correct answer builds your combo") },
      ],
    },
  ],
};
