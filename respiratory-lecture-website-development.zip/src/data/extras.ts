import { t, type L, type Img } from "../types";
import { IMG } from "./media";

/* ---------------- Differential diagnosis ---------------- */
export type Ddx = { id: string; lec: number; a: string; b: string; rows: { label: L; a: L; b: L }[]; key: L; imgs?: [Img, Img] };
const R = (la: string, le: string, aa: string, ae: string, ba: string, be: string) => ({ label: t(la, le), a: t(aa, ae), b: t(ba, be) });

export const DDX: Ddx[] = [
  { id: "d1", lec: 2, a: "Type I RF", b: "Type II RF", rows: [
    R("الغازات", "Blood gases", "PaO₂ ↓ + PaCO₂ طبيعي/↓", "PaO₂ ↓ + PaCO₂ normal/↓", "PaO₂ ↓ + PaCO₂ ↑", "PaO₂ ↓ + PaCO₂ ↑"),
    R("الآلية", "Mechanism", "V/Q mismatch", "V/Q mismatch", "Hypoventilation", "Hypoventilation"),
    R("الأعراض المميزة", "Distinctive features", "لهاث سطحي سريع، زرقة، تململ", "Rapid shallow breathing, cyanosis, restlessness", "صداع صباحي، خفقان، رجفة رفرفية، نعاس، غيبوبة", "Morning headache, palpitation, flapping tremor, drowsiness, coma"),
    R("أمثلة", "Examples", "ذات رئة، وذمة، ARDS، صمة، ربو حاد", "Pneumonia, oedema, ARDS, PE, acute asthma", "COPD، GBS، MG، حداب، صدر سائب، تخدير", "COPD, GBS, MG, kyphoscoliosis, flail chest, anaesthesia"),
    R("الأوكسجين", "Oxygen", "Liberal (>30%)", "Liberal (>30%)", "مضبوط (Controlled) + تنفس مساعد", "Controlled + assisted ventilation"),
  ], key: t("السؤال الحاسم: هل الـ CO₂ مرتفع؟ إذا نعم = النوع الثاني.", "Decisive question: is CO₂ high? If yes = type II.") },
  { id: "d2", lec: 3, a: "ARDS", b: "Cardiogenic pulmonary oedema", imgs: [IMG.ards, IMG.chf], rows: [
    R("السبب", "Cause", "تلف الغشاء التنفسي (نفاذية)", "Membrane damage (permeability)", "عجز القلب الأيسر (ضغط)", "Left heart failure (pressure)"),
    R("ضغط الإسفين (PCWP)", "Wedge pressure (PCWP)", "طبيعي", "Normal", "مرتفع", "High"),
    R("حجم القلب", "Heart size", "طبيعي", "Normal", "متضخم (Cardiomegaly)", "Enlarged (cardiomegaly)"),
    R("خطوط كيرلي B", "Kerley B lines", "غالباً غائبة", "Usually absent", "موجودة", "Present"),
    R("تحويل الدم للفص العلوي", "Upper lobe diversion", "لا", "No", "نعم", "Yes"),
    R("السويقة الوعائية", "Vascular pedicle", "طبيعية", "Normal", "متوسعة", "Widened"),
    R("السياق", "Context", "بعد 1–2 يوم من مرض/جراحة شديدة", "1–2 days after severe illness/surgery", "مريض قلب، ألم صدر، احتشاء", "Cardiac patient, chest pain, MI"),
    R("السائل", "Fluid", "غني بالبروتين", "Protein-rich", "فقير بالبروتين (رشحي)", "Protein-poor (transudate)"),
    R("الاستجابة للأوكسجين", "Response to O₂", "زرقة مقاومة للعلاج", "Cyanosis resistant to treatment", "تتحسن مع المدرات والأوكسجين", "Improves with diuretics & O₂"),
  ], key: t("ARDS = وذمة + قلب طبيعي + ضغط إسفيني طبيعي + بدون خطوط كيرلي.", "ARDS = oedema + normal heart + normal wedge + no Kerley lines.") },
  { id: "d3", lec: 2, a: "Tension pneumothorax", b: "Large pleural effusion", imgs: [IMG.ptx, IMG.effCxr], rows: [
    R("القرع", "Percussion", "فرط رنين (Hyper-resonance)", "Hyper-resonance", "أصمية صخرية (Stony dullness)", "Stony dullness"),
    R("أصوات التنفس", "Breath sounds", "غائبة", "Absent", "غائبة/ضعيفة", "Absent/reduced"),
    R("القصبة", "Trachea", "تنحرف بعيداً عن المصاب", "Deviated away", "تنحرف بعيداً (إذا كبير)", "Deviated away (if large)"),
    R("الأشعة", "X-ray", "سواد بدون علامات رئوية + حافة رئة", "Black without lung markings + lung edge", "بياض كثيف بحافة هلالية (Meniscus)", "Dense whiteness with meniscus"),
    R("البداية", "Onset", "مفاجئة جداً (COPD، رضة، جهاز تنفس)", "Very sudden (COPD, trauma, ventilator)", "تدريجية عادة (أو مفاجئة)", "Usually gradual (or sudden)"),
    R("أفضل فحص", "Best test", "سريري ← فك ضغط فوري", "Clinical → immediate decompression", "السونار + البزل", "Ultrasound + aspiration"),
  ], key: t("الفرق بالقرع: هواء = رنين، سائل = أصمية.", "Percussion decides: air = resonant, fluid = dull.") },
  { id: "d4", lec: 1, a: "Obstructive (asthma/COPD)", b: "Restrictive (fibrosis)", imgs: [IMG.emphysema, IMG.uip], rows: [
    R("FEV1", "FEV1", "↓↓", "↓↓", "↓", "↓"),
    R("FVC", "FVC", "طبيعي أو ↓ قليلاً", "Normal or mildly ↓", "↓", "↓"),
    R("FEV1/FVC", "FEV1/FVC", "< 70%", "< 70%", "طبيعي أو ↑", "Normal or ↑"),
    R("TLC / RV", "TLC / RV", "↑ (احتباس هواء)", "↑ (air trapping)", "↓", "↓"),
    R("DLCO", "DLCO", "↓ بالانتفاخ، طبيعي بالربو", "↓ in emphysema, normal in asthma", "↓ بالتليف", "↓ in fibrosis"),
    R("CT", "CT", "مناطق سوداء متهدمة (انتفاخ)", "Dark destroyed areas (emphysema)", "شبكية وقرص عسل", "Reticulation and honeycombing"),
  ], key: t("النسبة هي المفتاح: أقل من 70% = انسدادي.", "The ratio is key: below 70% = obstructive.") },
  { id: "d5", lec: 2, a: "Central cyanosis", b: "Peripheral cyanosis", imgs: [IMG.cyanosis, IMG.oxi], rows: [
    R("المكان", "Site", "الشفاه، اللسان، الأغشية المخاطية + الأطراف", "Lips, tongue, mucosa + extremities", "الأصابع والأطراف فقط (اللسان وردي)", "Fingers/extremities only (tongue pink)"),
    R("السبب", "Cause", "نقص أكسجة الدم الشرياني (فشل تنفسي)", "Arterial desaturation (respiratory failure)", "بطء الدورة، البرد، صدمة", "Slow circulation, cold, shock"),
    R("SpO₂", "SpO₂", "منخفض", "Low", "طبيعي غالباً", "Usually normal"),
    R("الأطراف", "Extremities", "دافئة", "Warm", "باردة", "Cold"),
    R("التدفئة", "Warming", "ما تتحسن", "No change", "تتحسن", "Improves"),
  ], key: t("افحص اللسان: أزرق = مركزية.", "Check the tongue: blue = central.") },
  { id: "d6", lec: 1, a: "Hemoptysis", b: "Hematemesis", imgs: [IMG.hemoptysis, IMG.afb], rows: [
    R("المصدر", "Source", "الجهاز التنفسي السفلي", "Lower respiratory tract", "الجهاز الهضمي العلوي", "Upper GI tract"),
    R("الطريقة", "How", "مع الكحة", "With cough", "مع القيء", "With vomiting"),
    R("الشكل", "Appearance", "أحمر فاتح رغوي", "Bright red, frothy", "داكن (تفل قهوة)، مع أكل", "Dark (coffee ground), with food"),
    R("الـ pH", "pH", "قلوي", "Alkaline", "حامضي", "Acidic"),
    R("الأسباب", "Causes", "سل، سرطان، توسع قصبات، صمة", "TB, cancer, bronchiectasis, PE", "قرحة، دوالي المريء", "Ulcer, oesophageal varices"),
  ], key: t("كحة = رئة، قيء = معدة.", "Cough = lung, vomit = stomach.") },
  { id: "d7", lec: 1, a: "Exudate", b: "Transudate", imgs: [IMG.tap, IMG.usEff], rows: [
    R("البروتين", "Protein", "> 30 g/L", "> 30 g/L", "< 30 g/L", "< 30 g/L"),
    R("LDH", "LDH", "مرتفع", "High", "منخفض", "Low"),
    R("الآلية", "Mechanism", "التهاب/نفاذية بالجنب", "Pleural inflammation/permeability", "ضغط أو نقص بروتين بالدم", "Pressure or low plasma protein"),
    R("الأسباب", "Causes", "التهاب، سل، سرطان، صمة", "Infection, TB, cancer, PE", "عجز قلب، تشمع، متلازمة كلوية", "Heart failure, cirrhosis, nephrotic"),
    R("الخطوة التالية", "Next step", "CT ± خزعة جنب / تنظير", "CT ± pleural biopsy / thoracoscopy", "علاج السبب الجهازي", "Treat the systemic cause"),
  ], key: t("بروتين عالي = نضحي = الجنب نفسه مريض.", "High protein = exudate = pleura itself diseased.") },
  { id: "d8", lec: 1, a: "V/Q scan", b: "CTPA", imgs: [IMG.vq, IMG.ctpa], rows: [
    R("الأداة", "Tool", "كاميرا كاما + مواد مشعة", "Gamma camera + radiotracers", "CT مع صبغة وريدية", "CT with IV contrast"),
    R("علامة الصمة", "PE sign", "Mismatch (تهوية بدون تروية)", "Mismatch (ventilation without perfusion)", "خثرة داكنة داخل الشريان", "Dark clot inside artery"),
    R("الحالة", "Status", "استُبدل بالـ CT", "Replaced by CT", "الفحص الحالي المفضل", "Current preferred test"),
    R("ميزة", "Advantage", "بدون صبغة (للحامل/الفشل الكلوي)", "No contrast (pregnancy/renal failure)", "يبين تشخيصات بديلة", "Shows alternative diagnoses"),
  ], key: t("المحاضرة: V/Q replaced by CT chest.", "Lecture: V/Q replaced by CT chest.") },
  { id: "d9", lec: 2, a: "Guillain-Barré", b: "Myasthenia gravis", imgs: [IMG.vent, IMG.mg], rows: [
    R("الحلقة المصابة", "Link affected", "الأعصاب (Nerves)", "Nerves", "الوصلة العصبية العضلية/العضلات", "Neuromuscular junction/muscles"),
    R("الآلية", "Mechanism", "التهاب مناعي بالأعصاب الطرفية بعد عدوى", "Post-infectious immune neuropathy", "أجسام مضادة لمستقبلات الأستيل كولين", "Anti-acetylcholine receptor antibodies"),
    R("النمط", "Pattern", "شلل صاعد + غياب المنعكسات", "Ascending paralysis + absent reflexes", "تعب يزيد مع التكرار، تدلي جفن، ازدواج رؤية", "Fatigable weakness, ptosis, diplopia"),
    R("الإحساس", "Sensation", "ممكن يتأثر (تنميل)", "May be affected (tingling)", "طبيعي", "Normal"),
    R("النتيجة التنفسية", "Respiratory result", "النوع الثاني (Hypodynamic)", "Type II (hypodynamic)", "النوع الثاني (Hypodynamic)", "Type II (hypodynamic)"),
  ], key: t("GBS = عصب صاعد؛ MG = عضلة تتعب.", "GBS = ascending nerve; MG = fatiguing muscle.") },
  { id: "d10", lec: 3, a: "ARDS", b: "Lobar pneumonia", imgs: [IMG.ards, IMG.pneumonia], rows: [
    R("التوزيع", "Distribution", "ثنائي منتشر", "Bilateral diffuse", "فص واحد عادة", "Usually one lobe"),
    R("الأعراض", "Features", "فشل تنفسي شديد بعد مرض/جراحة شديدة", "Severe RF after severe illness/surgery", "حمى، كحة ببلغم، ألم جنبي", "Fever, productive cough, pleuritic pain"),
    R("العلاقة", "Relation", "ذات الرئة ممكن تكون سبب لـ ARDS", "Pneumonia can cause ARDS", "سبب للنوع الأول", "Cause of type I"),
    R("الأوكسجين", "Oxygen", "زرقة مقاومة", "Resistant cyanosis", "تتحسن عادة", "Usually improves"),
  ], key: t("فص واحد = ذات رئة؛ الرئتين كلها بعد صدمة = ARDS.", "One lobe = pneumonia; both lungs after shock = ARDS.") },
];

export const CONFUSED: { a: string; b: string; tip: L }[] = [
  { a: "Hypoxia", b: "Hypercapnia", tip: t("Hypoxia = O₂ نازل (النوعين). Hypercapnia = CO₂ صاعد (النوع الثاني فقط).", "Hypoxia = low O₂ (both types). Hypercapnia = high CO₂ (type II only).") },
  { a: "Shunt", b: "Dead space", tip: t("Shunt: دم بدون هواء (ذات رئة). Dead space: هواء بدون دم (صمة).", "Shunt: blood without air (pneumonia). Dead space: air without blood (PE).") },
  { a: "IPPV", b: "PEEP", tip: t("IPPV: ضغط إيجابي متقطع بالشهيق. PEEP: ضغط يبقى حتى نهاية الزفير.", "IPPV: intermittent inspiratory positive pressure. PEEP: pressure maintained to end-expiration.") },
  { a: "Thoracoscopy", b: "Mediastinoscopy", tip: t("Thoracoscopy: تجويف الجنب. Mediastinoscopy: المنصف (العقد اللمفاوية).", "Thoracoscopy: pleural cavity. Mediastinoscopy: mediastinum (lymph nodes).") },
  { a: "Bronchoscopy", b: "Laryngoscopy", tip: t("Laryngoscopy تقف عند الحنجرة؛ Bronchoscopy تكمل للقصبات.", "Laryngoscopy stops at the larynx; bronchoscopy continues to the bronchi.") },
  { a: "Oximetry", b: "ABG", tip: t("Oximetry: تشبع فقط بدون إبرة. ABG: O₂ و CO₂ و pH و HCO₃ من شريان.", "Oximetry: saturation only, no needle. ABG: O₂, CO₂, pH, HCO₃ from an artery.") },
  { a: "PET", b: "CT", tip: t("CT يبين الشكل (التشريح). PET يبين النشاط (الأيض/الغلوكوز).", "CT shows anatomy. PET shows activity (glucose metabolism).") },
  { a: "Liberal O₂", b: "Controlled O₂", tip: t("Liberal: تركيز عالي للنوع الأول و ARDS. Controlled: قليل مضبوط للنوع الثاني/COPD.", "Liberal: high for type I & ARDS. Controlled: low fixed for type II/COPD.") },
  { a: "Cyanosis in type I", b: "Cyanosis in ARDS", tip: t("النوع الأول: تتصحح بأوكسجين >30%. ARDS: مقاومة للعلاج.", "Type I: corrected by O₂ >30%. ARDS: resistant to treatment.") },
  { a: "Acute severe asthma", b: "Life-threatening asthma", tip: t("شديد: عدم إكمال الجملة، نبض ≥110، تنفس ≥25، PEF 33–50%. مهدد: زرقة، صدر صامت، بطء قلب، هبوط ضغط، إنهاك.", "Severe: can't complete sentences, HR ≥110, RR ≥25, PEF 33–50%. Life-threatening: cyanosis, silent chest, bradycardia, hypotension, exhaustion.") },
  { a: "Acute ARDS X-ray", b: "Chronic ARDS X-ray", tip: t("حاد: وذمة سنخية ← بينية. مزمن: تليف + انتفاخ بؤري.", "Acute: alveolar → interstitial oedema. Chronic: fibrosis + focal emphysema.") },
  { a: "Abram needle", b: "CT-guided biopsy", tip: t("Abram: خزعة الجنب (عمياء). CT-guided: كتلة رئة/جنب بتوجيه المفراس.", "Abram: pleural biopsy (blind). CT-guided: lung/pleural mass under CT.") },
];

/* ---------------- Clinical cases ---------------- */
export type Case = {
  id: string; lec: number; title: L; patient: L; vitals: L; img?: Img;
  findings: { text: L; correct: boolean }[];
  options: L[]; answer: number; explain: L; others: L[];
};

export const CASES: Case[] = [
  { id: "c1", lec: 3, title: t("ضيق نفس بعد التهاب البنكرياس", "Breathlessness after pancreatitis"),
    patient: t("رجل 45 سنة أُدخل قبل يومين بالتهاب بنكرياس حاد شديد. اليوم صار عنده ضيق نفس متزايد وزرقة ما تتحسن رغم الأوكسجين 60%.", "45-year-old man admitted 2 days ago with severe acute pancreatitis. Today he has progressive SOB and cyanosis not improving on 60% oxygen."),
    vitals: t("RR 36، SpO₂ 82% على 60% O₂، PaO₂ 75 mmHg، PaCO₂ 30 mmHg، خرخرة ناعمة بالرئتين، JVP طبيعي", "RR 36, SpO₂ 82% on 60% O₂, PaO₂ 75 mmHg, PaCO₂ 30 mmHg, bilateral fine crepitations, normal JVP"),
    img: IMG.ards,
    findings: [
      { text: t("ظلال بيضاء ثنائية منتشرة", "Bilateral diffuse white shadowing"), correct: true },
      { text: t("حجم قلب طبيعي", "Normal heart size"), correct: true },
      { text: t("تضخم القلب الواضح", "Marked cardiomegaly"), correct: false },
      { text: t("سواد بدون علامات رئوية بجهة واحدة", "Unilateral black area without lung markings"), correct: false },
      { text: t("بياض بفص واحد فقط", "Whiteness of a single lobe only"), correct: false },
    ],
    options: s2(["ARDS", "Cardiogenic pulmonary oedema", "Lobar pneumonia", "Tension pneumothorax"]), answer: 0,
    explain: t("مرض شديد (التهاب بنكرياس – السبب 4) + فشل تنفسي شديد خلال يومين + زرقة مقاومة + نقص O₂ ونقص CO₂ + ظلال ثنائية + قلب طبيعي = ARDS. P/F = 75/0.6 = 125 (< 200 = شديد).", "Severe illness (pancreatitis – cause 4) + severe RF within 2 days + resistant cyanosis + hypoxia & hypocapnia + bilateral shadowing + normal heart = ARDS. P/F = 75/0.6 = 125 (< 200 = severe)."),
    others: [t("الوذمة القلبية: يكون القلب متضخم و JVP مرتفع وخطوط كيرلي – مو موجودة.", "Cardiogenic oedema: would show cardiomegaly, raised JVP, Kerley lines – absent."), t("ذات الرئة الفصية: فص واحد مع حمى وبلغم، مو انتشار ثنائي.", "Lobar pneumonia: a single lobe with fever and sputum, not bilateral spread."), t("الاسترواح الضاغط: فرط رنين وسواد بجهة واحدة.", "Tension pneumothorax: unilateral hyper-resonance and blackness.")] },
  { id: "c2", lec: 2, title: t("مريض COPD صار يختنق فجأة", "COPD patient suddenly gasping"),
    patient: t("رجل 72 سنة مصاب بـ COPD، أثناء نوبة كحة حس بألم حاد بالجهة اليمنى وضيق نفس مفاجئ.", "72-year-old with COPD developed sharp right chest pain and sudden SOB during a coughing fit."),
    vitals: t("RR 34، نبض 128، ضغط 85/50، فرط رنين يمين، غياب أصوات التنفس يمين، القصبة منحرفة لليسار", "RR 34, HR 128, BP 85/50, right hyper-resonance, absent right breath sounds, trachea shifted left"),
    img: IMG.tension,
    findings: [
      { text: t("الهواء يدفع المنصف للجهة الأخرى", "Air pushes the mediastinum to the opposite side"), correct: true },
      { text: t("انخماص الرئة بالجهة المصابة", "Lung collapse on the affected side"), correct: true },
      { text: t("سائل بحافة هلالية", "Fluid with a meniscus"), correct: false },
      { text: t("ظلال ثنائية منتشرة", "Bilateral diffuse shadowing"), correct: false },
    ],
    options: s2(["Tension pneumothorax", "Large pleural effusion", "Acute asthma", "Pulmonary embolism"]), answer: 0,
    explain: t("فرط رنين + غياب أصوات التنفس + انحراف القصبة بعيداً + هبوط ضغط = استرواح ضاغط (Sudden pneumothorax – سبب تقييدي للنوع الأول). علاج إسعافي: فك الضغط بإبرة ثم أنبوب صدر.", "Hyper-resonance + absent breath sounds + trachea deviated away + hypotension = tension pneumothorax (sudden pneumothorax – restrictive type I cause). Emergency needle decompression then chest drain."),
    others: [t("الانصباب: أصمية مو فرط رنين.", "Effusion: dullness, not hyper-resonance."), t("الربو: صفير ثنائي بدون انحراف القصبة.", "Asthma: bilateral wheeze without tracheal shift."), t("الصمة: الفحص الصدري غالباً طبيعي.", "PE: chest exam usually normal.")] },
  { id: "c3", lec: 1, title: t("حمى مسائية وانصباب", "Evening fever and effusion"),
    patient: t("شاب 30 سنة، كحة وألم صدر أيمن وحمى مسائية وتعرق ليلي لمدة 3 أسابيع، نقص وزن.", "30-year-old with cough, right chest pain, evening fever and night sweats for 3 weeks, weight loss."),
    vitals: t("أصمية صخرية أسفل اليمين، غياب أصوات التنفس، WBC طبيعي", "Stony dullness right base, absent breath sounds, normal WBC"),
    img: IMG.effCxr,
    findings: [
      { text: t("بياض كثيف يغطي أسفل نصف الصدر", "Dense whiteness covering the lower hemithorax"), correct: true },
      { text: t("طمس الزاوية الضلعية الحجابية", "Obliterated costophrenic angle"), correct: true },
      { text: t("سواد بدون علامات رئوية", "Black area without lung markings"), correct: false },
      { text: t("تضخم القلب مع خطوط كيرلي", "Cardiomegaly with Kerley lines"), correct: false },
    ],
    options: s2(["Tuberculous pleural effusion → aspiration + Abram biopsy", "Pneumothorax → chest drain", "ARDS → ICU", "Cardiac oedema → diuretics"]), answer: 0,
    explain: t("أعراض السل (حمى مسائية، تعرق، نقص وزن) + انصباب. نؤكد بالسونار، ثم بزل (اللون، البروتين – نضحي، الجراثيم، الخلايا)، وإذا ما شخّص: خزعة جنب بإبرة أبرامز أو تنظير للبحث عن الأورام الحبيبية.", "TB features (evening fever, sweats, weight loss) + effusion. Confirm by ultrasound, aspirate (colour, protein – exudate, bacteriology, cytology); if non-diagnostic: Abram needle or thoracoscopic pleural biopsy for granulomas."),
    others: [t("الاسترواح: سواد مو بياض.", "Pneumothorax: blackness, not whiteness."), t("ARDS: ثنائي ومنتشر بعد مرض شديد.", "ARDS: bilateral diffuse after severe illness."), t("القلبي: ثنائي غالباً مع تضخم قلب، رشحي.", "Cardiac: usually bilateral with cardiomegaly, transudate.")] },
  { id: "c4", lec: 2, title: t("نعاس بعد الأوكسجين", "Drowsy after oxygen"),
    patient: t("رجل 68 سنة مدخن مصاب بـ COPD، أُدخل بضيق نفس وأُعطي أوكسجين عالي بقناع غير مضبوط. ثاني يوم صار نعسان ومشوش مع صداع.", "68-year-old smoker with COPD admitted with SOB and given high uncontrolled oxygen. Next day drowsy, confused with headache."),
    vitals: t("PaO₂ 75، PaCO₂ 78 mmHg، pH 7.22، رجفة رفرفية، أطراف دافئة، نبض قوي", "PaO₂ 75, PaCO₂ 78 mmHg, pH 7.22, flapping tremor, warm hands, bounding pulse"),
    img: IMG.venturi,
    findings: [
      { text: t("ارتفاع CO₂ (Hypercapnia)", "Hypercapnia"), correct: true },
      { text: t("حموضة تنفسية (pH منخفض)", "Respiratory acidosis (low pH)"), correct: true },
      { text: t("رجفة رفرفية وصداع – علامات CO₂", "Flapping tremor and headache – CO₂ signs"), correct: true },
      { text: t("نقص CO₂", "Hypocapnia"), correct: false },
    ],
    options: s2(["Type II RF worsened by uncontrolled O₂ → assisted ventilation + controlled O₂", "Type I RF → increase O₂ to 100%", "ARDS → PEEP only", "Sedate the patient"]), answer: 0,
    explain: t("COPD = سبب النوع الثاني. الأوكسجين العالي غير المضبوط رفع CO₂ (تخدير CO₂). العلاج: أوكسجين مضبوط (فنتوري 24–28%) + تنظيف المجاري + تنفس مساعد (NIV أو تنبيب). لا توقف الأوكسجين فجأة، ولا مهدئات.", "COPD = type II cause. Uncontrolled high O₂ raised CO₂ (CO₂ narcosis). Treat: controlled O₂ (Venturi 24–28%) + airway clearance + assisted ventilation (NIV or intubation). Don't stop O₂ abruptly; no sedatives."),
    others: [t("زيادة الأوكسجين لـ 100% راح تزيد CO₂ أكثر.", "Raising O₂ to 100% will raise CO₂ further."), t("ما اكو علامات ARDS (لا مرض شديد حاد ولا ظلال ثنائية).", "No ARDS features (no acute severe illness or bilateral shadows)."), t("المهدئات تثبط مركز التنفس – ممنوعة.", "Sedatives depress the respiratory centre – contraindicated.")] },
  { id: "c5", lec: 2, title: t("ضيق نفس بعد رحلة طويلة", "Breathless after a long journey"),
    patient: t("امرأة 46 سنة رجعت من سفرة طويلة بالطيارة. ساقها اليسرى متورمة، وفجأة صار عندها ضيق نفس وألم صدر جنبي.", "46-year-old woman back from a long flight. Swollen left calf, then sudden SOB and pleuritic chest pain."),
    vitals: t("نبض 118، RR 30، SpO₂ 88%، PaCO₂ 30، الفحص الصدري طبيعي تقريباً", "HR 118, RR 30, SpO₂ 88%, PaCO₂ 30, chest exam nearly normal"),
    img: IMG.peEcg,
    findings: [
      { text: t("تسرع قلب جيبي", "Sinus tachycardia"), correct: true },
      { text: t("علامات إجهاد القلب الأيمن", "Right heart strain signs"), correct: true },
      { text: t("ارتفاع ST بكل الاتجاهات", "Diffuse ST elevation"), correct: false },
      { text: t("بطء قلب شديد", "Severe bradycardia"), correct: false },
    ],
    options: s2(["Pulmonary thromboembolism → CTPA", "Pneumonia → sputum culture", "Type II RF → controlled O₂", "Pleural effusion → aspiration"]), answer: 0,
    explain: t("DVT (ساق متورمة بعد سفر) + ضيق نفس مفاجئ + نقص O₂ مع CO₂ منخفض + صدر طبيعي = صمة رئوية (سبب وعائي للنوع الأول – حيز ميت). ECG: تسرع ± S1Q3T3. التشخيص: CTPA (اللي استبدل V/Q).", "DVT (swollen leg after travel) + sudden SOB + hypoxia with low CO₂ + normal chest = PE (vascular type I cause – dead space). ECG: tachycardia ± S1Q3T3. Diagnose with CTPA (which replaced V/Q)."),
    others: [t("ذات الرئة: حمى وبلغم وعلامات صدرية.", "Pneumonia: fever, sputum, chest signs."), t("النوع الثاني: CO₂ مرتفع – هنا منخفض.", "Type II: high CO₂ – here low."), t("الانصباب: أصمية بالفحص.", "Effusion: dullness on exam.")] },
  { id: "c6", lec: 2, title: t("ضعف صاعد بعد إسهال", "Ascending weakness after diarrhoea"),
    patient: t("شاب 25 سنة، بعد أسبوعين من التهاب معوي، بدأ ضعف بالرجلين صعد للذراعين خلال أيام، والحين صوته ضعيف وتنفسه سطحي.", "25-year-old, two weeks after gastroenteritis, weakness started in legs ascending to arms over days; now weak voice and shallow breathing."),
    vitals: t("المنعكسات غائبة، PaO₂ 58، PaCO₂ 58 mmHg، الرئتين صافيتين بالأشعة", "Absent reflexes, PaO₂ 58, PaCO₂ 58 mmHg, clear lungs on CXR"),
    img: IMG.vent,
    findings: [
      { text: t("نقص O₂ + ارتفاع CO₂", "Hypoxia + hypercapnia"), correct: true },
      { text: t("الرئة نفسها سليمة", "The lungs themselves are healthy"), correct: true },
      { text: t("V/Q mismatch بسبب ذات رئة", "V/Q mismatch from pneumonia"), correct: false },
    ],
    options: s2(["Guillain-Barré → type II RF (nerves) → assisted ventilation", "Myasthenia gravis crisis", "ARDS", "Acute asthma"]), answer: 0,
    explain: t("شلل صاعد بعد عدوى + غياب المنعكسات = غيلان-باريه. الأعصاب الوربية والحجابية تتأثر ← نقص تهوية ← النوع الثاني (Hypodynamic – Nerves). العلاج: تنفس مساعد + علاج السبب.", "Post-infectious ascending paralysis + areflexia = Guillain-Barré. Intercostal & phrenic nerves affected → hypoventilation → type II (hypodynamic – nerves). Treat: assisted ventilation + treat cause."),
    others: [t("الوهن العضلي: ضعف يتعب بالتكرار مع تدلي جفن، والمنعكسات طبيعية.", "MG: fatigable weakness with ptosis; reflexes normal."), t("ARDS: ظلال ثنائية و CO₂ منخفض.", "ARDS: bilateral shadows, low CO₂."), t("الربو: صفير ونوع أول بالبداية.", "Asthma: wheeze, initially type I.")] },
];
function s2(xs: string[]) { return xs.map((x) => t(x, x)); }

/* ---------------- Mind map ---------------- */
export type MNode = { label: L; children?: MNode[] };
const n = (ar: string, en: string, children?: MNode[]): MNode => ({ label: t(ar, en), children });

export const MIND: MNode[] = [
  n("الفحوصات", "Investigations", [
    n("البصاق", "Sputum", [n("السل – ZN/AFB", "TB – ZN/AFB"), n("Cytology – سرطان", "Cytology – cancer"), n("نفث الدم", "Hemoptysis")]),
    n("الأشعة", "Radiology", [n("CXR: رئة، قلب، منصف، أوعية، قفص", "CXR: lungs, heart, mediastinum, vessels, cage"), n("CT: تفاصيل + خزعة موجهة", "CT: detail + guided biopsy"), n("US: سائل الجنب", "US: pleural fluid"), n("V/Q: كاميرا كاما، صمة ← CT", "V/Q: gamma camera, PE → CT"), n("PET: غلوكوز، انتشار", "PET: glucose, metastasis")]),
    n("PFT", "PFT", [n("تشخيص، عجز، متابعة", "Diagnose, impairment, monitor"), n("انسدادي: ربو", "Obstructive: asthma"), n("تقييدي: تليف", "Restrictive: fibrosis")]),
    n("Oximetry / ABG", "Oximetry / ABG", [n("SpO₂", "SpO₂"), n("O₂, CO₂, pH, HCO₃", "O₂, CO₂, pH, HCO₃")]),
    n("التنظير (5)", "Endoscopy (5)", [n("Bronchoscopy", "Bronchoscopy"), n("Mediastinoscopy", "Mediastinoscopy"), n("Laryngoscopy", "Laryngoscopy"), n("Thoracoscopy", "Thoracoscopy"), n("Pleuroscope", "Pleuroscope")]),
    n("الجنب", "Pleura", [n("بزل: لون، بروتين، جراثيم، خلايا", "Aspiration: colour, protein, bacteria, cells"), n("خزعة: Abram / Thoracoscopy", "Biopsy: Abram / thoracoscopy"), n("Pleuroscope", "Pleuroscope")]),
  ]),
  n("الفشل التنفسي", "Respiratory Failure", [
    n("التعريف", "Definition", [n("غازات غير طبيعية", "Abnormal gases"), n("سطح البحر + راحة", "Sea level + rest"), n("تهوية، تروية، تبادل", "Ventilation, perfusion, exchange")]),
    n("النوع الأول", "Type I", [n("O₂↓ CO₂ طبيعي/↓", "O₂↓ CO₂ N/↓"), n("V/Q mismatch", "V/Q mismatch"), n("تقييدي: ارتشاح، ذات رئة، وذمة، ARDS، استرواح، انصباب", "Restrictive: infiltrative, pneumonia, oedema, ARDS, PTX, effusion"), n("انسدادي: ربو، قصيبات", "Obstructive: asthma, bronchiolitis"), n("وعائي: صمة، التهاب أوعية", "Vascular: PTE, vasculitis")]),
    n("أعراض/علاج 1", "Type I features/Rx", [n("زرقة تتصحح > 30%", "Cyanosis corrected > 30%"), n("تأكيد ABG", "ABG confirms"), n("راحة + O₂ Liberal", "Rest + liberal O₂")]),
    n("النوع الثاني", "Type II", [n("O₂↓ CO₂↑", "O₂↓ CO₂↑"), n("Hypoventilation", "Hypoventilation"), n("COPD", "COPD"), n("مركز: رضة، ورم، جلطة، تخدير", "Centre: trauma, tumour, stroke, anaesthesia"), n("أعصاب: GBS، شلل أطفال", "Nerves: GBS, polio"), n("عضلات: Myopathy، MG", "Muscles: myopathy, MG"), n("قفص: حداب، صدر سائب", "Cage: kyphoscoliosis, flail"), n("نهاية النوع الأول", "End-stage type I")]),
    n("أعراض/علاج 2", "Type II features/Rx", [n("صداع، خفقان، رجفة، نعاس، غيبوبة", "Headache, palpitation, tremor, drowsiness, coma"), n("O₂ + تنظيف مجاري + تنفس مساعد", "O₂ + airway clearance + assisted ventilation")]),
  ]),
  n("ARDS", "ARDS", [
    n("التعريف", "Definition", [n("Shock lung", "Shock lung"), n("وذمة غير قلبية", "Non-cardiac oedema"), n("ضغط إسفيني طبيعي", "Normal wedge pressure")]),
    n("الأسباب (13)", "Causes (13)", [n("التهاب، إصابات، صدمة", "Infection, injury, shock"), n("بنكرياس، حروق، انصمام", "Pancreatitis, burns, emboli"), n("حامض، غرق، شنق", "Acid, drowning, hanging"), n("كيمياويات، مجازة، نقل دم", "Chemicals, bypass, transfusion"), n("أوكسجين > 24 ساعة", "O₂ > 24 h")]),
    n("الآلية", "Pathophysiology", [n("تلف Endothelium + Epithelium", "Endothelial + epithelial damage"), n("نفاذية ↑ ← سائل غني بالبروتين", "↑ permeability → protein-rich fluid"), n("خلل السيرفاكتانت ← تيبس", "Surfactant dysfunction → stiffness")]),
    n("الأشعة", "Radiology", [n("حاد: سويقة طبيعية، بدون قلب كبير، بدون خطوط", "Acute: normal pedicle, no cardiomegaly, no septal lines"), n("مزمن: تليف + انتفاخ بؤري", "Chronic: fibrosis + focal emphysema"), n("P/F < 200", "P/F < 200")]),
    n("المضاعفات", "Complications", [n("عدوى إضافية", "Super-infection"), n("فشل أعضاء متعدد", "Multi-organ failure"), n("تليف", "Fibrosis"), n("وفيات 50/70/90%", "Mortality 50/70/90%")]),
    n("العلاج (ICU)", "Treatment (ICU)", [n("السبب", "Cause"), n("O₂ Liberal لا نقي > 24h", "Liberal O₂, not pure > 24h"), n("IPPV + PEEP", "IPPV + PEEP"), n("عدوى، تغذية، نظافة، قرح، أملاح، ستيرويد", "Infection, feeding, hygiene, sores, electrolytes, steroids")]),
  ]),
];

/* ---------------- Radiology lab ---------------- */
export type RadItem = {
  id: string; img: Img; title: L; dx: L; explain: L;
  marks: { x: number; y: number; label: L }[];
  quiz: { x: number; y: number; r: number; label: L }[];
};
export const RAD: RadItem[] = [
  { id: "r1", img: IMG.cxr, title: t("صورة صدر طبيعية – تعلم التشريح", "Normal chest X-ray – learn the anatomy"), dx: t("طبيعية", "Normal"),
    explain: t("الرئتين سوداوين بعلامات وعائية رفيعة، القلب أقل من نصف عرض الصدر، الزوايا الضلعية الحجابية حادة وواضحة، القصبة بالوسط.", "Both lungs black with fine vascular markings, heart < half chest width, sharp costophrenic angles, central trachea."),
    marks: [
      { x: 50, y: 14, label: t("القصبة الهوائية", "Trachea") }, { x: 27, y: 42, label: t("الرئة اليمنى", "Right lung") }, { x: 74, y: 42, label: t("الرئة اليسرى", "Left lung") },
      { x: 60, y: 66, label: t("القلب", "Heart") }, { x: 25, y: 80, label: t("الحجاب الأيمن", "Right hemidiaphragm") }, { x: 9, y: 79, label: t("الزاوية الضلعية الحجابية", "Costophrenic angle") },
      { x: 38, y: 45, label: t("السرّة (Hilum)", "Hilum") }, { x: 25, y: 9, label: t("الترقوة", "Clavicle") },
    ],
    quiz: [
      { x: 50, y: 14, r: 8, label: t("القصبة الهوائية", "Trachea") }, { x: 60, y: 66, r: 12, label: t("القلب", "Heart") },
      { x: 74, y: 42, r: 13, label: t("الرئة اليسرى", "Left lung") }, { x: 9, y: 79, r: 7, label: t("الزاوية الضلعية الحجابية اليمنى", "Right costophrenic angle") },
      { x: 25, y: 9, r: 8, label: t("الترقوة اليمنى", "Right clavicle") },
    ] },
  { id: "r2", img: IMG.effCxr, title: t("بياض أسفل الصدر – شنو هو؟", "Lower chest whiteness – what is it?"), dx: t("انصباب جنبي كبير", "Large pleural effusion"),
    explain: t("بياض كثيف متجانس بأسفل نصف الصدر يطمس الزاوية الضلعية الحجابية وحدود الحجاب والقلب، بحافة علوية مقعرة (Meniscus). الخطوة التالية: سونار + بزل.", "Dense homogeneous whiteness of the lower hemithorax obliterating the costophrenic angle, diaphragm and heart border, with a concave upper edge (meniscus). Next: ultrasound + aspiration."),
    marks: [
      { x: 72, y: 62, label: t("السائل (بياض كثيف)", "Fluid (dense whiteness)") }, { x: 82, y: 33, label: t("حافة السائل الهلالية", "Meniscus") }, { x: 22, y: 42, label: t("الرئة السليمة (سوداء)", "Normal aerated lung") },
    ],
    quiz: [
      { x: 72, y: 62, r: 18, label: t("الانصباب", "The effusion") }, { x: 22, y: 42, r: 12, label: t("الرئة السليمة", "The normal lung") },
    ] },
  { id: "r3", img: IMG.ards, title: t("مريض بالعناية بعد صدمة إنتانية", "ICU patient after septic shock"), dx: t("ARDS", "ARDS"),
    explain: t("ظلال بيضاء ثنائية منتشرة (Bilateral infiltrates) بدون تضخم القلب، مع مريض بعد صدمة = ARDS. قارنها بصورة الوذمة القلبية حتى تشوف الفرق بحجم القلب.", "Bilateral diffuse infiltrates without cardiomegaly in a post-shock patient = ARDS. Compare with cardiogenic oedema to see the heart-size difference."),
    marks: [
      { x: 30, y: 50, label: t("ظلال بالرئة اليمنى", "Right lung shadowing") }, { x: 70, y: 50, label: t("ظلال بالرئة اليسرى", "Left lung shadowing") }, { x: 52, y: 68, label: t("قلب حجمه طبيعي", "Normal-sized heart") },
    ],
    quiz: [
      { x: 30, y: 50, r: 16, label: t("الظلال اليمنى", "Right-sided shadowing") }, { x: 70, y: 50, r: 16, label: t("الظلال اليسرى", "Left-sided shadowing") },
    ] },
];

export const COMPARE_PAIRS: { a: Img; b: Img; title: L; note: L }[] = [
  { a: IMG.ards, b: IMG.chf, title: t("ARDS مقابل الوذمة القلبية", "ARDS vs cardiogenic oedema"), note: t("ركّز على حجم القلب وخطوط كيرلي: ARDS قلب طبيعي بدون خطوط.", "Focus on heart size and Kerley lines: ARDS has a normal heart and no lines.") },
  { a: IMG.cxr, b: IMG.ptx, title: t("طبيعي مقابل استرواح الصدر", "Normal vs pneumothorax"), note: t("بالاسترواح تختفي العلامات الرئوية بالمنطقة السوداء.", "In pneumothorax lung markings vanish in the black area.") },
  { a: IMG.cxr, b: IMG.effCxr, title: t("طبيعي مقابل انصباب جنبي", "Normal vs pleural effusion"), note: t("الزاوية الضلعية الحجابية تنطمس بالانصباب.", "The costophrenic angle is obliterated by effusion.") },
  { a: IMG.emphysema, b: IMG.uip, title: t("انسدادي (انتفاخ) مقابل تقييدي (تليف)", "Obstructive (emphysema) vs restrictive (fibrosis)"), note: t("الانتفاخ: سواد متهدم. التليف: شبكية وقرص عسل.", "Emphysema: dark destruction. Fibrosis: reticulation & honeycombing.") },
];
