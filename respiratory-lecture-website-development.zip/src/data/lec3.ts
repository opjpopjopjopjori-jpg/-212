import { t, type Lecture } from "../types";
import { IMG, VID } from "./media";

export const lec3: Lecture = {
  id: "lec3", num: 3, emoji: "🌫️", color: "#d4a373", lecturer: "Prof. Dr. Muhammed Waheeb Al-Obaidy",
  title: t("متلازمة الضائقة التنفسية الحادة (ARDS)", "Acute Respiratory Distress Syndrome (ARDS)"),
  summary: t(
    "ARDS أو 'رئة الصدمة' – وذمة رئوية بدون مشكلة بالقلب. نتعلم الفرق بينها وبين الوذمة القلبية، أسبابها الـ13، آليتها، أشعتها، أعراضها، مضاعفاتها وعلاجها بالعناية المركزة.",
    "ARDS or 'shock lung' – pulmonary oedema without a heart problem. We learn how it differs from cardiac oedema, its 13 causes, mechanism, radiology, features, complications and ICU treatment."
  ),
  objectives: [
    t("تعريف ARDS والتفريق بينها وبين الوذمة الرئوية القلبية.", "Define ARDS and differentiate it from cardiogenic pulmonary oedema."),
    t("معرفة أسباب ARDS وآلية حدوثها ومراحلها الشعاعية.", "Know ARDS causes, pathophysiology and radiological phases."),
    t("معرفة الأعراض والمضاعفات وأسس العلاج.", "Know features, complications and principles of treatment."),
  ],
  sections: [
    {
      id: "def3", icon: "📖", title: t("التعريف: وذمة بدون قلب", "Definition: Oedema Without the Heart"),
      blocks: [
        { k: "callout", tone: "def", title: t("التعريف", "Definition"), body: t(
          "تسمى أيضاً 'رئة الصدمة' (Shock Lung). هي متلازمة فيها وذمة رئوية (Pulmonary oedema) بدون ارتفاع ضغط الأوردة الشعرية الرئوية – أي وذمة رئوية غير قلبية (Non-cardiac pulmonary oedema).",
          "Also called 'Shock Lung'. A syndrome with pulmonary oedema without increase in pulmonary capillary venous pressure – i.e. non-cardiac pulmonary oedema."
        )},
        { k: "explain", icon: "💧", tone: "sky", title: t("أول شي: شنو يعني وذمة رئوية؟", "First: what is pulmonary oedema?"), body: t(
          "الأسناخ لازم تكون مليانة هواء. الوذمة الرئوية = تسرب سائل من الأوعية الدموية الشعرية إلى نسيج الرئة والأسناخ. فالسنخ اللي جان يتبادل غازات صار 'غرقان' بالماي، والمريض يحس كأنه يغرق من الداخل.",
          "Alveoli should be full of air. Pulmonary oedema = fluid leaking from capillaries into lung tissue and alveoli. The alveolus that exchanged gases is now 'drowning', and the patient feels like drowning from inside."
        )},
        { k: "compare", title: t("طريقين للوذمة – نفس النتيجة، سبب مختلف", "Two routes to oedema – same result, different cause"), a: { title: t("الوذمة القلبية (عجز القلب الأيسر)", "Cardiac oedema (left heart failure)"), points: [t("ضغط الأذين الأيسر يرتفع", "Left atrial pressure rises"), t("← ضغط الأوردة الرئوية يرتفع", "→ pulmonary venous pressure rises"), t("← السائل 'ينعصر' للرئة بسبب الضغط العالي", "→ fluid is 'squeezed' into lung by high pressure"), t("الغشاء سليم – المشكلة ضغط", "Membrane intact – the problem is pressure")] }, b: { title: t("ARDS (غير قلبية)", "ARDS (non-cardiac)"), points: [t("ضغط الأوردة الرئوية طبيعي", "Pulmonary venous pressure normal"), t("السائل يرشح من الشعيرات مباشرة", "Fluid oozes through capillaries directly"), t("لأن الغشاء التنفسي نفسه متضرر ('مثقوب')", "Because the respiratory membrane itself is damaged ('leaky')"), t("المشكلة نفاذية – مو ضغط", "The problem is permeability – not pressure")] } },
        { k: "anim", name: "edema-compare", title: t("محاكاة: ضغط عالي مقابل غشاء مثقوب", "Simulation: high pressure vs leaky membrane"), caption: t("بدّل بين الحالتين وشوف من وين يطلع السائل وشنو نوعه", "Switch between both and see where fluid comes from and what kind") },
        { k: "callout", tone: "memory", title: t("تشبيه يثبت المعلومة", "An analogy to remember"), body: t("الوذمة القلبية = صنبور مفتوح بقوة والأنبوب سليم (ضغط). ARDS = الصنبور عادي بس الأنبوب مثقوب (نفاذية).", "Cardiac oedema = tap opened hard with intact hose (pressure). ARDS = normal tap but a hose full of holes (permeability).") },
        { k: "images", items: [IMG.ards, IMG.chf, IMG.ardsAlv] },
        { k: "video", items: [VID.edemaShort, VID.edema, VID.ards] },
      ],
    },
    {
      id: "causes3", icon: "⚠️", title: t("الأسباب الـ13", "The 13 Causes"),
      blocks: [
        { k: "lead", text: t("اكو عمليات كثيرة تسبب ARDS. المفتاح لفهمها: أي شي يسبب التهاب شديد بالجسم أو أذى مباشر للرئة ممكن يتلف الغشاء التنفسي. قسمها لمباشر (يضرب الرئة نفسها) وغير مباشر (يجي من الدم).", "Many processes precipitate ARDS. Key: anything causing severe body inflammation or direct lung injury can damage the respiratory membrane. Split into direct (hitting the lung) and indirect (via blood).") },
        { k: "list", check: true, title: t("الأسباب كما بالمحاضرة", "Causes as in the lecture"), ordered: true, items: [
          t("التهاب رئوي (Pulmonary infection): فيروسي (مثل H1N1 influenza، SARS)، مايكوبلازما، بكتيري، والسل.", "Pulmonary infection: viral (H1N1 influenza, SARS…), mycoplasmal, bacterial, tuberculosis."),
          t("الإصابات (Injuries): أذى الرئة المباشر (رصاصة، انفجار) أو غير المباشر (كسور، فقر دم انحلالي)، الكسور، إصابة الرأس، والعمليات الجراحية الطويلة.", "Injuries: direct lung injury (bullet, blast) or indirect (fractures, haemolytic anaemia), fractures, head injury, prolonged surgery."),
          t("تسمم الدم والصدمة الإنتانية (Septicaemia & septic shock): كل حالات الصدمة تسبب ARDS – لهذا سميت 'رئة الصدمة'.", "Septicaemia & septic shock: all shock states can cause ARDS – hence 'shock lung'."),
          t("التهاب البنكرياس الحاد (Acute pancreatitis): إنزيمات البنكرياس تطلع للدم وتهاجم الغشاء التنفسي.", "Acute pancreatitis: pancreatic enzymes enter blood and attack the membrane."),
          t("الحروق (Burn): التهاب جهازي واسع + استنشاق دخان.", "Burns: widespread systemic inflammation + smoke inhalation."),
          t("الانصمام (Embolization): صمة دهنية، صمة خثرية رئوية، صمة هوائية، صمة السائل الأمنيوسي. عادة الصمة الصغيرة تسد فرع صغير، بس ممكن تسبب ARDS، والصمة الكبيرة ← انصمام رئوي واسع ← ARDS.", "Embolization: fat, pulmonary thrombo-, air and amniotic fluid emboli. Small emboli block small branches but may cause ARDS; a big embolus → massive embolization → ARDS."),
          t("الأذى المباشر بالحوامض (القيء أو الارتجاع ← استنشاق حامض المعدة).", "Direct acid damage (vomiting/regurgitation → aspiration of gastric acid)."),
          t("الغرق (Drowning): الماء مؤذي للرئة ويبدأ ARDS.", "Drowning: water is detrimental to the lung and initiates ARDS."),
          t("الشنق (Hanging): انتحاري أو إعدام – إذا نجا المريض يتطور عنده ARDS.", "Hanging: suicidal or execution – a survivor may develop ARDS."),
          t("استنشاق المواد الكيمياوية والسامة: بالحروب (الجنود)، عمال تصفية الماء (الكلور مهيج جداً للرئة)، وربات البيوت اللي يستخدمن المنظفات بتركيز عالي.", "Inhalation of chemicals/toxins: wars (soldiers), water-treatment workers (chlorine is very irritant), housewives using concentrated detergents."),
          t("المجازة القلبية الرئوية (Cardiopulmonary bypass) بعمليات القلب.", "Cardiopulmonary bypass in cardiac surgery."),
          t("نقل الدم المتعدد (Multiple blood transfusion).", "Multiple blood transfusion."),
          t("الغازات السامة – ومنها الأوكسجين نفسه! بتركيز عالي لأكثر من 24 ساعة (مثل 100% بجهاز التنفس المغلق).", "Toxic gases – including oxygen itself! At high concentration for >24 h (e.g. 100% in a closed-circuit ventilator)."),
        ]},
        { k: "game", name: "ards-cause-catch", title: t("لعبة: صيّاد مسببات ARDS", "Game: ARDS Trigger Catcher"), caption: t("فقاعات تطير بالشاشة – انفجر فقط اللي تسبب ARDS حسب المحاضرة! الغلط يكلفك وقت", "Bubbles float across – pop only those that cause ARDS per the lecture! Mistakes cost time") },
        { k: "callout", tone: "warn", title: t("المفارقة الكبرى: الأوكسجين علاج وسبب", "The big paradox: oxygen is both cure and cause"), body: t("الأوكسجين يستخدم لعلاج ARDS، بس هو غاز مهيج إذا انعطى بتركيز عالي. فممنوع إعطاء تركيز عالي (نقي 100%) لأكثر من 24 ساعة – وهذا ممكن يصير بأجهزة التنفس إذا المريض يتنفس بدائرة مغلقة ويأخذ أوكسجين نقي.", "Oxygen treats ARDS but is irritant at high concentration. Pure (100%) O₂ must not be given >24 h – this can happen on ventilators breathing a closed circuit of pure O₂.") },
        { k: "anim", name: "o2-timer", title: t("ساعة سمية الأوكسجين", "Oxygen toxicity clock"), caption: t("شغّل الساعة على 100% أوكسجين: بعد 24 ساعة يبدأ التلف", "Run the clock on 100% oxygen: damage begins after 24 h") },
        { k: "images", items: [IMG.trali, IMG.drowning, IMG.neuroEdema] },
        { k: "video", items: [VID.ards2, VID.o2tox] },
      ],
    },
    {
      id: "patho3", icon: "🔬", title: t("الآلية المرضية (Pathophysiology)", "Pathophysiology"),
      blocks: [
        { k: "lead", text: t(
          "مهما كان السبب، ARDS يؤدي لتدمير نسيج الرئة. هذا النسيج يحتوي بطانة الأوعية الدموية (Endothelium) وظهارة الأسناخ (Epithelium) – وهاي الطبقتين سوية يكونن الغشاء التنفسي (Respiratory membrane).",
          "Whatever the cause, ARDS destroys lung tissue. This tissue contains the vessel endothelium and alveolar epithelium – which together form the respiratory membrane."
        )},
        { k: "three", name: "alveolus", title: t("نموذج 3D: سنخ طبيعي مقابل سنخ ARDS", "3D model: normal alveolus vs ARDS alveolus"), caption: t("اضغط زر ARDS: شوف السائل الغني بالبروتين يتسرب من الشعيرات ويملي السنخ", "Press ARDS: watch protein-rich fluid leak from capillaries and fill the alveolus") },
        { k: "anim", name: "ards-cascade", title: t("شلال الالتهاب خطوة بخطوة", "The inflammatory cascade step by step"), caption: t("اضغط 'التالي' لتشوف كل مرحلة من الأذى السنخي الالتهابي", "Press 'Next' to see each stage of inflammatory alveolar injury") },
        { k: "steps", title: t("الأذى السنخي الالتهابي (Inflammatory alveolar injury)", "Inflammatory alveolar injury"), items: [
          { title: t("تفعيل الوسائط الالتهابية والخلايا", "Activation of mediators & cells"), body: t("الخلايا الالتهابية (خصوصاً العدلات Neutrophils) تتجمع وتطلق مواد تتلف بطانة الشعيرات وظهارة الأسناخ.", "Inflammatory cells (esp. neutrophils) gather and release substances damaging capillary endothelium and alveolar epithelium.") },
          { title: t("زيادة نفاذية الغشاء", "Increased membrane permeability"), body: t("الغشاء السنخي-الشعري صار 'مثقوب'.", "The alveolar-capillary membrane becomes 'leaky'.") },
          { title: t("تدفق سائل غني بالبروتين وخلايا التهابية", "Influx of protein-rich fluid & inflammatory cells"), body: t("للمسافات الهوائية – هذا هو الوذمة الرئوية (مثل اللي تصير بعجز القلب الأيسر بس السبب مختلف).", "Into airspaces – this is the pulmonary oedema (as in LHF but different cause).") },
          { title: t("خلل السيرفاكتانت (Surfactant dysfunction)", "Dysfunction of surfactant"), body: t("الخلايا السنخية النوع الثاني (Type II pneumocytes) تتضرر ← السيرفاكتانت يقل ← الأسناخ تنكمش.", "Type II pneumocytes damaged → less surfactant → alveoli collapse.") },
          { title: t("تيبس الرئة (Lung stiffness)", "Stiffness of the lung"), body: t("تلف الطبقتين بالالتهاب يخلي الرئة متيبسة وصعبة النفخ.", "Damage to both layers makes the lung stiff and hard to inflate.") },
        ]},
        { k: "explain", icon: "🫧", tone: "lilac", title: t("شنو هو السيرفاكتانت (Surfactant)؟", "What is surfactant?"), body: t(
          "مادة دهنية-بروتينية تفرزها الخلايا السنخية النوع الثاني، تبطن الأسناخ من الداخل وتقلل الشد السطحي. بدونها السنخ ينكمش مثل البالون المبلول اللي جدرانه تلتصق ببعض. لهذا بـ ARDS نحتاج ضغط إيجابي يبقي الأسناخ مفتوحة.",
          "A lipoprotein secreted by type II pneumocytes, lining alveoli and reducing surface tension. Without it the alveolus collapses like a wet balloon whose walls stick together. That's why in ARDS we need positive pressure to keep alveoli open."
        )},
        { k: "images", items: [IMG.ardsAlv, IMG.hyaline] },
        { k: "video", items: [VID.surf, VID.surf2] },
      ],
    },
    {
      id: "radio3", icon: "🩻", title: t("الأشعة: المرحلة الحادة والمزمنة", "Radiology: Acute & Chronic Phases"),
      blocks: [
        { k: "anim", name: "ards-phases", title: t("خط زمني: من الرئة الطبيعية للتليف", "Timeline: from normal lung to fibrosis"), caption: t("اسحب على الخط الزمني وشوف تطور صورة الأشعة يوم بعد يوم", "Drag along the timeline and watch the X-ray evolve day by day") },
        { k: "list", check: true, title: t("المرحلة الحادة (Acute phase)", "Acute phase"), items: [
          t("وذمة رئوية مع سويقة وعائية طبيعية (Normal vascular pedicle) – عرض المنصف العلوي طبيعي لأن حجم الدم والضغط طبيعيين.", "Pulmonary oedema with normal vascular pedicle – normal upper mediastinal width as volume/pressure are normal."),
          t("بدون تضخم القلب (No cardiomegaly) وبدون تحويل الدم للفصوص العليا (No upper lobe diversion).", "No cardiomegaly and no upper lobe blood diversion."),
          t("إذا ظهرت الأوعية الرئوية فهي غالباً متقلصة (Constricted).", "When pulmonary vessels are visible they are often constricted."),
          t("الخطوط الحاجزية (Septal lines – Kerley B) غالباً غائبة، لأن التسرب يصير مباشرة للمسافات السنخية (بعكس الوذمة القلبية).", "Septal lines usually absent because capillary leak occurs directly into alveolar spaces (unlike cardiogenic oedema)."),
          t("تدمير رئوي متزايد وانتقال من ظلال سنخية إلى ظلال بينية (Alveolar → interstitial opacities).", "Progressive lung destruction and transition from alveolar to interstitial opacities."),
        ]},
        { k: "list", check: true, title: t("المرحلة المزمنة (Chronic phase)", "Chronic phase"), items: [
          t("تليف (Fibrosis).", "Fibrosis."),
          t("انتفاخ رئوي بؤري (Focal emphysema).", "Focal emphysema."),
        ]},
        { k: "callout", tone: "def", title: t("ARDS شديد / ALI شديد", "Severe ALI"), body: t("ارتشاحات شعاعية ثنائية (Bilateral radiographic infiltrates) + نسبة PaO₂/FiO₂ أقل من 200.", "Bilateral radiographic infiltrates + PaO₂/FiO₂ < 200.") },
        { k: "anim", name: "pf-ratio", title: t("حاسبة P/F التفاعلية", "Interactive P/F calculator"), caption: t("غيّر PaO₂ و FiO₂ – شوف إذا وصل المريض للمعيار (< 200)", "Change PaO₂ and FiO₂ – see if the patient meets the criterion (< 200)") },
        { k: "explain", icon: "🧮", tone: "sand", title: t("شنو يعني PaO₂/FiO₂؟", "What does PaO₂/FiO₂ mean?"), body: t(
          "FiO₂ = نسبة الأوكسجين بالهواء المستنشق (الهواء العادي 21% = 0.21). نقسم PaO₂ (بالـ mmHg) على FiO₂. الشخص الطبيعي: 100 ÷ 0.21 ≈ 476. إذا المريض ياخذ 60% أوكسجين وPaO₂ عنده 90 فقط: 90 ÷ 0.6 = 150 → أقل من 200 = شديد. يعني رغم الأوكسجين العالي، الدم ما يتأكسج.",
          "FiO₂ = fraction of inspired oxygen (room air 21% = 0.21). Divide PaO₂ (mmHg) by FiO₂. Normal: 100 ÷ 0.21 ≈ 476. If a patient on 60% O₂ has PaO₂ of only 90: 90 ÷ 0.6 = 150 → < 200 = severe. Despite high oxygen, the blood doesn't oxygenate."
        )},
        { k: "images", items: [IMG.ards, IMG.ardsCrop, IMG.chf, IMG.kerley, IMG.uip] },
      ],
    },
    {
      id: "clinic3", icon: "🩺", title: t("الأعراض وخلاصة النتائج", "Clinical Features & Summary of Findings"),
      blocks: [
        { k: "lead", text: t("أي مريض عنده مشكلة طبية أو جراحية شديدة، وتطور عنده فشل تنفسي شديد خلال أول يوم أو يومين – لازم تفكر بـ ARDS. وكذلك تلقى أعراض السبب الأساسي.", "Any patient with a severe medical or surgical problem who develops severe respiratory failure within the first 1–2 days – think ARDS. You also find features of the cause.") },
        { k: "stats", items: [
          { value: "1–2", label: t("يوم بعد المرض/الجراحة يبدأ ضيق النفس", "days after illness/surgery SOB begins") },
          { value: "<200", label: t("نسبة PaO₂/FiO₂ بالحالة الشديدة", "PaO₂/FiO₂ in severe cases") },
          { value: "24h", label: t("أقصى مدة للأوكسجين النقي", "max duration of pure O₂") },
          { value: "50–90%", label: t("نسبة الوفيات", "mortality range") },
        ]},
        { k: "list", check: true, title: t("خلاصة النتائج (7 نقاط – مهمة جداً)", "Summary of findings (7 points – very important)"), ordered: true, items: [
          t("ضيق نفس متزايد (خلال 1–2 يوم) بعد أي مشكلة طبية أو جراحية.", "Progressive SOB (1–2 days) following any medical or surgical problem."),
          t("زرقة مركزية مقاومة للعلاج (Resistant to treatment) – بعكس النوع الأول العادي اللي تتصحح بالأوكسجين.", "Central cyanosis resistant to treatment – unlike ordinary type I which corrects with O₂."),
          t("نقص أكسجين ونقص CO₂ (Hypoxia & hypocapnia) – يعني فشل تنفسي نوع أول.", "Hypoxia & hypocapnia – i.e. type I respiratory failure."),
          t("ظلال واسعة ثنائية الجانب بصورة الصدر.", "Widespread bilateral shadowing on chest X-ray."),
          t("بقسطرة القلب الأيمن لقياس ضغط الأوردة الرئوية: يكون طبيعي (ضغط إسفيني رئوي طبيعي) رغم وجود الوذمة.", "On right heart catheterization the pulmonary venous (wedge) pressure is normal despite oedema."),
          t("التليف الرئوي هو العاقبة لمن ينجو.", "Pulmonary fibrosis is the sequel in survivors."),
          t("خرخرة ناعمة (Fine crepitations) بالفحص بسبب الوذمة.", "Fine crepitations on examination due to oedema."),
        ]},
        { k: "explain", icon: "🎈", tone: "mint", title: t("شنو هي قسطرة القلب الأيمن والضغط الإسفيني؟", "What is right heart catheterization & wedge pressure?"), body: t(
          "نمرر قسطرة بالون (Swan-Ganz) من وريد كبير ← الأذين الأيمن ← البطين الأيمن ← الشريان الرئوي، وننفخ البالون حتى 'ينحشر' بفرع صغير. الضغط اللي نقيسه هنا (Pulmonary capillary wedge pressure) يعكس ضغط الأذين الأيسر. بعجز القلب: مرتفع. بـ ARDS: طبيعي – وهذا يثبت إن الوذمة مو قلبية.",
          "A balloon catheter (Swan-Ganz) passes from a large vein → RA → RV → pulmonary artery, then the balloon 'wedges' in a small branch. The pressure measured (PCWP) reflects left atrial pressure. In heart failure: high. In ARDS: normal – proving the oedema isn't cardiac."
        )},
        { k: "images", items: [IMG.pac, IMG.cyanosis, IMG.ards] },
      ],
    },
    {
      id: "comp3", icon: "💥", title: t("المضاعفات", "Complications"),
      blocks: [
        { k: "disease", items: [
          { name: "Bacterial super-infection", icon: "🦠", what: t("التهاب بكتيري إضافي فوق ARDS.", "Secondary bacterial infection on top of ARDS."), cause: t("لأن سائل الوذمة وسط ممتاز لنمو الكثير من الأحياء المجهرية.", "Because oedema fluid is a good medium for many micro-organisms.") },
          { name: "Multiple organ failure", icon: "🫀", what: t("فشل أعضاء متعددة: الكبد، الكلية، القلب، أو الدماغ.", "Failure of liver, kidney, heart or brain."), cause: t("بسبب تسمم الدم (Septicaemia) – ولهذا نسبة الوفيات عالية حتى بأفضل المراكز.", "Due to septicaemia – that's why mortality is high even in the best centres.") },
          { name: "Pulmonary fibrosis", icon: "🕸️", what: t("تليف الرئة.", "Lung fibrosis."), cause: t("إذا نجا المريض من المرحلة الحادة، ينتهي بتليف رئوي.", "If the patient survives the acute phase, they end up with pulmonary fibrosis.") },
        ]},
        { k: "stats", items: [
          { value: "~50%", label: t("الوفيات بأفضل المراكز", "mortality in the best centres") },
          { value: "~70%", label: t("المعدل المتوسط", "average mortality") },
          { value: "~90%", label: t("ببلدنا (قلة الأجهزة المتطورة)", "in our country (lack of sophisticated equipment)") },
        ]},
        { k: "anim", name: "mof", title: t("شلون ينتشر الفشل للأعضاء؟", "How does failure spread to organs?"), caption: t("تسمم الدم ينطلق من الرئة ويوصل لكل عضو", "Sepsis spreads from the lung to each organ") },
      ],
    },
    {
      id: "rx3", icon: "🏥", title: t("العلاج بالعناية المركزة", "Treatment in ICU"),
      blocks: [
        { k: "lead", text: t("المريض لازم يتعالج بوحدة العناية المركزة (ICU) فيها جهاز تنفس اصطناعي، والعلاج موجه نحو: (A) السبب (طبي أو جراحي)، (B) الإجراءات العامة.", "The patient must be cared for in an ICU with mechanical ventilation, and treatment targets: (A) the cause (medical or surgical), (B) general measures.") },
        { k: "explain", icon: "🅰️", tone: "sky", title: t("A – الأوكسجين", "A – Oxygen therapy"), body: t("أوكسجين بتركيز عالي (Liberal) لكل المرضى بغض النظر عن السبب – بس مو أوكسجين نقي (تركيز عالي جداً) لأكثر من 24 ساعة لأنه مهيج لنسيج الرئة.", "Liberal O₂ for all patients regardless of cause – but not pure (very high) O₂ for more than 24 h as it irritates lung tissue.") },
        { k: "explain", icon: "🅱️", tone: "mint", title: t("B – التنفس الاصطناعي", "B – Mechanical ventilation"), body: t("بـ ARDS اكو تلف بالخلايا السنخية النوع الثاني ← السيرفاكتانت يقل، فنحتاج دائماً ضغط إيجابي حتى يبقي الرئة منفوخة ويدفع السوائل بعيد عن المسافات الهوائية. نوعين من التنفس المساعد يحافظون على هذا الضغط: (1) IPPV (2) PEEP.", "In ARDS type II pneumocytes are damaged → less surfactant, so we always need positive pressure to keep the lung inflated and push fluid away from airspaces. Two assisted modes maintain it: (1) IPPV (2) PEEP.") },
        { k: "compare", a: { title: t("IPPV – Intermittent Positive Pressure Ventilation", "IPPV – Intermittent Positive Pressure Ventilation"), points: [t("الجهاز يدفع الهواء للرئة بضغط إيجابي بشكل متقطع (كل نفس)", "Ventilator pushes air in with positive pressure intermittently (each breath)"), t("بالزفير الضغط يرجع للصفر", "On expiration pressure returns to zero"), t("يعوض عن جهد التنفس", "Takes over the work of breathing")] }, b: { title: t("PEEP – Positive End Expiratory Pressure", "PEEP – Positive End Expiratory Pressure"), points: [t("يبقي ضغط إيجابي حتى بنهاية الزفير", "Keeps positive pressure even at end of expiration"), t("يمنع الأسناخ من الانكماش (يعوض السيرفاكتانت)", "Prevents alveolar collapse (replaces surfactant role)"), t("يدفع السائل من الأسناخ للخارج ويحسن الأكسجة", "Pushes fluid out of alveoli and improves oxygenation")] } },
        { k: "anim", name: "peep", title: t("محاكي PEEP: السنخ مع وبدون ضغط", "PEEP simulator: alveolus with and without pressure"), caption: t("حرّك قيمة PEEP (0–15 cmH₂O) وشوف السنخ يبقى مفتوح والسائل يتراجع", "Move PEEP (0–15 cmH₂O) and watch the alveolus stay open and fluid recede") },
        { k: "anim", name: "ippv", title: t("منحنى الضغط: IPPV مقابل PEEP", "Pressure curve: IPPV vs PEEP"), caption: t("لاحظ خط الأساس: بالـ IPPV يرجع للصفر، وبالـ PEEP يبقى مرتفع", "Notice the baseline: returns to zero in IPPV, stays raised with PEEP") },
        { k: "list", check: true, title: t("C – إجراءات عامة أخرى", "C – Other general measures"), ordered: true, items: [
          t("التعامل مع الالتهاب (Dealing with infection).", "Dealing with infection."),
          t("التغذية والتغذية الوريدية قد تحتاج بالعناية.", "Feeding & IV nutrition may be needed in ICU."),
          t("النظافة (Cleanliness).", "Cleanliness."),
          t("منع قرح الفراش (Prevent bed sores).", "Prevent bed sores."),
          t("ضبط توازن الأملاح بدقة (Electrolyte balance).", "Electrolyte balance carefully controlled."),
          t("استخدام الستيرويدات (Steroids).", "Use of steroids."),
        ]},
        { k: "game", name: "vent-rescue", title: t("لعبة: إنقاذ بالعناية المركزة – اضبط جهاز التنفس!", "Game: ICU Rescue – set the ventilator!"), caption: t("مريض ARDS حقيقي بالمحاكاة: اضبط FiO₂ و PEEP حتى تبقي التشبع فوق 90% بدون سمية أوكسجين – الوقت يمشي ساعة بعد ساعة!", "Simulated ARDS patient: tune FiO₂ and PEEP to keep SpO₂ above 90% without oxygen toxicity – the clock runs hour by hour!") },
        { k: "images", items: [IMG.vent, IMG.pac] },
        { k: "video", items: [VID.peep, VID.peepArds] },
        { k: "past", ids: ["p24", "p25"] },
      ],
    },
  ],
};
