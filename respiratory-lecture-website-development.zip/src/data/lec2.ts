import { t, type Lecture } from "../types";
import { IMG, VID } from "./media";

export const lec2: Lecture = {
  id: "lec2", num: 2, emoji: "🫁", color: "#8fa9c9", lecturer: "Prof. Dr. Muhammed Waheeb",
  title: t("الفشل التنفسي", "Respiratory Failure"),
  summary: t(
    "الفشل التنفسي مو مرض بحد ذاته، هو 'نتيجة' لأمراض كثيرة. نتعلم تعريفه، نوعيه (الأول والثاني)، سبب كل نوع، أعراضه، تشخيصه وعلاجه.",
    "Respiratory failure is not a disease itself but a 'result' of many diseases. We learn its definition, two types, causes of each, features, diagnosis and treatment."
  ),
  objectives: [
    t("تعريف الفشل التنفسي وشروطه (مستوى سطح البحر وأثناء الراحة).", "Define respiratory failure and its conditions (sea level, at rest)."),
    t("التفريق بين النوع الأول والثاني حسب غازات الدم والآلية.", "Differentiate type I and II by blood gases and mechanism."),
    t("معرفة أسباب كل نوع وأعراضه وعلاجه.", "Know causes, features and treatment of each type."),
  ],
  sections: [
    {
      id: "def", icon: "📖", title: t("التعريف والفسيولوجيا", "Definition & Physiology"),
      blocks: [
        { k: "callout", tone: "def", title: t("التعريف (احفظه حرفياً)", "Definition (memorise it)"), body: t(
          "غازات دم غير طبيعية بسبب أمراض الجهاز التنفسي أو مركز السيطرة عليه (أي مركز التنفس بالدماغ – Respiratory centre)، عندما يكون المريض يتنفس على مستوى سطح البحر وأثناء الراحة.",
          "Abnormal blood gases due to diseases of the respiratory system or its control (i.e. the respiratory centre) when the patient is breathing at sea level and at rest."
        )},
        { k: "explain", icon: "🏔️", tone: "sand", title: t("ليش 'سطح البحر' و'الراحة'؟", "Why 'sea level' and 'at rest'?"), body: t(
          "لأن بالمرتفعات العالية الهواء نفسه فقير بالأكسجين، فحتى الشخص السليم ينخفض عنده الأكسجين – وهذا مو فشل تنفسي. وأثناء الرياضة الشديدة ممكن تتغير الغازات مؤقتاً. فحتى نقول 'فشل تنفسي' لازم نستبعد هاي الظروف ونقيس والمريض مرتاح وبهواء طبيعي.",
          "At high altitude the air itself is oxygen-poor, so even a healthy person becomes hypoxic – that is not respiratory failure. During heavy exercise gases may change temporarily. To call it respiratory failure we exclude these conditions and measure at rest in normal air."
        )},
        { k: "lead", text: t(
          "حتى يصير التنفس صحيح نحتاج 3 وظائف مهمة تشتغل سوية: (1) تهوية صحيحة (Proper ventilation) – الهواء يوصل للأسناخ. (2) تروية صحيحة (Proper perfusion) – الدم يوصل للأسناخ. (3) تبادل غازات صحيح (Proper exchange) عبر الغشاء التنفسي.",
          "For proper respiration you need 3 functions working together: (1) proper ventilation – air reaches the alveoli; (2) proper perfusion – blood reaches the alveoli; (3) proper exchange of gases across the respiratory membrane."
        )},
        { k: "anim", name: "breath-3", title: t("الوظائف الثلاث للتنفس", "The three functions of respiration"), caption: t("اضغط على كل وظيفة لتعطلها وشوف شنو يصير للأكسجين", "Tap each function to break it and see what happens to oxygen") },
        { k: "three", name: "gas", title: t("نموذج 3D: تبادل الغازات بالسنخ", "3D model: gas exchange in the alveolus"), caption: t("O₂ (أزرق) يعبر للدم و CO₂ (برتقالي) يطلع للسنخ", "O₂ (blue) crosses into blood and CO₂ (orange) exits to the alveolus") },
        { k: "list", check: true, title: t("الوظائف الثلاث", "The three functions"), items: [
          t("التهوية (Ventilation)", "Ventilation"), t("التروية (Perfusion)", "Perfusion"), t("تبادل الغازات (Exchange of gases)", "Exchange of gases"),
        ]},
      ],
    },
    {
      id: "class", icon: "⚖️", title: t("التصنيف: النوع الأول مقابل الثاني", "Classification: Type I vs Type II"),
      blocks: [
        { k: "lead", text: t(
          "سريرياً، الفشل التنفسي يتصنف إلى نوعين حسب وجود أو غياب ارتفاع ثاني أكسيد الكربون (Hypercapnia). يعني السؤال الأساسي: هل الـ CO₂ مرتفع؟",
          "Clinically, respiratory failure is classified into 2 types depending on the presence or absence of hypercapnia. The key question: is CO₂ high?"
        )},
        { k: "chips", title: t("مصطلحات لازم تفهمها", "Terms you must understand"), items: [
          { term: "Hypoxia / Hypoxaemia", meaning: t("نقص الأكسجين بالدم: PaO₂ < 8 kPa (60 mmHg)", "Low blood oxygen: PaO₂ < 8 kPa (60 mmHg)") },
          { term: "Hypercapnia", meaning: t("ارتفاع CO₂ بالدم: PaCO₂ > 6 kPa (45 mmHg)", "High blood CO₂: PaCO₂ > 6 kPa (45 mmHg)") },
          { term: "Normocapnia", meaning: t("CO₂ طبيعي", "Normal CO₂") },
          { term: "Hypocapnia", meaning: t("CO₂ منخفض (لأن المريض يلهث بسرعة ويطرد CO₂)", "Low CO₂ (patient breathes fast and blows CO₂ off)") },
        ]},
        { k: "compare", a: { title: t("النوع الأول (Type I)", "Type I"), points: [t("نقص أكسجين + CO₂ طبيعي أو منخفض", "Hypoxia + normo- or hypocapnia"), t("الآلية: عدم تطابق التهوية-التروية (V/Q mismatch)", "Mechanism: V/Q mismatching"), t("الرئة نفسها مريضة بس المريض يقدر يتنفس بقوة", "The lung is diseased but the patient can still breathe hard"), t("العلاج: أوكسجين بتركيز عالي (Liberal)", "Treatment: liberal (high) O₂")] }, b: { title: t("النوع الثاني (Type II)", "Type II"), points: [t("نقص أكسجين + ارتفاع CO₂", "Hypoxia + hypercapnia"), t("الآلية: نقص التهوية (Hypoventilation)", "Mechanism: hypoventilation"), t("'المضخة' عاجزة – الهواء ما يدخل ويطلع كفاية", "The 'pump' fails – not enough air moves in and out"), t("العلاج: أوكسجين مضبوط + تحسين التهوية", "Treatment: controlled O₂ + improve ventilation")] } },
        { k: "anim", name: "type1-type2", title: t("مقياس الغازات: النوع الأول ضد الثاني", "Gas gauges: type I vs type II"), caption: t("بدّل بين النوعين وشوف مؤشرات O₂ و CO₂", "Switch types and watch the O₂ and CO₂ gauges") },
        { k: "callout", tone: "memory", title: t("حيلة الحفظ", "Memory trick"), body: t("النوع 1 = مشكلة 1 (بس O₂ نازل). النوع 2 = مشكلتين (O₂ نازل + CO₂ صاعد).", "Type 1 = 1 problem (only O₂ low). Type 2 = 2 problems (O₂ low + CO₂ high).") },
        { k: "video", items: [VID.rf, VID.rf2] },
        { k: "past", ids: ["p9", "p10"] },
      ],
    },
    {
      id: "t1mech", icon: "🔀", title: t("النوع الأول: عدم تطابق V/Q", "Type I: V/Q Mismatch"),
      blocks: [
        { k: "lead", text: t(
          "العامل المرضي الرئيسي في النوع الأول هو عدم تطابق التهوية مع التروية (Ventilation-Perfusion mismatching). بالرئة الطبيعية كل سنخ يوصله هواء ودم بنسبة متناسقة. إذا اختلت هاي النسبة، الدم يعبر بدون ما ياخذ أكسجين كافي.",
          "The main pathogenetic factor in type I is ventilation–perfusion mismatching. In a normal lung each alveolus gets air and blood in balance. If this ratio is disturbed, blood passes without picking up enough oxygen."
        )},
        { k: "anim", name: "vq-mismatch", title: t("محاكي V/Q: طبيعي / تحويلة / حيز ميت", "V/Q simulator: normal / shunt / dead space"), caption: t("اختار الحالة وشوف حركة الهواء والدم ولون الدم الخارج", "Choose the scenario and watch air, blood and the colour of blood leaving") },
        { k: "compare", a: { title: t("تحويلة (Shunt) – V قليل", "Shunt – low V"), points: [t("دم يوصل بس هواء ما يوصل (السنخ مليان سائل/قيح أو منخمص)", "Blood arrives but air doesn't (alveolus full of fluid/pus or collapsed)"), t("أمثلة: ذات الرئة، الوذمة الرئوية، ARDS", "Examples: pneumonia, pulmonary oedema, ARDS")] }, b: { title: t("حيز ميت (Dead space) – Q قليل", "Dead space – low Q"), points: [t("هواء يوصل بس دم ما يوصل (الشريان مسدود)", "Air arrives but blood doesn't (artery blocked)"), t("مثال: الصمة الرئوية", "Example: pulmonary embolism")] } },
        { k: "explain", icon: "❓", tone: "lilac", title: t("طيب ليش الـ CO₂ ما يرتفع بالنوع الأول؟", "So why doesn't CO₂ rise in type I?"), body: t(
          "لأن الـ CO₂ ينتشر بسهولة أكبر بـ 20 مرة من O₂، والمريض يحس بنقص الأكسجين فيتنفس بسرعة (Tachypnoea). هذا التنفس السريع يطرد الـ CO₂ من الأجزاء السليمة بالرئة، فيبقى طبيعي أو حتى ينخفض. بس الأكسجين ما يقدر يتعوض بنفس الطريقة لأن الدم بالأجزاء السليمة أصلاً مشبع تقريباً 100%.",
          "CO₂ diffuses ~20× more easily than O₂, and the hypoxic patient breathes fast (tachypnoea). This washes CO₂ out through the healthy lung parts, so it stays normal or even falls. Oxygen cannot be compensated the same way because blood in healthy parts is already ~100% saturated."
        )},
        { k: "video", items: [VID.vqm, VID.shunt] },
      ],
    },
    {
      id: "t1causes", icon: "🧾", title: t("أسباب النوع الأول", "Causes of Type I"),
      blocks: [
        { k: "lead", text: t("المحاضرة تقسم الأسباب لثلاث مجاميع: عيوب تقييدية بالتهوية، عيوب انسدادية بالتهوية، وأسباب وعائية. كل مرض هنا لازم تعرف شنو هو وليش يسبب V/Q mismatch.", "The lecture groups causes into three: restrictive ventilation defects, obstructive ventilation defects, and vascular causes. For each disease know what it is and why it causes V/Q mismatch.") },
        { k: "explain", icon: "1️⃣", tone: "mint", title: t("أولاً: العيوب التقييدية (Restrictive defects)", "1. Restrictive defects of ventilation"), body: t("الرئة ما تقدر تتمدد أو الأسناخ مليانة بشي غير الهواء.", "The lung cannot expand or the alveoli are filled with something other than air.") },
        { k: "disease", items: [
          { name: "Infiltrative lung diseases", icon: "🕸️", what: t("أمراض ترتشح بنسيج الرئة البيني (مثل التليف الرئوي، الساركويد) فتصير الرئة سميكة ومتيبسة.", "Diseases infiltrating the lung interstitium (e.g. pulmonary fibrosis, sarcoidosis) making it thick and stiff."), cause: t("الغشاء التنفسي يتسمك ← تبادل الغازات يضعف + الرئة ما تتمدد.", "Thickened membrane → impaired gas exchange + poor expansion."), sign: t("CT: ظلال شبكية، وبالمتقدم شكل قرص العسل.", "CT: reticular shadowing, honeycombing when advanced.") },
          { name: "Pneumonias", icon: "🦠", what: t("التهاب بالأسناخ تسببه جراثيم، فتمتلي الأسناخ بالقيح والسوائل الالتهابية.", "Infection of alveoli by organisms, filling them with pus and inflammatory fluid."), cause: t("الأسناخ المليانة ما يوصلها هواء بس الدم يمر ← تحويلة (Shunt).", "Filled alveoli get no air but blood still flows → shunt."), sign: t("حمى، كحة ببلغم، وبالأشعة بياض بفص (Consolidation).", "Fever, productive cough, X-ray lobar whiteness (consolidation).") },
          { name: "Cardiac pulmonary oedema", icon: "❤️", what: t("عجز البطين الأيسر ← الضغط يرتفع بالأذين الأيسر والأوردة الرئوية ← السائل يرشح للرئة.", "Left ventricular failure → raised left atrial & pulmonary venous pressure → fluid leaks into lung."), cause: t("الأسناخ تمتلي سائل ← تحويلة.", "Fluid-filled alveoli → shunt."), sign: t("تضخم القلب، خطوط كيرلي B، تحويل الدم للفصوص العليا.", "Cardiomegaly, Kerley B lines, upper lobe diversion.") },
          { name: "ARDS", icon: "🌫️", what: t("متلازمة الضائقة التنفسية الحادة – وذمة رئوية غير قلبية بسبب تلف الغشاء التنفسي (المحاضرة الثالثة كاملة عنها).", "Acute respiratory distress syndrome – non-cardiac pulmonary oedema from respiratory membrane damage (the whole of lecture 3)."), cause: t("الأسناخ تمتلي سائل غني بالبروتين ← تحويلة شديدة.", "Alveoli fill with protein-rich fluid → severe shunt."), sign: t("ظلال ثنائية منتشرة بدون تضخم قلب.", "Bilateral diffuse shadowing without cardiomegaly.") },
          { name: "Sudden pneumothorax", icon: "🎈", what: t("استرواح الصدر المفاجئ: دخول هواء لتجويف الجنب فتنكمش الرئة.", "Sudden air entry into the pleural space, collapsing the lung."), cause: t("الرئة المنكمشة ما تتهوى بس يبقى يجيها دم ← V/Q mismatch.", "Collapsed lung isn't ventilated but still perfused → V/Q mismatch."), sign: t("فرط رنين، غياب أصوات التنفس، وبالضاغط القصبة تنحرف للجهة الثانية.", "Hyper-resonance, absent breath sounds; in tension, trachea deviates away.") },
          { name: "Sudden pleural effusion", icon: "💧", what: t("تجمع مفاجئ لسائل كبير بالجنب يضغط على الرئة.", "Sudden large fluid collection in the pleura compressing the lung."), cause: t("الرئة المضغوطة ما تتمدد ← تهوية قليلة.", "Compressed lung can't expand → poor ventilation."), sign: t("أصمية صخرية (Stony dullness) وغياب أصوات التنفس.", "Stony dullness and absent breath sounds.") },
        ]},
        { k: "callout", tone: "exam", title: t("انتبه لكلمة 'Sudden'", "Notice the word 'Sudden'"), body: t("المحاضرة تقول استرواح/انصباب 'مفاجئ' – لأن الحالة المفاجئة ما تعطي الجسم وقت للتكيف فتسبب فشل حاد. نفس الحالة لو تطورت ببطء ممكن الجسم يتأقلم.", "The lecture says 'sudden' pneumothorax/effusion – acute onset gives no time to adapt, causing acute failure. The same slowly developing may be tolerated.") },
        { k: "images", items: [IMG.pneumonia, IMG.chf, IMG.ptxSigns, IMG.tension, IMG.effCxr, IMG.uip] },
        { k: "explain", icon: "2️⃣", tone: "sky", title: t("ثانياً: العيوب الانسدادية (Obstructive defects)", "2. Obstructive defects of ventilation"), body: t("القصبات تتضيق فالهواء ما يوصل لبعض الأسناخ.", "Airways narrow so air fails to reach some alveoli.") },
        { k: "disease", items: [
          { name: "Acute asthmatic attack", icon: "🌪️", what: t("نوبة ربو حادة: تقلص عضلات القصبات + التهاب + مخاط ← تضيق شديد.", "Acute asthma: bronchospasm + inflammation + mucus → severe narrowing."), cause: t("مناطق ما توصلها هواء كافي ← V/Q mismatch. ويبقى المريض يلهث فيطرد CO₂ (النوع الأول) – إلا إذا تعب فيرتفع الـ CO₂ (خطر!).", "Poorly ventilated areas → V/Q mismatch. The patient hyperventilates blowing off CO₂ (type I) – unless exhausted, then CO₂ rises (danger!)."), sign: t("صفير (Wheeze)؛ الصدر الصامت (Silent chest) + زرقة = مهدد للحياة.", "Wheeze; silent chest + cyanosis = life-threatening.") },
          { name: "Acute bronchiolitis", icon: "👶", what: t("التهاب القصيبات الحاد – غالباً فيروسي (RSV) عند الرضع.", "Acute inflammation of bronchioles – usually viral (RSV) in infants."), cause: t("القصيبات الصغيرة تنسد بالالتهاب والمخاط ← V/Q mismatch.", "Small bronchioles block with inflammation & mucus → V/Q mismatch."), sign: t("رضيع بلهاث وصفير وصعوبة رضاعة.", "Infant with tachypnoea, wheeze, feeding difficulty.") },
        ]},
        { k: "explain", icon: "3️⃣", tone: "rose", title: t("ثالثاً: الأسباب الوعائية (Vascular causes)", "3. Vascular causes"), body: t("الهواء يوصل بس الدم ما يوصل ← حيز ميت.", "Air arrives but blood doesn't → dead space.") },
        { k: "disease", items: [
          { name: "Pulmonary thromboembolism", icon: "🧱", what: t("خثرة (غالباً من أوردة الساق DVT) تسد شريان رئوي.", "A clot (usually from leg DVT) blocks a pulmonary artery."), cause: t("منطقة متهوية بدون تروية ← حيز ميت ← نقص أكسجين.", "Ventilated but unperfused area → dead space → hypoxia."), sign: t("ضيق نفس مفاجئ، ألم صدر، تسرع قلب؛ ECG: S1Q3T3؛ التشخيص بـ CTPA.", "Sudden dyspnoea, chest pain, tachycardia; ECG: S1Q3T3; diagnosis by CTPA.") },
          { name: "Pulmonary vasculitis", icon: "🔥", what: t("التهاب جدران الأوعية الدموية الرئوية (مناعي).", "Immune inflammation of pulmonary vessel walls."), cause: t("الأوعية تتضيق أو تنسد أو تنزف ← اضطراب التروية.", "Vessels narrow, occlude or bleed → disturbed perfusion."), sign: t("ممكن نفث دم وعلامات التهاب بأعضاء ثانية (كلية، جلد).", "May have hemoptysis and inflammation elsewhere (kidney, skin).") },
        ]},
        { k: "images", items: [IMG.ctpa, IMG.peEcg] },
        { k: "game", name: "triage-rush", title: t("لعبة: مطر الأسباب – النوع الأول أو الثاني؟", "Game: Cause Rain – type I or type II?"), caption: t("الأسباب تنزل من فوق وتسرع تدريجياً! صنّفها قبل ما توصل الأرض – عندك 3 أرواح", "Causes fall from above and speed up! Sort them before they hit the ground – 3 lives") },
        { k: "video", items: [VID.ptx, VID.pe] },
        { k: "past", ids: ["p13", "p14"] },
      ],
    },
    {
      id: "t1clinic", icon: "🩺", title: t("النوع الأول: الأعراض والتشخيص والعلاج", "Type I: Features, Diagnosis & Treatment"),
      blocks: [
        { k: "list", check: true, title: t("الأعراض والعلامات", "Clinical features"), items: [
          t("أعراض وعلامات المرض المسبب (مثلاً حمى وكحة بذات الرئة).", "Signs & symptoms of the underlying cause (e.g. fever & cough in pneumonia)."),
          t("أعراض نقص الأكسجين: ضيق نفس (SOB)، تململ (Restlessness)، هيجان (Agitation)، تشوش ذهني (Confusion)، وزرقة مركزية (Central cyanosis).", "Hypoxia: SOB, restlessness, agitation, confusion and central cyanosis."),
          t("ضيق نفس متزايد مع تنفس سريع وسطحي (Tachypnoea).", "Progressive SOB with tachypnoea (shallow & rapid breathing)."),
          t("الزرقة المركزية واضحة مع أقل مجهود، وتتصحح بإعطاء أوكسجين بتركيز أكثر من 30%.", "Central cyanosis obvious on minimal exertion, corrected by O₂ therapy > 30% concentration."),
        ]},
        { k: "explain", icon: "💙", tone: "sky", title: t("شنو هي الزرقة المركزية (Central cyanosis)؟", "What is central cyanosis?"), body: t(
          "لون أزرق بالشفاه واللسان والأغشية المخاطية، يظهر لما تكون كمية الهيموغلوبين غير المؤكسج بالدم الشرياني ≥ 5 g/dL. 'مركزية' لأن الدم الطالع من القلب والرئة نفسه ناقص أكسجين – بعكس الزرقة الطرفية (بالأصابع فقط) اللي سببها بطء الدورة الدموية أو البرد.",
          "A blue tinge of lips, tongue and mucous membranes, appearing when deoxygenated haemoglobin in arterial blood is ≥ 5 g/dL. 'Central' because blood leaving heart and lungs is itself under-oxygenated – unlike peripheral cyanosis (fingers only) due to slow circulation or cold."
        )},
        { k: "anim", name: "cyanosis-o2", title: t("الزرقة تتصحح بالأوكسجين", "Cyanosis corrects with oxygen"), caption: t("ارفع تركيز الأوكسجين (FiO₂) وشوف لون الشفاه ونسبة التشبع", "Raise FiO₂ and watch lip colour and saturation") },
        { k: "images", items: [IMG.cyanosis, IMG.venturi, IMG.cannula] },
        { k: "steps", title: t("التشخيص", "Diagnosis"), items: [
          { title: t("سريري بالأساس", "Mostly clinical"), body: t("القصة والفحص (لهاث، زرقة، تململ).", "History and exam (tachypnoea, cyanosis, restlessness).") },
          { title: t("تشخيص السبب", "Diagnose the underlying cause"), body: t("ذات رئة؟ صمة؟ وذمة؟", "Pneumonia? Embolism? Oedema?") },
          { title: t("الفحوصات المختبرية والشعاعية", "Lab & radiological investigations"), body: t("صورة صدر، تحليل دم، CT حسب الحاجة.", "CXR, blood tests, CT as needed.") },
          { title: t("التأكيد بغازات الدم الشرياني", "Confirmed by arterial blood gases"), body: t("PaO₂ منخفض + PaCO₂ طبيعي أو منخفض.", "Low PaO₂ + normal or low PaCO₂.") },
        ]},
        { k: "list", check: true, title: t("العلاج", "Treatment"), items: [
          t("علاج السبب الأساسي.", "Treat the underlying cause."),
          t("علاج عام: راحة بالفراش.", "General: rest in bed."),
          t("أوكسجين بتركيز عالي (Liberal O₂ therapy) – آمن هنا لأن المريض ما عنده احتباس CO₂.", "Liberal (high-concentration) O₂ – safe here because there is no CO₂ retention."),
        ]},
        { k: "video", items: [VID.cyan, VID.cyan2] },
        { k: "past", ids: ["p25"] },
      ],
    },
    {
      id: "t2", icon: "🫧", title: t("النوع الثاني: نقص التهوية والأسباب", "Type II: Hypoventilation & Causes"),
      blocks: [
        { k: "lead", text: t(
          "العامل المرضي الرئيسي بالنوع الثاني هو نقص التهوية (Hypoventilation): كمية الهواء الداخل والطالع من الرئة كلها قليلة. فما يدخل أكسجين كافي (O₂ ينزل) وما يطلع CO₂ كافي (CO₂ يتراكم). تخيل الرئة سليمة بس 'المنفاخ' عاطل.",
          "The main factor in type II is hypoventilation: total air moving in and out of the lungs is reduced. Not enough O₂ enters (O₂ falls) and not enough CO₂ leaves (CO₂ accumulates). Imagine healthy lungs but a broken 'bellows'."
        )},
        { k: "anim", name: "hypovent-chain", title: t("سلسلة التنفس: من الدماغ للقفص الصدري", "The breathing chain: from brain to thoracic cage"), caption: t("اضغط على أي حلقة لتكسرها – شوف شلون يرتفع الـ CO₂ وأي مرض يصيب هاي الحلقة", "Tap any link to break it – see CO₂ rise and which disease hits that link") },
        { k: "three", name: "lungs", title: t("نموذج 3D: تنفس طبيعي مقابل نقص تهوية", "3D model: normal breathing vs hypoventilation"), caption: t("لاحظ عمق حركة الرئتين – بنقص التهوية الحركة ضعيفة", "Notice the depth of lung movement – shallow in hypoventilation") },
        { k: "explain", icon: "1️⃣", tone: "sand", title: t("السبب الأول: COPD", "Cause 1: COPD"), body: t(
          "مرض الانسداد الرئوي المزمن (Chronic Obstructive Pulmonary Disease) – يشمل التهاب القصبات المزمن وانتفاخ الرئة، أهم سبب له التدخين. القصبات ضيقة بشكل دائم والأسناخ متهدمة، فالمريض يتعب من التنفس والتهوية الفعالة تقل ← CO₂ يتراكم. وهو أشهر سبب للنوع الثاني.",
          "Chronic obstructive pulmonary disease – chronic bronchitis and emphysema, mainly from smoking. Airways are permanently narrowed and alveoli destroyed; the patient tires and effective ventilation falls → CO₂ accumulates. It is the commonest cause of type II."
        )},
        { k: "explain", icon: "2️⃣", tone: "mint", title: t("السبب الثاني: الأسباب 'ضعيفة الحركة' (Hypodynamic)", "Cause 2: Hypodynamic causes"), body: t(
          "يعني الرئة سليمة بس القوة اللي تحركها ضعيفة. نمشي على السلسلة: الدماغ يعطي الأمر ← الأعصاب توصله ← العضلات تتقلص ← القفص الصدري يتمدد. أي حلقة تنكسر = نقص تهوية.",
          "The lung is healthy but the force moving it is weak. Follow the chain: brain gives the order → nerves carry it → muscles contract → thoracic cage expands. Break any link = hypoventilation."
        )},
        { k: "disease", items: [
          { name: "Respiratory centre depression", icon: "🧠", what: t("تثبيط مركز التنفس بجذع الدماغ – ما يرسل إشارات كافية.", "Depression of the brainstem respiratory centre – insufficient signals."), cause: t("الأسباب بالمحاضرة: الرضوض (Trauma)، الأورام (Tumors)، الجلطة الدماغية (Vascular accident)، التخدير (Anesthesia). وكذلك المهدئات والمورفين.", "Lecture causes: trauma, tumours, vascular accident (stroke), anaesthesia. Also sedatives and opiates."), sign: t("تنفس بطيء وسطحي مع نعاس.", "Slow shallow breathing with drowsiness.") },
          { name: "Nerves (intercostal & phrenic)", icon: "⚡", what: t("إصابة الأعصاب الوربية والعصب الحجابي اللي توصل الأوامر للعضلات.", "Affection of intercostal and phrenic nerves carrying orders to muscles."), cause: t("متلازمة غيلان-باريه (Guillain-Barré): التهاب مناعي يهاجم الأعصاب الطرفية بعد عدوى، يسبب شلل صاعد من الرجلين للأعلى. شلل الأطفال (Poliomyelitis): فيروس يدمر الخلايا العصبية الحركية.", "Guillain-Barré: post-infectious immune attack on peripheral nerves causing ascending paralysis from legs upward. Poliomyelitis: virus destroying motor neurons."), sign: t("ضعف عضلات تنفسية متزايد – نراقب السعة الحيوية.", "Progressive respiratory muscle weakness – monitor vital capacity.") },
          { name: "Muscles", icon: "💪", what: t("ضعف العضلات التنفسية نفسها.", "Weakness of the respiratory muscles themselves."), cause: t("اعتلال العضلات (Myopathies): أمراض وراثية أو مكتسبة تضعف العضلات. الوهن العضلي الوبيل (Myasthenia gravis): أجسام مضادة تهاجم مستقبلات الأستيل كولين بالوصلة العصبية العضلية، فالعضلة تتعب بسرعة مع التكرار.", "Myopathies: inherited/acquired muscle diseases. Myasthenia gravis: antibodies against acetylcholine receptors at the neuromuscular junction, so muscles fatigue quickly with use."), sign: t("بالوهن العضلي: تدلي الجفن وازدواج الرؤية يزيد آخر النهار.", "In MG: ptosis and diplopia worse at day's end.") },
          { name: "Thoracic cage", icon: "🦴", what: t("تشوه أو عدم ثبات القفص الصدري فما يتمدد صح.", "Deformed or unstable chest wall that can't expand properly."), cause: t("الحداب الجنفي (Kyphoscoliosis): انحناء العمود الفقري للأمام وللجانب يشوه الصدر. الصدر السائب (Flail chest): كسر 3 أضلاع أو أكثر بمكانين، فالقطعة المكسورة تنسحب للداخل بالشهيق وتطلع بالزفير (تنفس متناقض).", "Kyphoscoliosis: forward + sideways spinal curvature deforming the chest. Flail chest: ≥3 ribs broken in 2 places each, so the segment moves in on inspiration and out on expiration (paradoxical breathing)."), sign: t("Flail chest: حركة متناقضة بجزء من جدار الصدر.", "Flail chest: paradoxical movement of a chest wall segment.") },
        ]},
        { k: "images", items: [IMG.mg, IMG.kypho, IMG.flail, IMG.paradox, IMG.emphysema] },
        { k: "explain", icon: "3️⃣", tone: "rose", title: t("السبب الثالث: المرحلة النهائية للنوع الأول", "Cause 3: End stage of type I"), body: t(
          "مريض النوع الأول يلهث بسرعة لفترة طويلة حتى يعوض نقص الأكسجين. بالنهاية عضلات التنفس تتعب وتنهار (Exhaustion)، فالتهوية تنخفض ويبدي CO₂ يرتفع – فيتحول للنوع الثاني. مثال: مريض ربو حاد كان CO₂ عنده منخفض وصار طبيعي أو مرتفع = علامة خطر على الإنهاك.",
          "A type I patient breathes fast for a long time to compensate. Eventually respiratory muscles exhaust, ventilation drops and CO₂ rises – converting to type II. Example: an acute asthmatic whose low CO₂ becomes normal or high = danger sign of exhaustion."
        )},
        { k: "game", name: "chain-hunt", title: t("لعبة: صيّاد السلسلة", "Game: Chain Hunter"), caption: t("كل مرض يظهر – اضغط على الحلقة اللي يكسرها بالسلسلة (دماغ/عصب/عضلة/قفص/رئة) قبل ما يطلع الـ CO₂ للخط الأحمر!", "Each disease appears – tap the link it breaks (brain/nerve/muscle/cage/lung) before CO₂ hits the red line!") },
        { k: "video", items: [VID.gbs, VID.mg, VID.flail, VID.paradox] },
        { k: "past", ids: ["p11"] },
      ],
    },
    {
      id: "t2clinic", icon: "🧠", title: t("النوع الثاني: الأعراض والتشخيص والعلاج", "Type II: Features, Diagnosis & Treatment"),
      blocks: [
        { k: "list", check: true, title: t("الأعراض والعلامات (3 مجاميع)", "Clinical features (3 groups)"), items: [
          t("أعراض المرض المسبب.", "Features of the underlying cause."),
          t("أعراض نقص الأكسجين (مثل النوع الأول: ضيق نفس، زرقة، تململ).", "Features of hypoxia (as in type I: SOB, cyanosis, restlessness)."),
          t("أعراض ارتفاع CO₂: صداع (Headache)، خفقان (Palpitation)، رجفة (Tremor)، نعاس (Drowsiness)، تشوش ثم غيبوبة (Confusion & coma).", "Features of hypercapnia: headache, palpitation, tremor, drowsiness, confusion & coma."),
        ]},
        { k: "anim", name: "hypercapnia-brain", title: t("شنو يسوي الـ CO₂ بالجسم؟", "What does CO₂ do to the body?"), caption: t("ارفع الـ CO₂ تدريجياً وشوف الأعراض تظهر بالترتيب", "Raise CO₂ gradually and watch symptoms appear in order") },
        { k: "table", title: t("ليش كل عرض يصير؟", "Why does each symptom happen?"), head: [t("العرض", "Symptom"), t("التفسير", "Explanation")], rows: [
          [t("صداع (خصوصاً الصبح)", "Headache (esp. morning)"), t("CO₂ يوسع أوعية الدماغ ← ضغط داخل الجمجمة يرتفع. الصبح أسوأ لأن التنفس يقل بالنوم.", "CO₂ dilates cerebral vessels → raised intracranial pressure. Worse in the morning as breathing falls during sleep.")],
          [t("خفقان", "Palpitation"), t("CO₂ يحفز الجهاز العصبي الودي ← تسرع القلب، وأطراف دافئة ونبض قوي (Bounding pulse).", "CO₂ stimulates sympathetic system → tachycardia, warm hands, bounding pulse.")],
          [t("رجفة (Flapping tremor / Asterixis)", "Tremor (flapping / asterixis)"), t("اضطراب وظيفة الدماغ بسبب الحموضة وارتفاع CO₂ – اليد 'ترفرف' لما يمدها المريض.", "Brain dysfunction from acidosis & high CO₂ – outstretched hands 'flap'.")],
          [t("نعاس ← تشوش ← غيبوبة", "Drowsiness → confusion → coma"), t("ارتفاع شديد = تخدير بالـ CO₂ (CO₂ narcosis).", "Severe rise = CO₂ narcosis.")],
        ]},
        { k: "steps", title: t("التشخيص", "Diagnosis"), items: [
          { title: t("سريرياً", "Clinically"), body: t("أعراض نقص O₂ + ارتفاع CO₂.", "Hypoxia + hypercapnia features.") },
          { title: t("فحوصات مختبرية", "Lab investigations"), body: t("مثل تعداد الدم (كثرة الكريات الحمر بالمزمن).", "E.g. CBC (polycythaemia in chronic cases).") },
          { title: t("فحوصات شعاعية", "Radiological investigations"), body: t("صورة صدر للسبب.", "CXR for the cause.") },
          { title: t("غازات الدم الشرياني", "Arterial blood gases"), body: t("PaO₂ منخفض + PaCO₂ مرتفع ± pH منخفض (حموضة تنفسية).", "Low PaO₂ + high PaCO₂ ± low pH (respiratory acidosis).") },
        ]},
        { k: "list", check: true, title: t("العلاج", "Treatment"), items: [
          t("علاج السبب.", "Treat the cause."),
          t("إجراءات عامة تحسن التهوية السنخية = تحسين نقص الأكسجين وارتفاع CO₂.", "General measures improving alveolar ventilation = improving hypoxia & hypercapnia."),
          t("الأوكسجين (O₂ therapy) – مضبوط (Controlled) بتركيز قليل، مثل قناع فنتوري 24–28%.", "O₂ therapy – controlled low concentration, e.g. Venturi 24–28%."),
          t("تنظيف المجاري الهوائية (Airway clearance) – سحب البلغم، علاج طبيعي صدري، موسعات قصبات.", "Airway clearance – suction, chest physiotherapy, bronchodilators."),
          t("التنفس المساعد (Assisted ventilation) – غير جراحي (NIV/BiPAP) أو جهاز تنفس عبر أنبوب.", "Assisted ventilation – non-invasive (NIV/BiPAP) or invasive via tube."),
        ]},
        { k: "anim", name: "o2-copd", title: t("معضلة الأوكسجين بمريض COPD", "The oxygen dilemma in COPD"), caption: t("اختار نوع الأوكسجين: شوف شلون الأوكسجين العالي غير المضبوط يرفع CO₂ ويسبب نعاس", "Choose oxygen type: see how uncontrolled high O₂ raises CO₂ and causes drowsiness") },
        { k: "callout", tone: "warn", title: t("تحذير مهم", "Important warning"), body: t("بمريض النوع الثاني (خصوصاً COPD) الأوكسجين العالي غير المضبوط ممكن يرفع الـ CO₂ أكثر ويدخله بغيبوبة. وتجنب المهدئات والمنومات لأنها تثبط مركز التنفس.", "In type II (esp. COPD), uncontrolled high O₂ can raise CO₂ further and cause coma. Avoid sedatives/hypnotics as they depress the respiratory centre.") },
        { k: "images", items: [IMG.venturi, IMG.vent] },
        { k: "video", items: [VID.asterixis, VID.o2copd, VID.o2copd2] },
        { k: "past", ids: ["p12", "p18", "p19", "p26"] },
      ],
    },
    {
      id: "asthma-er", icon: "🚑", title: t("تطبيق: نوبة الربو بالطوارئ (أسئلة سنين)", "Application: Asthma in the ER (past papers)"),
      blocks: [
        { k: "lead", text: t("أسئلة السنين جمعت مفاهيم المحاضرة بحالة ربو مهددة للحياة: نوبة ربو حادة (سبب للنوع الأول) ← إنهاك ← تحول للنوع الثاني ← نحتاج تنفس مساعد.", "Past papers combine the lecture concepts in life-threatening asthma: acute asthma (type I cause) → exhaustion → conversion to type II → assisted ventilation needed.") },
        { k: "flow", items: [t("نوبة ربو حادة", "Acute asthma attack"), t("لهاث ← CO₂ منخفض (نوع 1)", "Tachypnoea → low CO₂ (type 1)"), t("إنهاك العضلات", "Muscle exhaustion"), t("CO₂ يرتفع (نوع 2)", "CO₂ rises (type 2)"), t("صدر صامت، بطء قلب، هبوط ضغط", "Silent chest, bradycardia, hypotension"), t("تنبيب وتنفس اصطناعي", "Intubation & ventilation")] },
        { k: "callout", tone: "exam", title: t("علامات الربو المهدد للحياة", "Life-threatening asthma features"), body: t("زرقة (Cyanosis)، صدر صامت (Silent chest)، جهد تنفسي ضعيف، بطء قلب، هبوط ضغط، إنهاك، تشوش. أما عدم إكمال الجملة، النبض ≥110، التنفس ≥25، و PEF 33–50% فهي علامات 'الربو الشديد الحاد' مو المهدد للحياة.", "Cyanosis, silent chest, feeble effort, bradycardia, hypotension, exhaustion, confusion. Inability to complete sentences, HR ≥110, RR ≥25 and PEF 33–50% are 'acute severe' – not life-threatening.") },
        { k: "past", ids: ["p20", "p21", "p22", "p23"] },
      ],
    },
  ],
};
