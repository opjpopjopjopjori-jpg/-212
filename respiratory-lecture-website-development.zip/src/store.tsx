import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { L } from "./types";

type Lang = "ar" | "en";
export type SrsRec = { box: number; right: number; wrong: number; last: number; due: number; streakWrong: number };

type Ctx = {
  lang: Lang; setLang: (l: Lang) => void; tr: (x: L) => string; ui: (ar: string, en: string) => string;
  done: Record<string, boolean>; isDone: (k: string) => boolean; toggle: (k: string) => void; setDone: (k: string, v: boolean) => void;
  srs: Record<string, SrsRec>; grade: (id: string, correct: boolean) => void; resetSrs: () => void;
};
const C = createContext<Ctx>(null as unknown as Ctx);

const load = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(k); return v ? (JSON.parse(v) as T) : d; } catch { return d; } };
const MIN = 60_000, DAY = 86_400_000;
const INTERVALS = [10 * MIN, 1 * DAY, 3 * DAY, 7 * DAY, 14 * DAY, 30 * DAY];

export function StoreProvider({ children }: { children: ReactNode }) {
  const [lang, setLangS] = useState<Lang>(() => load("rx-lang", "ar"));
  const [done, setDoneS] = useState<Record<string, boolean>>(() => load("rx-done", {}));
  const [srs, setSrs] = useState<Record<string, SrsRec>>(() => load("rx-srs", {}));

  useEffect(() => { document.documentElement.lang = lang; document.documentElement.dir = lang === "ar" ? "rtl" : "ltr"; localStorage.setItem("rx-lang", JSON.stringify(lang)); }, [lang]);
  useEffect(() => { localStorage.setItem("rx-done", JSON.stringify(done)); }, [done]);
  useEffect(() => { localStorage.setItem("rx-srs", JSON.stringify(srs)); }, [srs]);

  const tr = useCallback((x: L) => (lang === "ar" ? x.ar : x.en), [lang]);
  const ui = useCallback((ar: string, en: string) => (lang === "ar" ? ar : en), [lang]);
  const toggle = useCallback((k: string) => setDoneS((d) => ({ ...d, [k]: !d[k] })), []);
  const setDone = useCallback((k: string, v: boolean) => setDoneS((d) => ({ ...d, [k]: v })), []);
  const grade = useCallback((id: string, correct: boolean) => {
    setSrs((s) => {
      const now = Date.now();
      const r = s[id] ?? { box: 0, right: 0, wrong: 0, last: 0, due: 0, streakWrong: 0 };
      const box = correct ? Math.min(r.box + 1, 5) : 0;
      return { ...s, [id]: { box, right: r.right + (correct ? 1 : 0), wrong: r.wrong + (correct ? 0 : 1), last: now, due: now + INTERVALS[box], streakWrong: correct ? 0 : r.streakWrong + 1 } };
    });
  }, []);
  const resetSrs = useCallback(() => setSrs({}), []);

  const value = useMemo<Ctx>(() => ({ lang, setLang: setLangS, tr, ui, done, isDone: (k) => !!done[k], toggle, setDone, srs, grade, resetSrs }), [lang, tr, ui, done, toggle, setDone, srs, grade, resetSrs]);
  return <C.Provider value={value}>{children}</C.Provider>;
}
export const useStore = () => useContext(C);

export const srsStatus = (r?: SrsRec): "new" | "wrong" | "repeat" | "mastered" | "due" | "learning" => {
  if (!r) return "new";
  if (r.wrong >= 2 && r.box < 3) return "repeat";
  if (r.box === 0) return "wrong";
  if (r.box >= 4) return r.due <= Date.now() ? "due" : "mastered";
  return r.due <= Date.now() ? "due" : "learning";
};
