import { useMemo, useState } from "react";
import { useStore } from "../store";
import { MIND, type MNode } from "../data/extras";
import { ZoomPan } from "../components/ui";

const COLORS = ["#7fb39b", "#8fa9c9", "#d4a373", "#c99ab8", "#e0a08f", "#9cbf8a", "#b5a4d6", "#e3b75d"];
const tw = (s: string, fs: number) => Math.max(60, [...s].length * fs * 0.56 + 26);

export function MindView() {
  const { tr, ui, lang } = useStore();
  const tdir = lang === "ar" ? "rtl" : "ltr";
  const [li, setLi] = useState(0);
  const [closed, setClosed] = useState<number[]>([]);
  const root = MIND[li];
  const layout = useMemo(() => {
    const kids = root.children ?? [];
    const rootW = tw(tr(root.label), 18) + 20;
    const sides: { node: MNode; idx: number }[][] = [[], []];
    kids.forEach((k, i) => sides[i % 2].push({ node: k, idx: i }));
    const out: { x: number; y: number; w: number; h: number; text: string; color: string; level: number; idx: number; parent?: { x: number; y: number }; side: number; count?: number }[] = [];
    let minY = 0, maxY = 0, minX = -rootW / 2, maxX = rootW / 2;
    sides.forEach((list, s) => {
      const dir = s === 0 ? 1 : -1;
      const blocks = list.map(({ node, idx }) => { const leaves = closed.includes(idx) ? [] : node.children ?? []; return { node, idx, leaves, h: Math.max(48, leaves.length * 34) + 22 }; });
      const total = blocks.reduce((n, b) => n + b.h, 0);
      let y = -total / 2;
      blocks.forEach((b) => {
        const cy = y + b.h / 2; const color = COLORS[b.idx % COLORS.length];
        const cw = tw(tr(b.node.label), 15);
        const cx = dir * (rootW / 2 + 70 + cw / 2);
        out.push({ x: cx, y: cy, w: cw, h: 38, text: tr(b.node.label), color, level: 1, idx: b.idx, parent: { x: dir * rootW / 2, y: 0 }, side: dir, count: b.node.children?.length });
        b.leaves.forEach((lf, j) => {
          const lw = tw(tr(lf.label), 12.5);
          const ly = cy - ((b.leaves.length - 1) * 34) / 2 + j * 34;
          const lx = cx + dir * (cw / 2 + 50 + lw / 2);
          out.push({ x: lx, y: ly, w: lw, h: 28, text: tr(lf.label), color, level: 2, idx: b.idx, parent: { x: cx + dir * cw / 2, y: cy }, side: dir });
          minX = Math.min(minX, lx - lw / 2); maxX = Math.max(maxX, lx + lw / 2);
        });
        minX = Math.min(minX, cx - cw / 2); maxX = Math.max(maxX, cx + cw / 2);
        y += b.h;
      });
      minY = Math.min(minY, -total / 2); maxY = Math.max(maxY, total / 2);
    });
    return { out, rootW, vb: `${minX - 30} ${minY - 30} ${maxX - minX + 60} ${maxY - minY + 60}` };
  }, [root, closed, tr]);
  return (
    <div className="space-y-4">
      <div className="view-head"><span className="sticker" style={{ background: "#e3efd8" }}>🗺️</span><div><h1>{ui("الخريطة الذهنية", "Mind Map")}</h1><p>{ui("اضغط على أي فرع حتى تطويه أو تفتحه • كبّر واسحب للتنقل", "Tap a branch to collapse/expand • zoom & drag to navigate")}</p></div></div>
      <div className="flex flex-wrap gap-2 items-center">
        <div className="seg">{MIND.map((m, i) => <button key={i} className={li === i ? "on" : ""} onClick={() => { setLi(i); setClosed([]); }}>LEC {i + 1} · {tr(m.label)}</button>)}</div>
        <button className="pill" onClick={() => setClosed([])}>⊕ {ui("افتح الكل", "Expand all")}</button>
        <button className="pill" onClick={() => setClosed((root.children ?? []).map((_, i) => i))}>⊖ {ui("اطوِ الكل", "Collapse all")}</button>
      </div>
      <div className="mind-box">
        <ZoomPan minH={560}>
          <svg viewBox={layout.vb} className="mind-svg" style={{ width: "100%", height: 560 }}>
            <defs><filter id="msh" x="-10%" y="-10%" width="120%" height="140%"><feDropShadow dx="2" dy="3" stdDeviation="0" floodColor="#3f3d38" floodOpacity=".9" /></filter></defs>
            {layout.out.map((n, i) => n.parent && <path key={"l" + i} d={`M${n.parent.x},${n.parent.y} C${(n.parent.x + n.x - n.side * n.w / 2) / 2},${n.parent.y} ${(n.parent.x + n.x - n.side * n.w / 2) / 2},${n.y} ${n.x - n.side * n.w / 2},${n.y}`} fill="none" stroke={n.color} strokeWidth={n.level === 1 ? 5 : 2.5} strokeLinecap="round" opacity={n.level === 1 ? 0.9 : 0.75} className="draw-path" />)}
            <g filter="url(#msh)"><rect x={-layout.rootW / 2} y={-30} width={layout.rootW} height={60} rx={30} fill="#3f3d38" /></g>
            <text x={0} y={7} textAnchor="middle" fontSize="18" fontWeight="800" fill="#fbf8f2" direction={tdir}>{tr(root.label)}</text>
            {layout.out.map((n, i) => (
              <g key={"n" + i} onClick={() => n.level === 1 && setClosed((c) => (c.includes(n.idx) ? c.filter((x) => x !== n.idx) : [...c, n.idx]))} style={{ cursor: n.level === 1 ? "pointer" : "default" }} className="mind-node">
                {n.level === 1 ? <g filter="url(#msh)"><rect x={n.x - n.w / 2} y={n.y - n.h / 2} width={n.w} height={n.h} rx={14} fill={n.color} stroke="#3f3d38" strokeWidth="2" /></g>
                  : <rect x={n.x - n.w / 2} y={n.y - n.h / 2} width={n.w} height={n.h} rx={10} fill="#fffdf8" stroke={n.color} strokeWidth="2" />}
                <text x={n.x} y={n.y + (n.level === 1 ? 5 : 4)} textAnchor="middle" fontSize={n.level === 1 ? 15 : 12.5} fontWeight={n.level === 1 ? 800 : 500} fill="#3f3d38" direction={tdir}>{n.text}</text>
                {n.level === 1 && <g><circle cx={n.x + n.side * (n.w / 2)} cy={n.y - n.h / 2} r="9" fill="#fffdf8" stroke="#3f3d38" /><text x={n.x + n.side * (n.w / 2)} y={n.y - n.h / 2 + 4} textAnchor="middle" fontSize="11" fontWeight="800">{closed.includes(n.idx) ? "+" : n.count}</text></g>}
              </g>
            ))}
          </svg>
        </ZoomPan>
      </div>
    </div>
  );
}
