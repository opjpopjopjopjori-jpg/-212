import { useState, type MouseEvent } from "react";
import { useStore } from "../store";
import { DDX, CONFUSED, CASES, RAD, COMPARE_PAIRS } from "../data/extras";
import { SmartImg, ZoomPan, useLightbox } from "../components/ui";

export function DdxView() {
  const { tr, ui } = useStore();
  const [sel, setSel] = useState(DDX[0].id);
  const [lec, setLec] = useState(0);
  const list = DDX.filter((d) => !lec || d.lec === lec);
  const d = DDX.find((x) => x.id === sel) ?? DDX[0];
  const open = useLightbox();
  return (
    <div className="space-y-5">
      <div className="view-head"><span className="sticker" style={{ background: "#f8d9d2" }}>⚖️</span><div><h1>{ui("التشخيص التفريقي", "Differential Diagnosis")}</h1><p>{ui("شلون تفرق بين الأمراض المتشابهة – جنب بعض، صف بصف", "How to tell similar conditions apart – side by side, row by row")}</p></div></div>
      <div className="seg">{[0, 1, 2, 3].map((n) => <button key={n} className={lec === n ? "on" : ""} onClick={() => setLec(n)}>{n === 0 ? ui("الكل", "All") : `LEC ${n}`}</button>)}</div>
      <div className="ddx-tabs">{list.map((x) => <button key={x.id} onClick={() => setSel(x.id)} className={"ddx-tab " + (x.id === d.id ? "on" : "")} dir="ltr">{x.a} <i>vs</i> {x.b}</button>)}</div>
      <div className="ddx-card animate-fade" key={d.id}>
        <div className="ddx-header"><div className="ddx-a" dir="ltr">{d.a}</div><div className="ddx-vs">VS</div><div className="ddx-b" dir="ltr">{d.b}</div></div>
        {d.imgs && <div className="grid grid-cols-2 gap-3 my-3">{d.imgs.map((im, i) => <button key={i} className="ddx-img" onClick={() => open(d.imgs!, i)}><SmartImg img={im} /><span>{tr(im.cap)}</span></button>)}</div>}
        <div className="overflow-x-auto"><table className="ddx-table"><thead><tr><th>{ui("وجه المقارنة", "Feature")}</th><th dir="ltr">{d.a}</th><th dir="ltr">{d.b}</th></tr></thead><tbody>{d.rows.map((r, i) => <tr key={i}><td>{tr(r.label)}</td><td>{tr(r.a)}</td><td>{tr(r.b)}</td></tr>)}</tbody></table></div>
        <div className="ddx-key">🔑 <b>{ui("شنو يميز واحد عن الثاني؟ ", "What sets them apart? ")}</b>{tr(d.key)}</div>
      </div>
      <div>
        <div className="view-sub">🔀 Commonly Confused Conditions</div>
        <div className="fill-grid">{CONFUSED.map((c, i) => <div key={i} className="confuse-card"><div className="confuse-vs"><b dir="ltr">{c.a}</b><span>VS</span><b dir="ltr">{c.b}</b></div><div className="text-sm leading-relaxed">{tr(c.tip)}</div></div>)}</div>
      </div>
    </div>
  );
}

export function CasesView() {
  const { tr, ui, grade } = useStore();
  const [ci, setCi] = useState(0);
  const [step, setStep] = useState(0);
  const [found, setFound] = useState<number[]>([]);
  const [checked, setChecked] = useState(false);
  const [pick, setPick] = useState<number | null>(null);
  const c = CASES[ci];
  const reset = (i: number) => { setCi(i); setStep(0); setFound([]); setChecked(false); setPick(null); };
  const steps = [ui("المريض", "Patient"), ui("الصورة", "Image"), ui("العلامات", "Findings"), ui("التشخيص", "Diagnosis"), ui("التفسير", "Explanation")];
  return (
    <div className="space-y-4">
      <div className="view-head"><span className="sticker" style={{ background: "#d7ecdf" }}>🩺</span><div><h1>{ui("الحالات السريرية التفاعلية", "Interactive Clinical Cases")}</h1><p>{ui("الحالة تنكشف بالتدريج – أنت الطبيب", "The case unfolds step by step – you are the doctor")}</p></div></div>
      <div className="fill-grid tight">{CASES.map((x, i) => <button key={x.id} onClick={() => reset(i)} className={"case-pick " + (i === ci ? "on" : "")}><span className="tag">LEC {x.lec}</span> {tr(x.title)}</button>)}</div>
      <div className="case-card">
        <div className="stepper">{steps.map((s, i) => <div key={i} className={"st " + (i <= step ? "on" : "")}><span>{i + 1}</span>{s}</div>)}</div>
        <div className="mt-4 space-y-3">
          <div className="case-box"><b>👤 {ui("القصة:", "History:")}</b> {tr(c.patient)}</div>
          <div className="case-box"><b>📟 {ui("الفحص/العلامات الحيوية:", "Exam/vitals:")}</b> <span dir="auto">{tr(c.vitals)}</span></div>
          {step >= 1 && c.img && <div className="animate-fade"><ZoomPan minH={280}><SmartImg img={c.img} className="case-img" draggable={false} /></ZoomPan><div className="text-xs text-center mt-1 text-[#7c776b]">{ui("كبّر وحرّك الصورة – التشخيص مخفي لحد ما تجاوب", "Zoom & pan – diagnosis hidden until you answer")}</div></div>}
          {step >= 2 && <div className="animate-fade"><div className="font-bold mb-2">🔎 {ui("حدد العلامات غير الطبيعية/المهمة (اختيار متعدد):", "Select the abnormal/key findings (multi-select):")}</div>
            <div className="grid gap-2">{c.findings.map((f, i) => { const on = found.includes(i); const cls = checked ? (f.correct ? "right" : on ? "wrong" : "dim") : on ? "sel" : ""; return <button key={i} disabled={checked} onClick={() => setFound(on ? found.filter((x) => x !== i) : [...found, i])} className={"opt text-start " + cls}>{on ? "☑" : "☐"} {tr(f.text)}</button>; })}</div>
            {!checked && <button className="btn-soft mt-2" onClick={() => setChecked(true)}>{ui("تحقق", "Check")}</button>}
          </div>}
          {step >= 3 && <div className="animate-fade"><div className="font-bold mb-2">🧩 {ui("اختار التشخيص/الخطة الأرجح:", "Choose the most likely diagnosis/plan:")}</div>
            <div className="grid gap-2">{c.options.map((o, i) => <button key={i} onClick={() => { if (pick === null) { setPick(i); grade("case-" + c.id, i === c.answer); setStep(4); } }} className={"opt text-start " + (pick === null ? "" : i === c.answer ? "right" : i === pick ? "wrong" : "dim")} dir="ltr">{tr(o)}</button>)}</div></div>}
          {step >= 4 && <div className="animate-fade space-y-2">
            <div className="past-why"><b>✅ {ui("التشخيص والتفسير: ", "Diagnosis & explanation: ")}</b>{tr(c.explain)}</div>
            <div className="case-box"><b>🚫 {ui("ليش الخيارات الثانية أقل احتمالاً؟", "Why are the others less likely?")}</b><ul className="mt-1 space-y-1">{c.others.map((o, i) => <li key={i}>• {tr(o)}</li>)}</ul></div>
          </div>}
          <div className="flex gap-2 justify-end">
            {step < 3 && (step !== 2 || checked) && <button className="btn-soft" onClick={() => setStep(step + 1 === 1 && !c.img ? 2 : step + 1)}>{ui("الخطوة التالية", "Next step")} ›</button>}
            {step === 4 && ci < CASES.length - 1 && <button className="btn-soft" onClick={() => reset(ci + 1)}>{ui("الحالة التالية", "Next case")} ›</button>}
          </div>
        </div>
      </div>
    </div>
  );
}

export function RadLab() {
  const { tr, ui } = useStore();
  const [tab, setTab] = useState<"view" | "compare">("view");
  const [ri, setRi] = useState(0);
  const [marks, setMarks] = useState(false);
  const [reveal, setReveal] = useState(false);
  const [quiz, setQuiz] = useState(false);
  const [qi, setQi] = useState(0); const [qScore, setQScore] = useState(0); const [qFb, setQFb] = useState<null | { x: number; y: number; ok: boolean }>(null);
  const [pi, setPi] = useState(0); const [swipe, setSwipe] = useState(false); const [sw, setSw] = useState(50);
  const r = RAD[ri];
  const target = r.quiz[qi % r.quiz.length];
  const clickImg = (e: MouseEvent<HTMLDivElement>) => {
    if (!quiz) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100, y = ((e.clientY - rect.top) / rect.height) * 100;
    const ok = Math.hypot(x - target.x, y - target.y) <= target.r;
    setQFb({ x, y, ok }); if (ok) setQScore((s) => s + 1);
    setTimeout(() => { setQFb(null); setQi((i) => i + 1); }, 1100);
  };
  const choose = (i: number) => { setRi(i); setMarks(false); setReveal(false); setQuiz(false); setQi(0); setQScore(0); };
  const p = COMPARE_PAIRS[pi];
  return (
    <div className="space-y-4">
      <div className="view-head"><span className="sticker" style={{ background: "#dfe6f2" }}>🩻</span><div><h1>{ui("مختبر الأشعة التفاعلي", "Interactive Radiology Lab")}</h1><p>{ui("تكبير، تحريك، أسهم توضيحية، اختبار الأجزاء، ومقارنة جنباً إلى جنب", "Zoom, pan, toggle labels, part-identification quiz, and side-by-side comparison")}</p></div></div>
      <div className="seg"><button className={tab === "view" ? "on" : ""} onClick={() => setTab("view")}>🔍 {ui("العارض", "Viewer")}</button><button className={tab === "compare" ? "on" : ""} onClick={() => setTab("compare")}>🆚 {ui("مقارنة", "Compare")}</button></div>
      {tab === "view" ? (
        <div className="grid lg:grid-cols-[1fr_300px] gap-4">
          <div className="rad-stage">
            <ZoomPan minH={420}>
              <div className="rad-wrap" onClick={clickImg} style={{ cursor: quiz ? "crosshair" : undefined }}>
                <SmartImg img={r.img} className="rad-img" draggable={false} />
                {marks && r.marks.map((m, i) => <span key={i} className="rad-mark" style={{ left: `${m.x}%`, top: `${m.y}%` }}><i />{tr(m.label)}</span>)}
                {qFb && <span className={"rad-hit " + (qFb.ok ? "ok" : "bad")} style={{ left: `${qFb.x}%`, top: `${qFb.y}%` }}>{qFb.ok ? "✓" : "✗"}</span>}
                {qFb && !qFb.ok && <span className="rad-target" style={{ left: `${target.x}%`, top: `${target.y}%`, width: `${target.r * 2}%`, height: `${target.r * 2}%` }} />}
              </div>
            </ZoomPan>
          </div>
          <div className="space-y-3">
            <div className="fill-grid tight">{RAD.map((x, i) => <button key={x.id} onClick={() => choose(i)} className={"case-pick " + (i === ri ? "on" : "")}>{tr(x.title)}</button>)}</div>
            <div className="soft-card space-y-2">
              <label className="toggle"><input type="checkbox" checked={marks} onChange={(e) => setMarks(e.target.checked)} /> 🏷️ {ui("إظهار الأسهم والعلامات", "Show arrows & labels")}</label>
              <label className="toggle"><input type="checkbox" checked={quiz} onChange={(e) => { setQuiz(e.target.checked); setMarks(false); setQi(0); setQScore(0); }} /> 🎯 {ui("وضع الاختبار", "Quiz mode")}</label>
              {quiz && <div className="quiz-prompt">{ui("اضغط على: ", "Click on: ")}<b>{tr(target.label)}</b><div className="text-xs mt-1">⭐ {qScore} / {qi}</div></div>}
              <button className="btn-soft w-full" onClick={() => setReveal(!reveal)}>{reveal ? ui("إخفاء التفسير", "Hide interpretation") : ui("اكشف التشخيص والتفسير", "Reveal diagnosis & interpretation")}</button>
              {reveal && <div className="past-why animate-fade"><b>{tr(r.dx)}: </b>{tr(r.explain)}</div>}
            </div>
            <div className="text-xs text-[#7c776b]">🖱️ {ui("عجلة الماوس أو الأزرار للتكبير، اسحب للتحريك، دبل كلك للتكبير السريع", "Mouse wheel or buttons to zoom, drag to pan, double-click to quick-zoom")}</div>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div className="fill-grid tight">{COMPARE_PAIRS.map((x, i) => <button key={i} onClick={() => setPi(i)} className={"case-pick " + (i === pi ? "on" : "")}>{tr(x.title)}</button>)}</div>
          <label className="toggle"><input type="checkbox" checked={swipe} onChange={(e) => setSwipe(e.target.checked)} /> ↔️ {ui("وضع السحب فوق بعض", "Overlay swipe mode")}</label>
          {!swipe ? (
            <div className="grid md:grid-cols-2 gap-3">{[p.a, p.b].map((im, i) => <div key={i}><ZoomPan minH={340}><SmartImg img={im} className="rad-img" draggable={false} /></ZoomPan><div className="text-sm text-center mt-1 font-semibold">{tr(im.cap)}</div></div>)}</div>
          ) : (
            <div><div className="swipe-box"><SmartImg img={p.b} className="swipe-img" /><div className="swipe-top" style={{ clipPath: `inset(0 ${100 - sw}% 0 0)` }}><SmartImg img={p.a} className="swipe-img" /></div><div className="swipe-line" style={{ left: `${sw}%` }} /></div><input type="range" min={0} max={100} value={sw} onChange={(e) => setSw(+e.target.value)} className="w-full mt-2" /></div>
          )}
          <div className="callout" style={{ background: "#e7eef7" }}><span className="callout-ic">👁️</span><div>{tr(p.note)}</div></div>
        </div>
      )}
    </div>
  );
}
