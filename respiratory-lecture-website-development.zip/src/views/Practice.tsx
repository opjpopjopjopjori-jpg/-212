import { useMemo, useState } from "react";
import { useStore, srsStatus } from "../store";
import { MCQ, FLASH, PAST } from "../data/practice";
import { PastCard } from "../components/Blocks";
import { SmartImg } from "../components/ui";
import type { L, Img } from "../types";

type Q = { id: string; lec: number; q: L; options: L[]; answer: number; why: L; img?: Img; past?: boolean };
const ALLQ: Q[] = [...MCQ.map((m) => ({ ...m })), ...PAST.filter((p) => p.options).map((p) => ({ id: p.id, lec: p.lec, q: p.q, options: p.options!, answer: p.answer as number, why: p.why, img: p.img, past: true }))];
const shuffle = <T,>(a: T[]) => [...a].sort(() => Math.random() - 0.5);

function LecFilter({ v, set }: { v: number; set: (n: number) => void }) {
  const { ui } = useStore();
  return <div className="seg">{[0, 1, 2, 3].map((n) => <button key={n} className={v === n ? "on" : ""} onClick={() => set(n)}>{n === 0 ? ui("الكل", "All") : `LEC ${n}`}</button>)}</div>;
}

export function McqView({ smart = false }: { smart?: boolean }) {
  const { tr, ui, grade, srs } = useStore();
  const [lec, setLec] = useState(0);
  const [mode, setMode] = useState(smart ? "smart" : "all");
  const [seed, setSeed] = useState(0);
  const list = useMemo(() => {
    let l = ALLQ.filter((q) => !lec || q.lec === lec);
    if (mode === "smart") { const pri = (q: Q) => { const s = srsStatus(srs[q.id]); return s === "repeat" ? 0 : s === "wrong" ? 1 : s === "due" ? 2 : s === "new" ? 3 : 9; }; l = l.filter((q) => pri(q) < 9).sort((a, b) => pri(a) - pri(b)); }
    else if (mode === "past") l = l.filter((q) => q.past);
    return mode === "smart" ? l : shuffle(l);
  }, [lec, mode, seed]); // eslint-disable-line
  const [i, setI] = useState(0); const [pick, setPick] = useState<number | null>(null); const [score, setScore] = useState(0);
  const restart = () => { setI(0); setPick(null); setScore(0); setSeed((s) => s + 1); };
  const q = list[i];
  const choose = (k: number) => { if (pick !== null) return; setPick(k); grade(q.id, k === q.answer); if (k === q.answer) setScore((s) => s + 1); };
  return (
    <div className="space-y-4">
      <div className="view-head"><span className="sticker" style={{ background: "#fbe3c4" }}>✍️</span><div><h1>{ui("أسئلة الاختيار من متعدد", "Multiple Choice Questions")}</h1><p>{ui(`${ALLQ.length} سؤال (منها أسئلة سنين) – كل جواب يتسجل بنظام المراجعة الذكي`, `${ALLQ.length} questions (incl. past papers) – every answer feeds the smart review`)}</p></div></div>
      <div className="flex flex-wrap gap-2 items-center">
        <LecFilter v={lec} set={(n) => { setLec(n); restart(); }} />
        <div className="seg">{[["all", ui("كل الأسئلة", "All")], ["past", ui("سنين فقط", "Past only")], ["smart", ui("مراجعة ذكية 🧠", "Smart review 🧠")]].map(([k, l]) => <button key={k} className={mode === k ? "on" : ""} onClick={() => { setMode(k); restart(); }}>{l}</button>)}</div>
      </div>
      {!q ? (
        <div className="soft-card text-center py-10">{i >= list.length && list.length > 0 ? <><div className="text-5xl">🎉</div><div className="text-2xl font-black my-2">{score} / {list.length}</div><div className="mb-3">{Math.round((score / list.length) * 100)}%</div><button className="btn-soft" onClick={restart}>{ui("أعد", "Restart")} ↻</button></> : <div>{ui("ما اكو أسئلة تحتاج مراجعة حالياً 👌", "Nothing needs review right now 👌")}</div>}</div>
      ) : (
        <div className="soft-card mcq-card animate-fade" key={q.id + i}>
          <div className="flex justify-between items-center mb-3 text-sm"><span className="tag">LEC {q.lec}</span>{q.past && <span className="past-badge">📜 {ui("سنين", "Past")}</span>}<span>{i + 1} / {list.length} · ⭐ {score}</span></div>
          <div className="progress-line"><span style={{ width: `${((i + 1) / list.length) * 100}%` }} /></div>
          <div className="text-lg font-bold my-3 leading-relaxed">{tr(q.q)}</div>
          {q.img && <div className="past-img"><SmartImg img={q.img} /></div>}
          <div className="grid gap-2">{q.options.map((o, k) => <button key={k} onClick={() => choose(k)} className={"opt text-start " + (pick === null ? "" : k === q.answer ? "right" : k === pick ? "wrong" : "dim")}><b className="me-2">{String.fromCharCode(65 + k)}.</b>{tr(o)}</button>)}</div>
          {pick !== null && <div className="past-why animate-fade"><b>{pick === q.answer ? ui("✅ صح! ", "✅ Correct! ") : ui("❌ غلط. ", "❌ Wrong. ")}</b>{tr(q.why)}</div>}
          {pick !== null && <div className="text-end mt-3"><button className="btn-soft" onClick={() => { setI(i + 1); setPick(null); }}>{ui("التالي", "Next")} ›</button></div>}
        </div>
      )}
    </div>
  );
}

export function FlashView() {
  const { tr, ui, grade, srs } = useStore();
  const [lec, setLec] = useState(0); const [seed, setSeed] = useState(0);
  const list = useMemo(() => shuffle(FLASH.filter((f) => !lec || f.lec === lec)), [lec, seed]); // eslint-disable-line
  const [i, setI] = useState(0); const [flip, setFlip] = useState(false);
  const f = list[i % Math.max(1, list.length)];
  const rate = (ok: boolean) => { grade(f.id, ok); setFlip(false); setTimeout(() => setI((x) => x + 1), 150); };
  const mastered = FLASH.filter((x) => srsStatus(srs[x.id]) === "mastered").length;
  return (
    <div className="space-y-4">
      <div className="view-head"><span className="sticker" style={{ background: "#d9ecf5" }}>🃏</span><div><h1>{ui("بطاقات المراجعة السريعة", "Quick Review Flashcards")}</h1><p>{ui(`${FLASH.length} بطاقة · متقنة: ${mastered}`, `${FLASH.length} cards · mastered: ${mastered}`)}</p></div></div>
      <div className="flex flex-wrap gap-2 items-center"><LecFilter v={lec} set={(n) => { setLec(n); setI(0); setSeed((s) => s + 1); }} /><button className="pill" onClick={() => { setSeed((s) => s + 1); setI(0); }}>🔀 {ui("خلط", "Shuffle")}</button></div>
      {f && <>
        <div className={"flip " + (flip ? "on" : "")} onClick={() => setFlip(!flip)}>
          <div className="flip-inner">
            <div className="flip-face flip-front"><span className="tag">LEC {f.lec}</span><div className="text-xl font-extrabold mt-3">{tr(f.front)}</div><div className="text-xs mt-4 opacity-60">{ui("اضغط للقلب", "Tap to flip")}</div></div>
            <div className="flip-face flip-back"><div className="text-lg font-bold leading-relaxed">{tr(f.back)}</div></div>
          </div>
        </div>
        <div className="flex gap-3 justify-center"><button className="btn-bad" onClick={() => rate(false)}>😕 {ui("ما عرفتها", "Didn't know")}</button><button className="btn-good" onClick={() => rate(true)}>😎 {ui("عرفتها", "Knew it")}</button></div>
        <div className="text-center text-sm text-[#7c776b]">{(i % list.length) + 1} / {list.length}</div>
      </>}
    </div>
  );
}

export function PastView() {
  const { ui } = useStore();
  const [lec, setLec] = useState(0);
  const list = PAST.filter((p) => !lec || p.lec === lec);
  return (
    <div className="space-y-4">
      <div className="view-head"><span className="sticker" style={{ background: "#f6e3b4" }}>📜</span><div><h1>{ui("أسئلة السنين (LEC 1–3)", "Past Papers (LEC 1–3)")}</h1><p>{ui(`${PAST.length} سؤال متعلق فعلاً بالمحاضرات وجوابه موجود بالشرح`, `${PAST.length} questions truly related to the lectures, answerable from the content`)}</p></div></div>
      <div className="callout" style={{ background: "#fdf0e6" }}><span className="callout-ic">ℹ️</span><div className="text-sm leading-relaxed">{ui("تم استبعاد 5 أسئلة من الملف لأنها ما تخص هاي المحاضرات: أدوية التليف الرئوي (2017)، رئة المزارع، معايير تفاقم COPD، القلب الرئوي (Cor pulmonale)، ومضاعفات الربو.", "5 questions were excluded as unrelated to these lectures: drug-induced fibrosis (2017), farmer's lung, COPD exacerbation criteria, cor pulmonale, and asthma complications.")}</div></div>
      <LecFilter v={lec} set={setLec} />
      <div className="grid gap-3">{list.map((p) => <PastCard key={p.id} p={p} />)}</div>
    </div>
  );
}

export function ReviewView({ go }: { go: (v: string) => void }) {
  const { tr, ui, srs, resetSrs } = useStore();
  const items = [...ALLQ.map((q) => ({ id: q.id, lec: q.lec, text: q.q, kind: "MCQ" })), ...FLASH.map((f) => ({ id: f.id, lec: f.lec, text: f.front, kind: "Card" })), ...PAST.filter((p) => !p.options).map((p) => ({ id: p.id, lec: p.lec, text: p.q, kind: "Past" }))];
  const groups: [string, string, string, string][] = [
    ["repeat", ui("أخطاء متكررة", "Repeated mistakes"), "🔁", "#f6d5cf"], ["wrong", ui("جاوبتها غلط", "Answered wrong"), "❌", "#fbe3d8"],
    ["due", ui("حان وقت مراجعتها", "Due for review"), "⏰", "#fbefd9"], ["learning", ui("قيد التعلم", "Learning"), "🌱", "#e7eef7"], ["mastered", ui("أتقنتها", "Mastered"), "🏆", "#e3f0e9"],
  ];
  const by = (s: string) => items.filter((it) => srsStatus(srs[it.id]) === s);
  const seen = items.filter((it) => srs[it.id]).length;
  const perLec = [1, 2, 3].map((l) => { const its = items.filter((x) => x.lec === l && srs[x.id]); const ok = its.reduce((n, x) => n + srs[x.id].right, 0); const all = its.reduce((n, x) => n + srs[x.id].right + srs[x.id].wrong, 0); return all ? Math.round((ok / all) * 100) : 0; });
  return (
    <div className="space-y-4">
      <div className="view-head"><span className="sticker" style={{ background: "#efe1f5" }}>🧠</span><div><h1>{ui("المراجعة الذكية (Spaced Repetition)", "Smart Review (Spaced Repetition)")}</h1><p>{ui("الموقع يتابع كل جواب ويحدد شنو تراجع ومتى", "The site tracks every answer and schedules what to review and when")}</p></div></div>
      <div className="fill-grid tight">
        <div className="stat"><div className="stat-v">{seen}/{items.length}</div><div className="text-sm">{ui("عناصر شفتها", "Items seen")}</div></div>
        {perLec.map((p, i) => <div key={i} className="stat"><div className="stat-v">{p}%</div><div className="text-sm">{ui(`دقة LEC ${i + 1}`, `LEC ${i + 1} accuracy`)}</div></div>)}
      </div>
      <div className="flex flex-wrap gap-2"><button className="btn-soft" onClick={() => go("smart")}>🚀 {ui("ابدأ جلسة مراجعة ذكية", "Start a smart session")}</button><button className="pill" onClick={() => go("flash")}>🃏 {ui("البطاقات", "Flashcards")}</button><button className="pill" onClick={() => { if (confirm(ui("مسح كل السجل؟", "Reset all history?"))) resetSrs(); }}>🗑️ {ui("مسح السجل", "Reset")}</button></div>
      <div className="callout" style={{ background: "#efe8f6" }}><span className="callout-ic">⏳</span><div className="text-sm leading-relaxed">{ui("الجواب الغلط يرجع بعد 10 دقائق. الصح يتباعد: يوم ← 3 أيام ← أسبوع ← أسبوعين ← شهر. غلطتين أو أكثر = 'أخطاء متكررة' تظهر أولاً.", "Wrong answers return after 10 min. Correct ones space out: 1 day → 3 days → 1 week → 2 weeks → 1 month. Two+ errors = 'repeated mistakes', shown first.")}</div></div>
      <div className="fill-grid review-grid">
        {groups.map(([k, l, ic, bg]) => { const g = by(k); return (
          <div key={k} className="review-col" style={{ background: bg }}>
            <div className="font-extrabold mb-2">{ic} {l} <span className="tag">{g.length}</span></div>
            <div className="space-y-1.5 max-h-72 overflow-auto">{g.length ? g.map((it) => <div key={it.id} className="review-item"><span className="tag tag-c">{it.kind} · L{it.lec}</span> {tr(it.text)}{srs[it.id] && <span className="text-xs opacity-60"> ({srs[it.id].right}✓ {srs[it.id].wrong}✗)</span>}</div>) : <div className="text-sm opacity-60">{ui("فارغ", "Empty")}</div>}</div>
          </div>
        ); })}
      </div>
    </div>
  );
}
